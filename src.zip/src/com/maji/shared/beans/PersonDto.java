package com.maji.shared.beans;

import java.io.Serializable;
import java.util.Date;

public class PersonDto implements Serializable {

	private static final long serialVersionUID = -899570681894377866L;
	  private Integer personId;
	    private String firstName;
	    private String lastName;
	    private String surname;
	    private Integer cityId;
	    private String address;
	    private String mobileNumber;
	    private Integer statusId;
	    private Date createdOn;
	    private Integer createdBy;
	    private Date modifiedOn;
	    private Integer modifiedBy;
	private boolean updated;
	private boolean deleted;
	
	    public PersonDto() {
		this.personId = -1;
	}

	public PersonDto(int serviceid) {
		this.personId = serviceid;
	}


	public Integer getPersonId() {
		return personId;
	}

	public void setPersonId(Integer personId) {
		this.personId = personId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public boolean isUpdated() {
		return updated;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public boolean isDeleted() {
		return deleted;
	}

	@Override
	  public String toString() {
	    StringBuilder builder = new StringBuilder();
	    builder.append("PersonDto [personId=");
	    builder.append(personId);
	    builder.append(", firstName=");
	    builder.append(firstName);
	    builder.append(", lastName=");
	    builder.append(lastName);
	    builder.append(", surname=");
	    builder.append(surname);
	    builder.append(", cityId=");
	    builder.append(cityId);
	    builder.append(", address=");
	    builder.append(address);
	    builder.append(", mobileNumber=");
	    builder.append(mobileNumber);
	    builder.append(", statusId=");
	    builder.append(statusId);
	    builder.append("]");
	    return builder.toString();
	  }

	  @Override
	  public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	    return result;
	  }

	  @Override
	  public boolean equals(Object obj) {
	    if (this == obj)
	      return true;
	    if (obj == null)
	      return false;
	    if (!(obj instanceof PersonDto))
	      return false;
	    
	    PersonDto other = (PersonDto) obj;
	    
	    if (personId != other.personId)
		      return false;
	    if (firstName != other.firstName)
	      return false;
	    if (lastName != other.lastName)
		      return false;
	    if (surname != other.surname)
		      return false;
	    if (cityId == null) {
	      if (other.cityId != null)
	        return false;
	    } else if (!address.equals(other.address))
	      return false;
	    if (mobileNumber != other.mobileNumber)
	      return false;
	    if (statusId != other.statusId)
		      return false;
	    
	    return false;
	  }
	
}
