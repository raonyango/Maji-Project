package com.maji.shared.properties;

import com.google.gwt.i18n.client.Constants;

public interface MajiStrings extends Constants, ToolbarConstants {
	
	public String new_bill_status();

	public String user_info_lbl();

	public String protectedpwd();

	public String username_label();

	public String password_label();

	public String save_login_label();

	public String login_button();

	public String reset_button();

	public String logout_button();

	public String loading();

	public String session_timed_out();

	public String invalid_login();

	public String login_as();

	public String refresh();

	public String welcome();

	public String footer();

	public String product_name();

	public String useraccount_token();

	public String login_token();

	public String home_token();

	public String error();

	public String app_error();

	public String ok_button_txt();

	public String cancel_button_txt();

	public String fail_logout_user();

	public String fail_login_user();

	public String fail_check_session();

	public String err_logout_user();

	public String err_login_user();

	public String err_check_session();

	public String forgot_password();

	public String forgot_password_link();

	public String err_remember_user_login();

	public String remember_me();

	public String username_and_password_required();

	public String username_required();

	public String password_required();

	public String username_too_short();

	public String password_too_short();

	public String err_validate_login_form();

	public String close_button();

	public String no_priviledge_for_operation();

	public String access_denied();

	public String settings_tab();

	public String news_tab();

	public String overview_tab();

	public String updating();

	public String update_profile_button();

	public String admin_firstname_label();

	public String admin_lastname_label();

	public String admin_username_label();

	public String street_label();

	public String city_label();

	public String admin_email_label();

	public String company_label();

	public String zip_label();

	public String user_not_found_title();

	public String user_not_found();

	public String error_getting_profile();

	public String personal_info();

	public String save_profile_button();

	public String update_personal_info();

	public String required_fields_info();

	public String confirm_password_label();

	public String industry_label();

	public String country_label();

	public String is_not_a_valid();

	public String rectify_fields_with_errors();

	public String err_updating_profile();

	public String company_profile_update_success();

	public String cancel_form_button();

	public String err_getallWBStatuses();

	public String please_wait();

	public String err_reset_password();

	public String password_reset_successfull();

	public String login_title();

	public String forgot_password_title();

	public String email_label();

	public String send_button();

	public String username_and_email_required();

	public String email_required();

	public String email_too_short();

	public String invalid_email();

	public String manage_tab();

	public String setup_tab();

	public String admin_tab();

	public String units_tab();

	public String bill_tab();

	public String charges_tab();

	public String combo_loading_text();

	public String company_info_lbl();

	public String cancel_tab();

	public String help_tab();

	public String expand_tab();

	public String statistics_tab();

	public String server_unavailable();

	public String user_profile_update_success();

	public String address1_label();

	public String address2_label();

	public String address3_label();

	public String phone_number_label();

	public String company_url_label();

	public String region_label();

	public String language_label();

	public String admin_password_label();

	public String err_getallregions();

	public String err_getalllanguages();

	public String register();

	public String register_form_title();

	public String err_creating_company_profile();

	public String register_profile_button();

	public String invalid_company_url();

	public String validating_msg();

	public String admin_password_confirm_label();

	public String captcha_label();

	public String invalid_captcha_code();

	public String password_not_matching_err();

	public String password_bad_err();

	public String short_password_info();

	public String bad_password_info();

	public String good_password_info();

	public String strong_password_info();

	public String same_password_info();

	public String update_token();

	@DefaultStringValue("Service, Keyword, Stopword, User, URL")
	public String new_activity_menu_item_names();

	public String main_navigator_section_header();

	public String project_name();

	@DefaultStringValue("Logout")
	public String options_activity_menu_item_names();

	public String required_field_error_msg();

	public String email();

	public String url();

	public String err_getallcountries();

	public String profile_update_success();

	public String help_popup_title();

	public String error_page_info();

	public String pending_implementation_info();

	public String option_menu();

	public String companyurl_ttip();

	public String accept_terms_lbl();

	public String terms_of_use();

	public String accept_terms_error_msg();

	public String refresh_captcha_btn_ttip();

	public String register_btn_caption();

	public String error_validate_password();

	public String phone_number();

	public String username_not_available();

	public String err_validate_captcha();

	public String err_validate_username();

	public String err_validate_url();

	public String admin_username_ttp();

	public String captcha_ttp();

	public String register_success_msg();

	public String brainup_msg();

	public String session_expired_info();

	public String sending_msg();

	public String change_button();

	public String oldpassword_label();

	public String new_password_label();

	public String confirm_new_password_label();

	public String change_password_title();

	public String password_change_successfull();

	public String err_change_password();

	public String invalid_old_password();

	public String first_name_lbl();

	public String person_address_lbl();

	public String person_telephone_lbl();

	public String person_created_on_lbl();

	public String person_status_lbl();

	public String service_details_lbl();

	public String service_last_update_time_lbl();

	public String error_get_all_addons();

	public String error_get_all_persons();

	public String service_last_update_date_lbl();

	public String servicedetails_popup_title();

	public String error_get_service_details();

	public String currency();

	public String form_unit_price();

	public String form_service_version();

	public String form_service_name();

	public String form_service_createdon();

	public String formsg();

	public String no_addons_msg();

	public String no_record_msg();

	public String addondetails_popup_title();

	public String form_addon_name();

	public String form_addon_version();

	public String form_addon_description();

	public String form_addon_createdon();

	public String err_show_details_popup();

	public String error_get_addon_details();

	public String hide_btn();

	public String cloud_iframe_width_label();

	public String cloud_iframe_height_label();

	public String font_label();

	public String color();

	public String default_view_label();

	public String bgcolor_label();

	public String domain_label();

	public String domain_ttip();

	public String contentcolor_label();

	public String newscolor_label();

	public String popupbgcolor_label();

	public String cloud_info_lbl();

	public String search_iframe_width_label();

	public String search_iframe_height_label();

	public String aisearch_info_lbl();

	public String links_info_lbl();

	public String copy_url_ttp();

	public String cloudlink_label();

	public String searchlink_label();

	public String agentlink_label();

	public String no_links_msg();

	public String err_getallfonts();

	public String service_label();

	public String select_other_domain_title();

	public String err_load_service_details();

	public String err_get_user_services();

	public String cloud_xl_info_lbl();

	public String select_default_view();

	public String no_domains();

	public String frames_default_section_header();

	public String edit_domain_label();

	public String update_domain_button();

	public String cancel_domain_update_button();

	public String updating_domain_msg();

	public String update_domain_title();

	public String add_domain_button();

	public String new_domain_label();

	public String delete_domain_button();

	public String delete_domain_title();

	public String delete_domain_msg();

	public String deleting_domain_msg();

	public String confirm_cascade_delete_domain_msg();

	public String domain_exists_msg();

	public String save_frames_changes_first_msg();

	public String color_highlights_keywords();

	public String frames_update_success();

	public String search_keywordscolor_label();

	public String id_lbl();

	public String news_category_lbl();

	public String newspaper_name_lbl();

	public String newspaper_region_lbl();

	public String err_get_all_newscategories();

	public String err_get_all_newspapers();

	public String err_get_user_newspapers();

	public String err_get_user_newscategories();

	public String err_save_user_newscategories();

	public String err_save_user_newspapers();

	public String save_cloudsources_success_msg();

	public String no_newspapers_msg();

	public String no_newscategories_msg();

	public String all_newspapers_lbl();

	public String selected_newspapers_lbl();

	public String all_news_categories_lbl();

	public String selected_news_categories_lbl();

	public String drag_drop_ttp();

	public String cloud_sources_service_list_ttp();

	public String service_actualqty_lbl();

	public String service_newqty_lbl();

	public String service_unitprice_lbl();

	public String service_totalprice_lbl();

	public String err_save_order();

	//--------------------------------
	public String person_menu();

	public String last_name_lbl();

	public String surname_lbl();
	
	public String unit_number_lbl();
	
	public String block_lbl();
	
	public String owner_lbl();
	
	public String tenant_lbl();
	
	public String error_get_all_units();
	
	public String units_menu();
	
	public String error_get_all_charges();
	
	public String charge_amount_lbl();
	
	public String currency_lbl();
	
	public String active_lbl();
	
	public String error_get_all_bills();
	
	public String bill_number_lbl();
	
	public String bill_month_lbl();
	
	public String bill_year_lbl();
	
	public String meter_reading_lbl();
	
	public String units_consumed_lbl();
	
	public String due_date_lbl();
	
	public String status_name_lbl();
	
	public String bill_charge_lbl();
	//---------------------

	public String month_lbl();

	public String year_lbl();

	public String charge_per_unit_lbl();

	public String house_unit_lbl();

	public String bill_due_date_lbl();

	public String created_on_lbl();

	public String bill_info_section_name();

	public String bill_status_lbl();
	
	public String total_bill_lbl();

	public String error_get_active_unit_charge();

	public String prev_meter_reading_lbl();

	public String error_add_new_bill();

	public String error_get_bill();

	public String error_update_bill();

	public String record_update_success();

	public String grd_meter_reading_lbl();

	public String print_bills_section();

	public String print_options_lbl();

	public String printbtn_caption();

	public String error_printing_bills();

	public String meter_no_lbl();

	public String billing_date_lbl();

	public String error_get_all_fees();

	public String fee_amount_lbl();

	public String fee_desc_lbl();

	public String fees_tab();//

	public String person_info_section_name();

	public String fname_lbl();

	public String mname_lbl();

	public String city_lbl();

	public String address_lbl();

	public String mobile_num_lbl();

	public String error_get_all_cities();
	
	public String error_get_all_pstatuses();

	public String error_add_new_person();

	public String error_update_person();

	public String unit_info_section_name();

	public String error_add_new_unit();

	public String error_update_unit();

	public String error_get_all_blocks();

	public String error_add_new_fee();

	public String error_update_fee();

	public String fee_status_lbl();

	public String fee_info_section_name();

	public String charge_info_section_name();

	public String error_add_new_charge();

	public String error_update_charge();

	public String form_fee_amount_lbl();

	public String charge_created_on_lbl();

	public String charge_modified_on_lbl();
}
