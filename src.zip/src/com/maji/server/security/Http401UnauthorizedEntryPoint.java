package com.maji.server.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

/**
 * <p>
 * In a GWT application, we are using GWT RPC requests, and cannot rely on the server
 * side for the commencement of authentication. Instead, this class will inform the
 * calling method that the user needs to authenticate first, by returning an
 * <code>HttpServletResponse.SC_UNAUTHORIZED</code> (401 error).
 * 
 * This needs to be picked up in an AsyncCallback super-class, such as {@link AutoErrorHandlingAsyncCallback}.
 */
public class Http401UnauthorizedEntryPoint implements AuthenticationEntryPoint {
    //private static final Log logger = LogFactory.getLog(Http401UnauthorizedEntryPoint.class);

    /**
     * Always returns a 401 error code to the client.
     */
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException arg2) throws IOException,
            ServletException {
        //if (logger.isDebugEnabled()) {
          //  logger.debug("Pre-authenticated entry point called. Rejecting access...");
        //}
        System.out.println("...Pre-authenticated entry point called. Rejecting access...");
        
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authentication required");
    }
}
