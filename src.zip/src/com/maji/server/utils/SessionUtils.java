package com.maji.server.utils;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.WeakHashMap;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.InitializingBean;

public class SessionUtils implements InitializingBean{
	/*public static FileItemRegistry getSessionRegistry(Log logger, HttpSession session) {
        FileItemRegistry registry = (FileItemRegistry)session.getAttribute("registry");
        if (registry == null) {
            registry = new FileItemRegistry(logger);
            session.setAttribute("registry", registry);
        }
        return registry;
    }*/

	private WeakHashMap<String, HttpSession> allsessions = null;

	public WeakHashMap<String, HttpSession> getSessionsList() {
		return allsessions;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		allsessions = new WeakHashMap<String, HttpSession>();
		allsessions.clear();		
	}

	public void ininializeSessionList() {
		allsessions = new WeakHashMap<String, HttpSession>();
	}		
	
    /**
     * Remove session attributes, it has to be done in the login and logout actions
     * @param session
     */
    public void cleanSessionAttributes(HttpSession session) {
        @SuppressWarnings("unchecked")
        Enumeration en = session.getAttributeNames();
        ArrayList<String> toRemove = new ArrayList<String>();
        String temp;
        while (en.hasMoreElements()) {
            toRemove.add(en.nextElement().toString());
        }
        for (String attr: toRemove) {
        	temp = attr;
        	if(temp.toLowerCase().indexOf("SPRING".toLowerCase()) < 0)
        		try{
        			session.removeAttribute(attr);
        		}catch (Exception e) {
					e.printStackTrace();
				}        	
        }
    }
	
    public WeakHashMap<String, HttpSession> addToSessionsList(HttpSession session, int userid){
    	try {
    		//TODO AOP:clear unused sessions
			if(allsessions == null)
				allsessions = new WeakHashMap<String, HttpSession>();
			
			WeakHashMap<String, HttpSession> sessionlistclone = allsessions;
			for(Entry<String, HttpSession> entry: sessionlistclone.entrySet()){
				if(entry.getKey().equals(String.valueOf(userid))){
					if(entry.getValue().getId().equals(session.getId())){
						//System.out.println(".............................................EXISTS...NT ADDED");
						return allsessions;
					}
				}
			}
			
			try{
				allsessions.put(String.valueOf(userid), session);
				//System.out.println(".............................................ADDED TO SESSIONLIST");
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return allsessions;
		} catch (Exception e) {
			e.printStackTrace();
			return allsessions;
		}				
	}
    
    public HttpSession getSessionFromList(HttpSession session){
    	try {
    		if(allsessions == null){
        		allsessions = new WeakHashMap<String, HttpSession>();
    		}
        	WeakHashMap<String, HttpSession> sessionlistclone = allsessions;
        	for(Entry<String, HttpSession> entry: sessionlistclone.entrySet()){
        		if(entry.getValue().getId().equals(session.getId())){
    				return entry.getValue();
    			}        		
        	}
        	return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
    }
    
    public HttpSession getSessionFromList(int userid){
    	try {
    		if(allsessions == null)
        		allsessions = new WeakHashMap<String, HttpSession>();
        	
        	WeakHashMap<String, HttpSession> sessionlistclone = allsessions;
        	for(Entry<String, HttpSession> entry: sessionlistclone.entrySet()){
        		if(entry.getKey().equals(String.valueOf(userid))){
    				return entry.getValue();
    			}        		
        	}
        	
        	return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
    }
    
    public boolean removeSessionFromList(HttpSession session){
    	try {
    		if(session != null){    		
	    		if(allsessions == null)
	        		allsessions = new WeakHashMap<String, HttpSession>();
	        	
	        	WeakHashMap<String, HttpSession> sessionlistclone = allsessions;
	        	for(Entry<String, HttpSession> entry: sessionlistclone.entrySet()){
	        		if(entry.getValue().getId().equals(session.getId())){
	    				allsessions.remove(entry.getKey());
	    				return true;
	    			}        		
	        	}        	
	        	return false;
    		}else{
    			return true;
    		}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
    
    @SuppressWarnings("unchecked")
	public HashMap getHashMapFromSession(String key, HttpSession session) {
		// If the session does not contain anything, create a new HashMap
		if (session.getAttribute(key) == null) {
			   session.setAttribute(key, new HashMap());
		}
		  
		// Return the HashMap
		return (HashMap) session.getAttribute(key);
	}
}
