package com.maji.server.utils;

/**
 * @author Rosemary A. Onyango
 *
 */
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.support.TransactionTemplate;

import com.maji.server.ibatis.dao.BlockDAO;
import com.maji.server.ibatis.dao.CityDAO;
import com.maji.server.ibatis.dao.HouseUnitDAO;
import com.maji.server.ibatis.dao.PersonDAO;
import com.maji.server.ibatis.dao.PersonStatusDAO;
import com.maji.server.ibatis.dao.StandardChargeDAO;
import com.maji.server.ibatis.dao.UserDAO;
import com.maji.server.ibatis.dao.WaterBillDAO;
import com.maji.server.ibatis.dao.WaterBillMaxDAO;
import com.maji.server.ibatis.dao.WaterBillStatusDAO;
import com.maji.server.ibatis.dao.WaterChargeDAO;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.Block;
import com.maji.shared.ibatis.beans.BlockExample;
import com.maji.shared.ibatis.beans.City;
import com.maji.shared.ibatis.beans.CityExample;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.HouseUnitExample;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.PersonExample;
import com.maji.shared.ibatis.beans.PersonStatus;
import com.maji.shared.ibatis.beans.PersonStatusExample;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.ibatis.beans.StandardChargeExample;
import com.maji.shared.ibatis.beans.User;
import com.maji.shared.ibatis.beans.UserExample;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterBillExample;
import com.maji.shared.ibatis.beans.WaterBillExample.Criteria;
import com.maji.shared.ibatis.beans.WaterBillMax;
import com.maji.shared.ibatis.beans.WaterBillMaxExample;
import com.maji.shared.ibatis.beans.WaterBillStatus;
import com.maji.shared.ibatis.beans.WaterBillStatusExample;
import com.maji.shared.ibatis.beans.WaterCharge;
import com.maji.shared.ibatis.beans.WaterChargeExample;
import com.maji.shared.properties.MajiConstants;

public class MajiManager implements InitializingBean {

	@Autowired
	private ResourceBundle appproperties;
	@Autowired
	private MajiUtils brainuputils;
	@Autowired
	private LoginManager loginmanager;
	@Autowired
	private SessionUtils sessionutils;
	@Autowired
	private UserManager usermanager;

	@Autowired
	private SystemRolesManager sysrolesmanager;
	@Autowired
	private TransactionTemplate sharedTransactionTemplate = null;

	@Autowired
	private PersonDAO persondao;
	private PersonExample personexample;

	@Autowired
	private WaterChargeDAO wchargedao;
	private WaterChargeExample wchargeexample;

	@Autowired
	private WaterBillDAO wbilldao;
	private WaterBillExample wbillexample;

	@Autowired
	private WaterBillMaxDAO wbillmaxdao;
	private WaterBillMaxExample wbillmaxexample;

	@Autowired
	private HouseUnitDAO hunitdao;
	private HouseUnitExample hunitexample;

	@Autowired
	private BlockDAO blockdao;
	private BlockExample blockexample;

	@Autowired
	private UserDAO userdao;
	private UserExample userexample;

	@Autowired
	private WaterBillStatusDAO wbstatusdao;
	private WaterBillStatusExample wbstatusexample;

	@Autowired
	private StandardChargeDAO feedao;
	private StandardChargeExample feeexample;

	@Autowired
	private CityDAO citydao;
	private CityExample cityexample;

	@Autowired
	private PersonStatusDAO pstatusdao;
	private PersonStatusExample pstatusexample;

	@Autowired
	private BasicDataSource dataSource;

	public ResourceBundle getAppproperties() {
		return appproperties;
	}

	public void setAppproperties(ResourceBundle appproperties) {
		this.appproperties = appproperties;
	}

	public MajiUtils getBrainuputils() {
		return brainuputils;
	}

	public void setBrainuputils(MajiUtils brainuputils) {
		this.brainuputils = brainuputils;
	}

	public LoginManager getLoginmanager() {
		return loginmanager;
	}

	public void setLoginmanager(LoginManager loginmanager) {
		this.loginmanager = loginmanager;
	}

	public SessionUtils getSessionutils() {
		return sessionutils;
	}

	public void setSessionutils(SessionUtils sessionutils) {
		this.sessionutils = sessionutils;
	}

	public MajiManager() {

	}

	@Override
	public void afterPropertiesSet() throws Exception {

	}

	public StandardServerResponse authenticateUser(UserLoginData logindata,
			HttpSession session) {
		return loginmanager.authenticateUser(logindata, session, sessionutils);
	}

	public StandardServerResponse checkUserSession(UserLoginData logindata,
			HttpSession session) {
		return loginmanager.checkUserSession(logindata, session, sessionutils);
	}

	public StandardServerResponse logoutUser(String username,
			HttpSession session) {
		return loginmanager.logoutUser(username, session, sessionutils);
	}

	public StandardServerResponse getUserProfileData(UserLoginData logindata,
			boolean newsession) {
		StandardServerResponse response = new StandardServerResponse();
		User user;
		try {
			user = usermanager.getUserProfile(logindata.getUsername(),
					newsession);
			if (user != null) {
				List<User> lst = new ArrayList<User>();
				lst.add(user);
				response.setListData(lst);
				response.setSuccess(true);
			} else {
				response.setSuccess(false);
				response.setErrorData(appproperties
						.getString("get_userprofile_data_error"));
			}
		} catch (Exception e) {
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_userprofile_data_error"));
			e.printStackTrace();
		} finally {
			user = null;
		}

		return response;
	}

	/*
	 * public StandardServerResponse updateUserProfile(final User
	 * updatedProfile, final boolean updatepassword, final HttpSession session)
	 * { final StandardServerResponse response = new StandardServerResponse();
	 * try{ if(updatedProfile != null){ if(session != null){
	 * if(sharedTransactionTemplate != null){
	 * sharedTransactionTemplate.execute(new TransactionCallback<Boolean>() {
	 * UserLoginData sessionuser;
	 * 
	 * @Override public Boolean doInTransaction(TransactionStatus arg0) { try{
	 * sessionuser =
	 * (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
	 * if(sessionuser != null){ updatedProfile.setModifiedon(new Date());
	 * updatedProfile.setModifiedby(sessionuser.getUserId());
	 * if(updatepassword){ if(updatedProfile.getPassword() != null)
	 * updatedProfile
	 * .setPassword(brainuputils.encryptString(updatedProfile.getPassword())); }
	 * if(usermanager.updateUser(updatedProfile)){ //update session data
	 * if(updatedProfile.getUsername() != null)
	 * sessionuser.setUsername(updatedProfile.getUsername());
	 * session.setAttribute(MajiConstants.USER_SESS_ATTR, sessionuser);
	 * 
	 * response.setSuccess(true); return true; }else{
	 * response.setSuccess(false);
	 * response.setErrorData(appproperties.getString(
	 * "update_userprofile_data_error")); } } return false; }catch (Exception e)
	 * { e.printStackTrace(); response.setSuccess(false);
	 * response.setErrorData(appproperties
	 * .getString("update_userprofile_error")); arg0.setRollbackOnly(); return
	 * false; }finally{ sessionuser = null; } } }); } } } } catch (Exception e)
	 * { e.printStackTrace(); response.setSuccess(false);
	 * response.setErrorData(appproperties
	 * .getString("update_userprofile_error")); }finally{ } return response; }
	 * 
	 * public StandardServerResponse updateUserProfile(User updatedProfile) {
	 * StandardServerResponse response = new StandardServerResponse();
	 * UserLoginData sessionuser = new UserLoginData();
	 * sessionuser.setUserId(1); try{ if(updatedProfile != null){ if(true){
	 * //sessionuser =
	 * (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
	 * if(true){ updatedProfile.setModifiedon(new Date());
	 * updatedProfile.setModifiedby(sessionuser.getUserId());
	 * if(usermanager.updateUser(updatedProfile)){ //update session data
	 * sessionuser.setUsername(updatedProfile.getUsername());
	 * //session.setAttribute(MajiConstants.USER_SESS_ATTR, sessionuser);
	 * 
	 * response.setSuccess(true); }else{ response.setSuccess(false);
	 * response.setErrorData
	 * (appproperties.getString("update_userprofile_data_error")); } } } } }
	 * catch (Exception e) { e.printStackTrace(); response.setSuccess(false);
	 * response
	 * .setErrorData(appproperties.getString("update_userprofile_error"));
	 * }finally{ sessionuser = null; } return response; }
	 */

	/*
	 * public StandardServerResponse resetPassword(ForgotPasswordData data) {
	 * return usermanager.resetPassword(data); }
	 * 
	 * public StandardServerResponse getCompanyProfileData(HttpSession session,
	 * boolean newsession) { StandardServerResponse response = new
	 * StandardServerResponse(); UserLoginData sessionuser;
	 * 
	 * try { if(session != null){ sessionuser =
	 * (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
	 * if(sessionuser != null){ List<Company> lst = new ArrayList<Company>();
	 * Company company =
	 * companymanager.getCompanyProfile(sessionuser.getCompanyId()); if(company
	 * != null){ lst.add(company); response.setListData(lst);
	 * response.setSuccess(true); return response; } } }
	 * response.setSuccess(false);
	 * response.setErrorData(appproperties.getString(
	 * "get_companyprofile_error")); } catch (Exception e) {
	 * e.printStackTrace(); response.setSuccess(false);
	 * response.setErrorData(appproperties
	 * .getString("get_companyprofile_error")); }finally{ sessionuser = null; }
	 * return response; }
	 * 
	 * public StandardServerResponse updateCompanyProfile(Company
	 * updatedProfile, HttpSession session) { StandardServerResponse response =
	 * new StandardServerResponse(); UserLoginData sessionuser; try {
	 * if(updatedProfile != null){ if(session != null){ sessionuser =
	 * (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
	 * if(sessionuser != null){
	 * updatedProfile.setModifiedby(sessionuser.getUserId());
	 * updatedProfile.setModifiedon(new Date()); } }
	 * if(companymanager.updateCompany(updatedProfile)){
	 * response.setSuccess(true); }else{ response.setSuccess(false);
	 * response.setErrorData
	 * (appproperties.getString("update_companyprofile_data_error")); } } }
	 * catch (Exception e) { e.printStackTrace(); response.setSuccess(false);
	 * response
	 * .setErrorData(appproperties.getString("update_companyprofile_error")); }
	 * return response; }
	 * 
	 * public StandardServerResponse loadAllLanguages() { StandardServerResponse
	 * response = new StandardServerResponse(); try {
	 * response.setListData(languagemanager.loadAllLanguages());
	 * response.setSuccess(true); } catch (Exception e) { e.printStackTrace();
	 * response.setSuccess(false);
	 * response.setErrorData(appproperties.getString(
	 * "get_all_languages_error")); } return response; }
	 */

	/*
	 * public StandardServerResponse registerCompany(final Company company,
	 * final User adminuser) { final StandardServerResponse response = new
	 * StandardServerResponse(); EmailCategory ecat = null; SentMail smail =
	 * null; UnSentMail usmail = null; EmailStatus estatus = null; String
	 * message = null, subject = null, from = null, to = null;
	 * 
	 * try { if(sharedTransactionTemplate != null){ boolean
	 * transactionsuccessful = sharedTransactionTemplate.execute(new
	 * TransactionCallback<Boolean>() {
	 * 
	 * @Override public Boolean doInTransaction(TransactionStatus arg0) {
	 * UserRole role; CompanyUser cuser; Date creationdate = null; try { //add
	 * to br_company int coid = companymanager.addCompany(company);
	 * company.setId(coid);
	 * 
	 * if(coid != -1 && coid != 0 && coid > 0){ role =
	 * sysrolesmanager.getRole(DatabaseConstants.ROLE_COMPANY_ADMIN); if(role !=
	 * null){ //add to br_user creationdate = new Date();
	 * 
	 * adminuser.setUserRoleId(role.getId());
	 * adminuser.setPassword(brainuputils.
	 * encryptString(adminuser.getPassword()));
	 * adminuser.setCreatedby(usermanager.getUserSystem("SYSTEM").getId());
	 * adminuser.setCreatedon(creationdate); int uid =
	 * usermanager.addUser(adminuser);
	 * 
	 * if( uid != -1 && uid != 0 && uid > 0 ){ //add to br_company_user cuser =
	 * new CompanyUser(); cuser.setUserId(uid); cuser.setCompanyId(coid);
	 * cuser.setCreatedby(usermanager.getUserSystem().getId());
	 * cuser.setCreatedon(creationdate);
	 * 
	 * int couid = usermanager.addCompanyUser(cuser);
	 * 
	 * if( couid != -1 && couid != 0 && couid > 0 ){
	 * response.setStringData("?key=" +
	 * brainuputils.encryptString(MajiConstants.COMPANY_PREFIX +
	 * adminuser.getUsername().trim().toLowerCase() + creationdate.toString()) +
	 * "&fl=" + uid); return true; } }else{ arg0.setRollbackOnly(); } } }else{
	 * arg0.setRollbackOnly(); } } catch (Exception e) { e.printStackTrace();
	 * response.setSuccess(false);
	 * response.setErrorData(appproperties.getString("err_register"));
	 * arg0.setRollbackOnly(); }finally{ role = null; cuser = null; } return
	 * false; } });
	 * 
	 * if(transactionsuccessful){ ecat =
	 * emailmanager.getEmailCategory(DatabaseConstants
	 * .NEW_ACCOUNT_CONFIRMATION); if(ecat == null){ response.setSuccess(false);
	 * response
	 * .setErrorData(appproperties.getString("err_retrieveing_email_category"));
	 * }else{ String activationkey = response.getStringData();
	 * response.setStringData(null);
	 * 
	 * //send e-mail with confirmation link from =
	 * usermanager.getUserSystem().geteMail(); to = adminuser.geteMail();
	 * subject = appproperties.getString("new_brainup_account"); message =
	 * appproperties.getString("new_brainup_account_email_1") + " " +
	 * adminuser.getFirstname().toUpperCase() + (adminuser.getLastname() == null
	 * || adminuser.getLastname().trim().equals("") ? "," : " " +
	 * adminuser.getLastname().toUpperCase()) + " " +
	 * appproperties.getString("new_brainup_account_email_2") + " " +
	 * appproperties.getString("account_activation_url") + activationkey + " " +
	 * appproperties.getString("new_brainup_account_email_3");
	 * 
	 * estatus = emailhelper.sendEmail(from,
	 * appproperties.getString("brainup_admin_name"), to, null, subject,
	 * message); if(estatus.isSent()){ //add to br_sent_mail smail = new
	 * SentMail(); smail.setCompanyId(company.getId());
	 * smail.setSender(usermanager.getUserSystem().getId());
	 * smail.setReceipient(to); smail.setSubject(subject);
	 * smail.setEmailmsg(message); smail.setEmailcategoryId(ecat.getId());
	 * smail.setDatesent(new Date());
	 * smail.setCreatedby(usermanager.getUserSystem().getId());
	 * smail.setCreatedon(new Date());
	 * 
	 * if(emailmanager.addSentMail(smail)){ response.setSuccess(true); }else{
	 * response.setSuccess(false);
	 * response.setErrorData(appproperties.getString("err_add_sent_mail")); }
	 * }else { if(estatus.isError()){ response.setSuccess(false);
	 * response.setIntegerData(1);
	 * response.setErrorData(appproperties.getString(
	 * "new_brainup_account_email_err")); }else{ response.setSuccess(true);
	 * response
	 * .setStringData(appproperties.getString("new_brainup_account_email_err"));
	 * } //add to br_unsent_mail usmail = new UnSentMail();
	 * usmail.setCompanyId(company.getId());
	 * usmail.setSender(usermanager.getUserSystem().getId());
	 * usmail.setReceipient(to); usmail.setSubject(subject);
	 * usmail.setEmailmsg(message); usmail.setEmailcategoryId(ecat.getId());
	 * usmail.setDuedate(new Date());
	 * usmail.setCreatedby(usermanager.getUserSystem().getId());
	 * usmail.setCreatedon(new Date());
	 * 
	 * if(!emailmanager.addUnsentMail(usmail)){
	 * 
	 * } } activationkey = null; } } } }catch(BrainupException be) {
	 * be.printStackTrace(); response.setSuccess(false);
	 * response.setErrorData(be.getMessage()); }catch(Exception e) {
	 * e.printStackTrace(); response.setSuccess(false);
	 * response.setErrorData(appproperties.getString("err_register")); }finally{
	 * ecat = null; smail = null; usmail = null; estatus = null; //company =
	 * null; //adminuser = null; }
	 * 
	 * return response; }
	 */

	public StandardServerResponse validateURL(String url) {
		StandardServerResponse response = new StandardServerResponse();

		URL urlobj;
		URLConnection conn;
		try {
			urlobj = new URL(brainuputils.getDecodedSearchString(url));
			conn = urlobj.openConnection();
			conn.connect();
			response.setSuccess(true);
		} catch (MalformedURLException e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("wrong_url_format"));
		} catch (IOException e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("no_connection")
					+ " " + brainuputils.getDecodedSearchString(url));
		} catch (Exception e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("err_validate_url"));
		} finally {
			conn = null;
			url = null;
			urlobj = null;
		}

		return response;
	}

	public StandardServerResponse verifyOldPassword(User tempuser) {
		StandardServerResponse response = new StandardServerResponse();
		User user;
		try {
			user = usermanager.getUser(tempuser.getUserId());
			if (user != null) {
				if (brainuputils.compareEncryptedAndPlainString(
						tempuser.getPassword(), user.getPassword())) {
					response.setIntegerData(0);
				} else {
					response.setIntegerData(1);
				}
				response.setSuccess(true);
			} else {
				response.setSuccess(false);
				response.setErrorData(appproperties
						.getString("err_validate_old_password_no_user"));
			}

		} catch (Exception e) {
			e.printStackTrace();

			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("err_validate_old_password"));
		} finally {
			user = null;
			tempuser = null;
		}

		return response;
	}

	public StandardServerResponse getLoginData(HttpSession session) {
		StandardServerResponse response = new StandardServerResponse();
		Object temp = null;
		List<UserLoginData> lst = null;
		try {
			temp = session.getAttribute(MajiConstants.USER_SESS_ATTR);
			if (temp instanceof UserLoginData) {
				lst = new ArrayList<UserLoginData>();
				lst.add((UserLoginData) temp);

				response.setSuccess(true);
				response.setListData(lst);

			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(e.getLocalizedMessage());
		} finally {
			temp = null;
			lst = null;
		}
		return response;
	}

	public StandardServerResponse getFonts() {
		/*
		 * StandardServerResponse response = new StandardServerResponse();
		 * List<String[]> results = new ArrayList<String[]>();
		 * 
		 * try{ if(systemfonts == null){ GraphicsEnvironment e; try{ e =
		 * GraphicsEnvironment.getLocalGraphicsEnvironment(); systemfonts =
		 * e.getAvailableFontFamilyNames(); // Get the fonts if(systemfonts ==
		 * null || systemfonts.length < 1){ systemfonts = new
		 * String[]{"Gerogia", "Tahoma", "Verdana", "Times New Roman"};
		 * 
		 * results.add(systemfonts); response.setListData(results);
		 * response.setSuccess(true); return response; }
		 * results.add(systemfonts); response.setListData(results);
		 * response.setSuccess(true); return response; }catch (Exception exn) {
		 * exn.printStackTrace();
		 * 
		 * response.setSuccess(false);
		 * response.setErrorData(exn.getLocalizedMessage()); return response;
		 * }finally{ e = null; } }else{ results.add(systemfonts);
		 * response.setListData(results); response.setSuccess(true); return
		 * response; } }catch (Exception exn) { exn.printStackTrace();
		 * 
		 * response.setSuccess(false);
		 * response.setErrorData(exn.getLocalizedMessage()); return response;
		 * }finally{ results = null; }
		 */
		return null;
	}

	@SuppressWarnings({ "unchecked", "deprecation", "unused" })
	private void addToSessionMap(String key, Object value, int user_id,
			HttpSession usersession) {
		HttpSession sessionclone;
		HashMap<String, Object> datamap = null;

		try {
			if (sessionutils.getSessionsList() == null) {
				sessionutils.ininializeSessionList();
			}
			sessionclone = sessionutils.getSessionFromList(usersession);
			if (sessionclone != null) {
				datamap = sessionutils.getHashMapFromSession(
						(user_id + "_" + new Date().getDate()), sessionclone);
			} else {
				sessionutils.addToSessionsList(usersession, user_id);
				datamap = sessionutils.getHashMapFromSession(
						(user_id + "_" + new Date().getDate()), usersession);
			}
			datamap.put(key, value);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sessionclone = null;
			datamap = null;
		}
	}

	public StandardServerResponse getAllPersons() {
		StandardServerResponse response = new StandardServerResponse();
		List<Person> p_lst = null;
		try {
			if (persondao != null) {
				personexample = new PersonExample();
				p_lst = persondao.selectPersonByExample(personexample);
			} else {
				p_lst = new LinkedList<Person>();
			}

			response.setListData(p_lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_persons_error"));
		}
		return response;
	}

	public StandardServerResponse getAllWaterCharges(Integer charge_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<WaterCharge> lst = null;
		try {
			if (wchargedao != null) {
				wchargeexample = new WaterChargeExample();

				if (charge_id != null) {
					if (charge_id > 0) {
						wchargeexample.createCriteria().andChargeIdEqualTo(
								charge_id);
					}
				}

				wchargeexample.setOrderByClause("charge_id DESC");

				lst = wchargedao.selectWaterChargeByExample(wchargeexample);
			} else {
				lst = new LinkedList<WaterCharge>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_wcharges_error"));
		}
		return response;
	}

	public StandardServerResponse getAllWaterBills(Integer bill_id,
			Integer house_unit_id, String month, Integer year, Integer status_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<WaterBill> lst = null;
		try {
			if (wbilldao != null) {
				wbillexample = new WaterBillExample();

				Criteria c = wbillexample.createCriteria();
				if (bill_id > 0) {
					c.andBillIdEqualTo(bill_id);
				}

				if (house_unit_id > 0) {
					c.andHouseUnitIdEqualTo(house_unit_id);
				}

				if (month != null) {
					if (!month.isEmpty()) {
						c.andMonthLike(month);
					}
				}

				if (year > 0) {
					c.andYearEqualTo(year);
				}

				if (status_id != null) {
					if (status_id > 0) {
						c.andStatusIdEqualTo(status_id);
					}
				}

				wbillexample.setOrderByClause("bill_id DESC");
				lst = wbilldao.selectWaterBillByExample(wbillexample);
			} else {
				lst = new LinkedList<WaterBill>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_wbills_error"));
		}
		return response;
	}

	public StandardServerResponse getAllHouseUnits(Integer unit_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<HouseUnit> lst = null;
		try {
			if (hunitdao != null) {
				hunitexample = new HouseUnitExample();

				if (unit_id > 0) {
					hunitexample.createCriteria().andUnitIdEqualTo(unit_id);
				}

				lst = hunitdao.selectHouseUnitByExample(hunitexample);
			} else {
				lst = new LinkedList<HouseUnit>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_hunits_error"));
		}
		return response;
	}

	public StandardServerResponse getAllHouseBlocks() {
		StandardServerResponse response = new StandardServerResponse();
		List<Block> lst = null;
		try {
			if (blockdao != null) {
				blockexample = new BlockExample();
				lst = blockdao.selectBlockByExample(blockexample);
			} else {
				lst = new LinkedList<Block>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_blocks_error"));
		}
		return response;
	}

	public StandardServerResponse getAllUsers() {
		StandardServerResponse response = new StandardServerResponse();
		List<User> lst = null;
		try {
			if (userdao != null) {
				userexample = new UserExample();
				lst = userdao.selectUserByExample(userexample);
			} else {
				lst = new LinkedList<User>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_wcharges_error"));
		}
		return response;
	}

	/*
	 * @Cacheable(value=MajiConstants.CONSTANTS_CACHE, key="#cache_key") private
	 * List<NewspaperDto> getAllNewspapers(String cache_key){ List<NewspaperDto>
	 * allnewspapers = null; List<Newspaper> result = null; try{
	 * System.out.println
	 * ("...................called......getAllNewspapers...maptoDTOs");
	 * 
	 * result =
	 * newspapermanager.getAllNewspapers(MajiConstants.ALL_NEWSPAPERS_KEY);
	 * 
	 * if(result != null){ if(allnewspapers == null){ allnewspapers = new
	 * ArrayList<NewspaperDto>(); }
	 * 
	 * for(Newspaper n: result){ allnewspapers.add(mapToNewspaperDto(n)); }
	 * 
	 * return allnewspapers; }
	 * 
	 * return null; }catch (Exception e) { e.printStackTrace(); return null;
	 * }finally{ result = null; } }
	 */

	// @Cacheable(value=MajiConstants.CONSTANTS_CACHE, key="#cache_key")
	public StandardServerResponse getAllWaterBillStatuses() {
		StandardServerResponse response = new StandardServerResponse();
		List<WaterBillStatus> lst = null;
		try {
			if (wbstatusdao != null) {
				wbstatusexample = new WaterBillStatusExample();
				lst = wbstatusdao
						.selectWaterBillStatusByExample(wbstatusexample);
			} else {
				lst = new LinkedList<WaterBillStatus>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("err_getallWBStatuses"));
		}
		return response;
	}

	public StandardServerResponse getActiveUnitCharge() {
		StandardServerResponse response = new StandardServerResponse();
		List<WaterCharge> lst = null;
		try {
			if (wchargedao != null) {
				wchargeexample = new WaterChargeExample();
				wchargeexample.createCriteria().andActiveEqualTo(true);
				lst = wchargedao.selectWaterChargeByExample(wchargeexample);
			} else {
				lst = new LinkedList<WaterCharge>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_wcharges_error"));
		}
		return response;
	}

	public StandardServerResponse getWaterBills(Integer houseunit_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<WaterBill> lst = null;
		try {
			if (wbilldao != null) {
				wbillexample = new WaterBillExample();
				wbillexample.createCriteria().andHouseUnitIdEqualTo(
						houseunit_id);
				wbillexample.setOrderByClause("bill_id DESC");

				lst = wbilldao.selectWaterBillByExample(wbillexample);
			} else {
				lst = new LinkedList<WaterBill>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("get_all_wbills_error"));
		}
		return response;
	}

	public StandardServerResponse addNewBill(WaterBill bill) {
		StandardServerResponse response = new StandardServerResponse();
		String bill_num = null;

		try {
			if (wbilldao != null && bill != null) {
				bill_num = getNewBillNumber(bill.getCreatedBy());

				if (bill_num != null) {
					bill.setBillNumber(bill_num);

					wbilldao.insertWaterBillSelective(bill);

					response.setSuccess(true);
				} else {
					response.setSuccess(false);
					response.setErrorData(appproperties
							.getString("error_get_new_bill_num"));
				}
			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_add_new_bill"));
		} finally {
			bill_num = null;
		}
		return response;
	}

	private String getNewBillNumber(int user_id_in) {
		String response = null;
		WaterBillMax max = null;
		String prefix = null;
		Date d = null;

		List<WaterBillMax> lst = null;
		try {
			if (wbillmaxdao != null) {
				wbillmaxexample = new WaterBillMaxExample();

				lst = wbillmaxdao.selectWaterBillMaxByExample(wbillmaxexample);

				if (lst != null) {
					if (lst.size() > 0) {
						max = lst.get(0);

						if (max.getLastNum().toString().toCharArray().length == 1) {
							prefix = "00000";
						} else if (max.getLastNum().toString().toCharArray().length == 2) {
							prefix = "0000";
						} else if (max.getLastNum().toString().toCharArray().length == 3) {
							prefix = "000";
						} else if (max.getLastNum().toString().toCharArray().length == 4) {
							prefix = "00";
						} else if (max.getLastNum().toString().toCharArray().length == 5) {
							prefix = "0";
						} else if (max.getLastNum().toString().toCharArray().length == 6) {
							prefix = "";
						}

						prefix = max.getPrefix() + prefix;
						response = prefix + (max.getLastNum() + 1);

						d = new Date();

						max.setLastNum(max.getLastNum() + 1);
						max.setModifiedOn(d);
						max.setModifiedBy(user_id_in);

						if (wbillmaxdao.updateWaterBillMaxByPrimaryKey(max) > 0) {
							return response;
						} else {
							return null;
						}

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	public StandardServerResponse updateBill(WaterBill bill) {
		StandardServerResponse response = new StandardServerResponse();
		int result = 0;

		try {
			if (wbilldao != null && bill != null) {
				result = wbilldao.updateWaterBillByPrimaryKeySelective(bill);
				if (result > 0) {
					response.setSuccess(true);
				} else {
					response.setSuccess(false);
					response.setErrorData(appproperties
							.getString("error_update_bill"));
				}
			} else {
				response.setSuccess(false);
				response.setErrorData(appproperties
						.getString("error_update_bill"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_update_bill"));
		} finally {
			result = 0;
		}
		return response;
	}

	@SuppressWarnings("deprecation")
	public StandardServerResponse printWaterBills(List<WaterBill> bills,
			HttpServletRequest request) {
		StandardServerResponse response = new StandardServerResponse();
		String file_name = null;
		Map<String, Object> parameters;
		File f;
		String bill_f_name = "";
		FileUtility fu;
		List<String> files;
		Date d = null;
		String merged_file = "C:\\merged_bill.pdf";

		try {

			fu = new FileUtility();
			files = new LinkedList<String>();

			file_name = request.getRealPath("/")
					+ appproperties.getString("bill_jrxml_file");

			f = new File(appproperties.getString("bill_export_file"));
			if (!f.exists()) {
				f.mkdirs();
			}

			for (WaterBill bill : bills) {
				parameters = new HashMap<String, Object>();
				parameters.put("bill_id_in", bill.getBillId());

				bill_f_name = appproperties.getString("bill_export_file")
						+ appproperties.getString("bill_prefix") + "_"
						+ bill.getBillNumber() + "_" + bill.getUnitNumber()
						+ ".pdf";

				JasperRunManager.runReportToPdfFile(file_name, bill_f_name,
						parameters, dataSource.getConnection());

				files.add(bill_f_name);
			}

			if (files != null) {
				if (files.size() > 0) {
					d = new Date();
					
					merged_file = appproperties.getString("merged_bill_file")
						+ d.getYear()	+ d.getMonth() + "_" + d.getDay() + "_" + d.getSeconds() + ".pdf";

					fu.merge_files(files, merged_file);
				}
			}

			response.setSuccess(true);
			response.setIntegerData(bills.size());
			response.setStringData(merged_file);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_printing_bills"));
		} finally {
			f = null;
		}

		return response;
	}

	public static void main(String[] args) {
		// MajiManager s = new MajiManager();

		try {
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("bill_id_in", Integer.valueOf(4));
			String file_name = "G:\\EclipseWorkspace\\maji\\war\\WEB-INF\\jasper_reports\\bill.jrxml";

			Connection c;
			BasicDataSource d = new BasicDataSource();
			d.setDriverClassName("com.mysql.jdbc.Driver");
			d.setUrl("jdbc:mysql://localhost/gcmaji");
			d.setUsername("root");
			d.setPassword("root");
			c = d.getConnection();

			JasperDesign jasperDesign = JRXmlLoader.load(file_name);
			JasperReport jasperReport = JasperCompileManager
					.compileReport(jasperDesign);

			JasperPrint jasperPrint = JasperFillManager.fillReport(
					jasperReport, parameters, c);
			JasperExportManager.exportReportToPdfFile(jasperPrint,
					"S:\\jreport.pdf");

			// JasperViewer.viewReport(jasperPrint);
			// JasperRunManager.runReportToPdf(file_name, parameters, c);
		} catch (Exception ex) {
			String connectMsg = "Could not create the report "
					+ ex.getMessage();
			System.out.println(connectMsg);
			ex.printStackTrace();
		}
	}

	public StandardServerResponse getAllStandardCharges(Integer fee_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<StandardCharge> lst = null;
		try {
			if (feedao != null) {
				feeexample = new StandardChargeExample();

				if (fee_id != null) {
					if (fee_id > 0) {
						feeexample.createCriteria()
								.andStchargeIdEqualTo(fee_id);
					}
				}

				lst = feedao.selectStandardChargeByExample(feeexample);
			} else {
				lst = new LinkedList<StandardCharge>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_get_all_fees"));
		}
		return response;
	}

	public StandardServerResponse getAllPersonStatuses() {
		StandardServerResponse response = new StandardServerResponse();
		List<PersonStatus> lst = null;
		try {
			if (pstatusdao != null) {
				pstatusexample = new PersonStatusExample();
				lst = pstatusdao.selectPersonStatusByExample(pstatusexample);
			} else {
				lst = new LinkedList<PersonStatus>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_get_all_pstatuses"));
		}
		return response;
	}

	public StandardServerResponse getAllCities() {
		StandardServerResponse response = new StandardServerResponse();
		List<City> lst = null;
		try {
			if (citydao != null) {
				cityexample = new CityExample();
				lst = citydao.selectCityByExample(cityexample);
			} else {
				lst = new LinkedList<City>();
			}

			response.setListData(lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_get_all_cities"));
		}
		return response;
	}

	public StandardServerResponse addNewPerson(Person person) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (persondao != null && person != null) {

				persondao.insertPersonSelective(person);
				response.setSuccess(true);

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_add_new_person"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse updatePerson(Person person) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (persondao != null && person != null) {

				persondao.updatePersonByPrimaryKeySelective(person);
				response.setSuccess(true);

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_update_person"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse getPerson(int person_id) {
		StandardServerResponse response = new StandardServerResponse();
		List<Person> p_lst = null;
		try {
			if (persondao != null) {
				personexample = new PersonExample();
				personexample.createCriteria().andPersonIdEqualTo(person_id);

				p_lst = persondao.selectPersonByExample(personexample);
			} else {
				p_lst = new LinkedList<Person>();
			}

			response.setListData(p_lst);
			response.setSuccess(true);
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("get_persons_error"));
		}
		return response;
	}

	public StandardServerResponse addNewHouseUnit(HouseUnit unit) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (hunitdao != null && unit != null) {

				if (!unitNumberExists(unit.getUnitNumber(), unit.getUnitId())) {
					if (!meterNumberExists(unit.getMeterNumber(),
							unit.getUnitId())) {

						hunitdao.insertHouseUnitSelective(unit);
						response.setSuccess(true);
					} else {
						response.setSuccess(false);
						response.setErrorData("Meter Number "
								+ unit.getMeterNumber() + " already exists");
					}
				} else {
					response.setSuccess(false);
					response.setErrorData("Unit Number " + unit.getUnitNumber()
							+ " already exists");
				}
			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_add_new_unit"));
		} finally {
		}
		return response;
	}

	private boolean meterNumberExists(String meterNumber, Integer unit_id) {
		boolean response = false;
		List<HouseUnit> lst = null;
		try {
			if (hunitdao != null) {
				hunitexample = new HouseUnitExample();

				if (meterNumber != null) {
					hunitexample.createCriteria()
							.andMeterNumberLike(meterNumber)
							.andUnitIdNotEqualTo(unit_id == null ? 0 : unit_id);
				}

				lst = hunitdao.selectHouseUnitByExample(hunitexample);

				if (lst != null) {
					if (lst.size() > 0) {
						response = true;
					}
				}
			} else {
				response = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			response = true;
		}
		return response;
	}

	private boolean unitNumberExists(String unitNumber, Integer unit_id) {
		boolean response = false;
		List<HouseUnit> lst = null;
		try {
			if (hunitdao != null) {
				hunitexample = new HouseUnitExample();

				if (unitNumber != null) {
					hunitexample.createCriteria().andUnitNumberLike(unitNumber)
							.andUnitIdNotEqualTo(unit_id == null ? 0 : unit_id);
				}

				lst = hunitdao.selectHouseUnitByExample(hunitexample);

				if (lst != null) {
					if (lst.size() > 0) {
						response = true;
					}
				}
			} else {
				response = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			response = true;
		}
		return response;
	}

	public StandardServerResponse updateHouseUnit(HouseUnit unit) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (hunitdao != null && unit != null) {
				if (!unitNumberExists(unit.getUnitNumber(), unit.getUnitId())) {
					if (!meterNumberExists(unit.getMeterNumber(),
							unit.getUnitId())) {

						hunitdao.updateHouseUnitByPrimaryKeySelective(unit);
						response.setSuccess(true);
					} else {
						response.setSuccess(false);
						response.setErrorData("Meter Number "
								+ unit.getMeterNumber() + " already exists");
					}
				} else {
					response.setSuccess(false);
					response.setErrorData("Unit Number " + unit.getUnitNumber()
							+ " already exists");
				}
			} else {

				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_update_unit"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse updateStandardCharge(StandardCharge fee) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (feedao != null && fee != null) {

				feedao.updateStandardChargeByPrimaryKeySelective(fee);
				response.setSuccess(true);

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_update_fee"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse addNewStandardCharge(StandardCharge fee) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (feedao != null && fee != null) {

				feedao.insertStandardChargeSelective(fee);
				response.setSuccess(true);

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("error_add_new_fee"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse updateWaterCharge(WaterCharge charge) {
		StandardServerResponse response = new StandardServerResponse();

		try {
			if (wchargedao != null && charge != null) {

				wchargedao.updateWaterChargeByPrimaryKeySelective(charge);
				response.setSuccess(true);

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_update_charge"));
		} finally {
		}
		return response;
	}

	public StandardServerResponse addNewWaterCharge(WaterCharge charge) {
		StandardServerResponse response = new StandardServerResponse();
		WaterCharge temp;

		try {
			if (wchargedao != null && charge != null) {

				temp = new WaterCharge();
				temp.setActive(false);
				temp.setModifiedBy(charge.getCreatedBy());
				temp.setModifiedOn(charge.getCreatedOn());

				wchargeexample = new WaterChargeExample();
				wchargeexample.createCriteria().andActiveEqualTo(true);

				if (wchargedao.updateWaterChargeByExampleSelective(temp,
						wchargeexample) > 0) {
					wchargedao.insertWaterChargeSelective(charge);
					response.setSuccess(true);
				} else {
					response.setSuccess(false);
				}

			} else {
				response.setSuccess(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setSuccess(false);
			response.setErrorData(appproperties
					.getString("error_add_new_charge"));
		} finally {
		}
		return response;
	}
}
