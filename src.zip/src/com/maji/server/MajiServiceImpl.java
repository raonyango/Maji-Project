package com.maji.server;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.maji.client.MajiService;
import com.maji.server.spring.GWTSpringController;
import com.maji.server.utils.MajiManager;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterCharge;

/**
 * The server side implementation of the RPC service.
 */
@Controller
@RequestMapping("/**/maji.rpc")
@SuppressWarnings("serial")
public class MajiServiceImpl extends GWTSpringController implements
    MajiService {

	@Autowired
	private MajiManager majimanager;
	
  public String greetServer(String input) throws IllegalArgumentException {
       return "Hello everyone!!";
  }

  /**
   * Escape an html string. Escaping data received from the client helps to
   * prevent cross-site script vulnerabilities.
   * 
   * @param html the html string to escape
   * @return the escaped string
   */
  @SuppressWarnings("unused")
private String escapeHtml(String html) {
    if (html == null) {
      return null;
    }
    return html.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(
        ">", "&gt;");
  }

@Override
public StandardServerResponse authenticateUser(UserLoginData logindata)
		throws IllegalArgumentException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public StandardServerResponse getLoginData() {
	return majimanager.getLoginData(getSession());
}

private HttpSession getSession() {
	// Get the current request and then return its session
	//return this.getThreadLocalRequest().getSession();		
	return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest().getSession();
}

@Override
public StandardServerResponse saveUserSession(UserLoginData logindata) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public StandardServerResponse getUserProfileData(UserLoginData logindata,
		boolean newsession) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public StandardServerResponse validateURL(String url) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public StandardServerResponse getAllPersons() {
	return majimanager.getAllPersons();
}

@Override
public StandardServerResponse getAllBlocks() {
	return majimanager.getAllHouseBlocks();
}

@Override
public StandardServerResponse getAllCharges(Integer charge_id) {
	return majimanager.getAllWaterCharges(charge_id);
}

@Override
public StandardServerResponse getAllHouseUnits(Integer unit_id) {
	return majimanager.getAllHouseUnits(unit_id);
}

@Override
public StandardServerResponse getAllUsers() {
	return majimanager.getAllUsers();
}

@Override
public StandardServerResponse getAllWaterBills(Integer bill_id, Integer house_unit_id, String month, Integer year, Integer status_id) {
	return majimanager.getAllWaterBills(bill_id, house_unit_id, month, year, status_id);
}

@Override
public StandardServerResponse getAllWaterBillStatuses() {
	return majimanager.getAllWaterBillStatuses();
}

@Override
public StandardServerResponse getActiveUnitCharge() {
	return majimanager.getActiveUnitCharge();
}

@Override
public StandardServerResponse getWaterBills(Integer houseunit_id) {
	return majimanager.getWaterBills(houseunit_id);
}

@Override
public StandardServerResponse addNewBill(WaterBill bill) {
	return majimanager.addNewBill(bill);
}

@Override
public StandardServerResponse UpdateBill(WaterBill bill) {
		return majimanager.updateBill(bill);
}

@SuppressWarnings("unchecked")
@Override
public StandardServerResponse printWaterBills(Integer bill_id,
		Integer house_unit_id, String month, Integer year, Integer status_id) {
	StandardServerResponse response = getAllWaterBills(bill_id, house_unit_id, month, year, status_id);
	List<WaterBill> bills;
	
	if (response != null){
		bills = (List<WaterBill>) response.getListData();
		if (bills != null){
			
			return majimanager.printWaterBills(bills,  getThreadLocalRequest());
		}else{
			return response;
		}
	}else{
		response = new StandardServerResponse();
		response.setSuccess(false);
		response.setErrorData(majimanager.getAppproperties().getString("error_printing_bills"));
		
		return response;
	}
	
}

@Override
public StandardServerResponse getAllStandardCharges(Integer fee_id) {
	return majimanager.getAllStandardCharges(fee_id);
}

@Override
public StandardServerResponse getAllPersonStatuses() {
	return majimanager.getAllPersonStatuses();
}

@Override
public StandardServerResponse getAllCities() {
	return majimanager.getAllCities();
}

@Override
public StandardServerResponse addNewPerson(Person person) {
	return majimanager.addNewPerson(person);
}

@Override
public StandardServerResponse updatePerson(Person person) {
	return majimanager.updatePerson(person);
}

@Override
public StandardServerResponse getPerson(int person_id) {
	return majimanager.getPerson(person_id);
}

@Override
public StandardServerResponse addNewHouseUnit(HouseUnit unit) {
	return majimanager.addNewHouseUnit(unit);
}

@Override
public StandardServerResponse updateHouseUnit(HouseUnit unit) {
	return majimanager.updateHouseUnit(unit);
}

@Override
public StandardServerResponse updateStandardCharge(StandardCharge fee) {
	return majimanager.updateStandardCharge(fee);
}

@Override
public StandardServerResponse addNewStandardCharge(StandardCharge fee) {
	return majimanager.addNewStandardCharge(fee);
}

@Override
public StandardServerResponse updateWaterCharge(WaterCharge charge) {
	return majimanager.updateWaterCharge(charge);
}

@Override
public StandardServerResponse addNewWaterCharge(WaterCharge charge) {
	return majimanager.addNewWaterCharge(charge);
}

}
