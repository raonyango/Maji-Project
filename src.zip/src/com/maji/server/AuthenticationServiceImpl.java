package com.maji.server;


import javax.servlet.http.HttpSession;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.maji.client.AuthenticationService;
import com.maji.server.spring.GWTSpringController;
import com.maji.server.utils.MajiManager;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;

@Controller
@RequestMapping("/**/auth.rpc")
@SuppressWarnings("serial")
public class AuthenticationServiceImpl extends GWTSpringController implements AuthenticationService{
	
	@Autowired
	private MajiManager brainupmanager;
	
	@Override
	public StandardServerResponse authenticateUser(UserLoginData logindata) throws IllegalArgumentException {
		return brainupmanager.authenticateUser(logindata, getSession());
	}

	@Override
	public StandardServerResponse checkSession(UserLoginData logindata) {
		return brainupmanager.checkUserSession(logindata, getSession());
	}
	
	@Override
	public StandardServerResponse logoutUser(String username) {
		return brainupmanager.logoutUser(username, getSession());
	}
	
	@Override
	public StandardServerResponse validateURL(String url) {
		return brainupmanager.validateURL(url);
	}

	private HttpSession getSession() {
		// Get the current request and then return its session
		//return this.getThreadLocalRequest().getSession();
		return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest().getSession();
	}
	
	private BeanFactory bf = null;

	private void initSpringFactory() {
		try {
			if (bf == null)
				bf = new FileSystemXmlApplicationContext(
						new String[] { "G:/EclipseWorkspace/maji/war/WEB-INF/spring_config/applicationContext.xml" });

		} catch (BeansException e) {
			e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
		AuthenticationServiceImpl s = new AuthenticationServiceImpl();
		s.initSpringFactory();
		/*MajiManager w = (MajiManager)s.bf.getBean("brainupmanager");
		Domain d = new Domain();
		d.setId(40);
		d.setDomain("http://cube2success.com");
		w.updateDomain(d, 6, 1);*/
	}

	
}
