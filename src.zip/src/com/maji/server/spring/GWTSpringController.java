package com.maji.server.spring;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

@SuppressWarnings("serial")
public class GWTSpringController extends RemoteServiceServlet implements Controller, ServletContextAware, ServletConfigAware {
	private ServletContext servletContext;

    public ModelAndView handleRequest(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        super.doPost(request, response);
        return null;
    }
    
	/**
	 * If the underlying resource throws an {@link AccessDeniedException}, re-throw it in order
	 * for the {@link ExceptionTranslationFilter} to pick it up and convert it to an http response code.
	 */
 	@Override
	protected void doUnexpectedFailure(Throwable e) {
		if (e.getCause() instanceof AccessDeniedException) {
			AccessDeniedException ade = (AccessDeniedException) e.getCause();
			throw ade;
		} else {
			super.doUnexpectedFailure(e);
		}
	}    

    @Override
    public ServletContext getServletContext() {
        return servletContext;
    }

    public void setServletContext(ServletContext servletContext) {
    	this.servletContext = servletContext;
    }

	@Override
	public void setServletConfig(ServletConfig arg0) {
		try {
			super.init(arg0);
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

}