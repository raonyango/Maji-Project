package com.maji.client.place;

public class PlaceTokens {

	public static final String person = "person";
	public static final String status = "status";
	public static final String unit = "unit";
	public static final String registration = "signup";
	public static final String settings = "settings";
	public static final String bill = "bill";
	public static final String login = "login";
	public static final String main = "main";
	public static final String home = "home";
	public static final String help = "help";
	public static final String forgotpassword = "forgotpassword";
	public static final String charge = "charge";
	public static final String editprofile = "editprofile";
	public static final String cancel = "cancel";
	public static final String setup = "setup";
	public static final String users = "users";
	public static final String error = "error";
	public static final String fee="stdcharge";
	public static final String manage= "manage";
	public static final String admin= "admin";

}
