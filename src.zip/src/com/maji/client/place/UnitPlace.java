package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.UnitPresenter;

public class UnitPlace extends ProvidedPresenterPlace<UnitPresenter> {

	public static final String NAME = PlaceTokens.unit;
	
	@Inject
    public UnitPlace(Provider<UnitPresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, UnitPresenter presenter) {
      /*  String user = request.getParameter("user", null);
        if (user != null) {
            presenter.getDisplay().getUserNameValue().setValue(user);
        }*/
    }
}
