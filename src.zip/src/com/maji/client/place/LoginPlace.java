package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.LoginPresenter;

public class LoginPlace extends ProvidedPresenterPlace<LoginPresenter> {

	public static final String NAME = PlaceTokens.login;
	
	@Inject
    public LoginPlace(Provider<LoginPresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, LoginPresenter presenter) {
        String user = request.getParameter("user", null);
        if (user != null) {
            presenter.getDisplay().setUserNameValue(user);
        }
    }
}
