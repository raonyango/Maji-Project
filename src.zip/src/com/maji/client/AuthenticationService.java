package com.maji.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;

/**
 * The client side stub.
 */
@RemoteServiceRelativePath("auth.rpc")
public interface AuthenticationService extends RemoteService {
	StandardServerResponse authenticateUser(UserLoginData logindata)
			throws IllegalArgumentException;

	StandardServerResponse checkSession(UserLoginData logindata);

	StandardServerResponse logoutUser(String username);

	StandardServerResponse validateURL(String url);
	
	//StandardServerResponse resetPassword(ForgotPasswordData data);	
	
	//StandardServerResponse validateCaptcha(String captcha);
	
	//StandardServerResponse checkUsernameAvailability(String username);
}
