package com.maji.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterCharge;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface MajiServiceAsync {
    void greetServer(String input, AsyncCallback<String> callback)
      throws IllegalArgumentException;
  
    void authenticateUser(UserLoginData logindata,
			AsyncCallback<StandardServerResponse> callback)
			throws IllegalArgumentException;
	
	void getLoginData(AsyncCallback<StandardServerResponse> callback);	

	void saveUserSession(UserLoginData logindata,
			AsyncCallback<StandardServerResponse> callback);

	void getUserProfileData(UserLoginData logindata, boolean newsession,
			AsyncCallback<StandardServerResponse> callback);

	void validateURL(String url, AsyncCallback<StandardServerResponse> callback);

	void getAllPersons(AsyncCallback<StandardServerResponse> callback);
	
	void getAllUsers(AsyncCallback<StandardServerResponse> callback);
	
	void getAllHouseUnits(Integer unit_id, AsyncCallback<StandardServerResponse> callback);
	
	void getAllBlocks(AsyncCallback<StandardServerResponse> callback);
	
	void getAllCharges(Integer charge_id, AsyncCallback<StandardServerResponse> callback);
	
	void getAllWaterBills(Integer bill_id, Integer house_unit_id, String month, Integer year, Integer status_id ,AsyncCallback<StandardServerResponse> callback);
	
	void getAllWaterBillStatuses(AsyncCallback<StandardServerResponse> callback);
	
	void getActiveUnitCharge(AsyncCallback<StandardServerResponse> callback);
	
	/*void verifyOldPassword(User user,
			AsyncCallback<StandardServerResponse> callback);*/
	
	/**
	 * Utility class to get the RPC Async interface from client-side code
	 */
	public static final class Util {
		private static MajiServiceAsync instance;

		public static final MajiServiceAsync getInstance() {
			if (instance == null) {
				instance = (MajiServiceAsync) GWT
						.create(MajiService.class);
				ServiceDefTarget target = (ServiceDefTarget) instance;
				target.setServiceEntryPoint(GWT.getModuleBaseURL()
						+ "brainup.rpc");
			}
			return instance;
		}

		private Util() {
			// Utility class should not be instanciated
		}
	}

	void getWaterBills(Integer houseunit_id,
			AsyncCallback<StandardServerResponse> callback);

	void addNewBill(WaterBill bill,AsyncCallback<StandardServerResponse> callback);

	void UpdateBill(WaterBill bill,	AsyncCallback<StandardServerResponse> callback);

	void printWaterBills(Integer bill_id, Integer house_unit_id, String month, Integer year, Integer status_id,
			AsyncCallback<StandardServerResponse> callback);

	void getAllStandardCharges(Integer fee_id, AsyncCallback<StandardServerResponse> callback);

	void getAllPersonStatuses(AsyncCallback<StandardServerResponse> callback);

	void getAllCities(AsyncCallback<StandardServerResponse> callback);

	void updatePerson(Person person,
			AsyncCallback<StandardServerResponse> callback);

	void addNewPerson(Person person,
			AsyncCallback<StandardServerResponse> callback);

	void getPerson(int person_id,
			AsyncCallback<StandardServerResponse> callback);

	void addNewHouseUnit(
			HouseUnit unit, AsyncCallback<StandardServerResponse> callback);

	void updateHouseUnit(
			HouseUnit unit, AsyncCallback<StandardServerResponse> callback);

	void updateStandardCharge(
			StandardCharge fee,	AsyncCallback<StandardServerResponse> callback);

	void addNewStandardCharge(
			StandardCharge fee,AsyncCallback<StandardServerResponse> callback);

	void updateWaterCharge(
			WaterCharge charge,
			AsyncCallback<StandardServerResponse> callback);

	void addNewWaterCharge(
			WaterCharge charge,
			AsyncCallback<StandardServerResponse> callback);

	
}
