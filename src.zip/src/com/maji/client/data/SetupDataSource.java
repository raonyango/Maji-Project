package com.maji.client.data;

import com.maji.client.place.PlaceTokens;


public class SetupDataSource extends NavigationPaneSectionDataSource {

	public static final String DEFAULT_RECORD_NAME = PlaceTokens.setup;

	private static final String DATA_SOURCE = "SetupDs";
	private static final String URL_PREFIX = "datasource/data/SetupDs";
	private static final String URL_SUFFIX = ".xml";

	private static SetupDataSource instance;

	public static SetupDataSource getInstance() {
		if (instance == null) {
			instance = new SetupDataSource(DATA_SOURCE);
		}

		return instance;
	}

	public SetupDataSource(String id) {
		super(id);
		setDataURL(URL_PREFIX, URL_SUFFIX);
	}
}
