package com.maji.client.data;

import com.maji.client.place.PlaceTokens;


public class AdminDataSource extends NavigationPaneSectionDataSource {

	public static final String DEFAULT_RECORD_NAME = PlaceTokens.admin;

	private static final String DATA_SOURCE = "AdminDs";
	private static final String URL_PREFIX = "datasource/data/AdminDs";
	private static final String URL_SUFFIX = ".xml";

	private static AdminDataSource instance;

	public static AdminDataSource getInstance() {
		if (instance == null) {
			instance = new AdminDataSource(DATA_SOURCE);
		}

		return instance;
	}

	public AdminDataSource(String id) {
		super(id);
		setDataURL(URL_PREFIX, URL_SUFFIX);
	}
}
