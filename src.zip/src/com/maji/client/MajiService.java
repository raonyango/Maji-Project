package com.maji.client;

import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.google.gwt.user.client.rpc.ServiceDefTarget;
import com.maji.server.security.XSRFAttackFilter;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterCharge;

/**
 * The client side stub for the RPC service.
 */
@RemoteServiceRelativePath("maji.rpc")
public interface MajiService extends RemoteService {
 
	String greetServer(String name) throws IllegalArgumentException;
  
	StandardServerResponse authenticateUser(UserLoginData logindata)
			throws IllegalArgumentException;
	
	StandardServerResponse getLoginData();
	
	StandardServerResponse saveUserSession(UserLoginData logindata);

	StandardServerResponse getUserProfileData(UserLoginData logindata,
			boolean newsession);

	
	StandardServerResponse validateURL(String url);

	StandardServerResponse getAllPersons();
	
	StandardServerResponse getAllUsers();
	
	StandardServerResponse getAllHouseUnits(Integer unit_id);
	
	StandardServerResponse getAllBlocks();
	
	StandardServerResponse getAllCharges(Integer charge_id);
	
	StandardServerResponse getAllWaterBills(Integer bill_id, Integer house_unit_id, String month, Integer year, Integer status_id );
	
	StandardServerResponse getAllWaterBillStatuses();
	
	StandardServerResponse getActiveUnitCharge();
	
	StandardServerResponse getWaterBills(Integer houseunit_id);
	
	StandardServerResponse addNewBill(WaterBill bill);
	
	StandardServerResponse UpdateBill(WaterBill bill);
	//StandardServerResponse verifyOldPassword(User user);

	StandardServerResponse printWaterBills(Integer bill_id, Integer house_unit_id, String month, Integer year, Integer status_id );
	
	StandardServerResponse getAllStandardCharges(Integer fee_id);
	
	StandardServerResponse getAllPersonStatuses();
	
	StandardServerResponse getAllCities();
	
	StandardServerResponse addNewPerson(Person person);
	
	StandardServerResponse updatePerson(Person person);
	
	StandardServerResponse getPerson(int person_id);
	
	StandardServerResponse addNewHouseUnit(HouseUnit unit);
	
	StandardServerResponse updateHouseUnit(HouseUnit unit);
	
	StandardServerResponse updateStandardCharge(StandardCharge fee);

	StandardServerResponse addNewStandardCharge(StandardCharge fee);
			
	StandardServerResponse updateWaterCharge(WaterCharge charge);

	StandardServerResponse addNewWaterCharge(WaterCharge charge);
			
	/**
	 * Utility class to get the RPC Async interface from client-side code, with
	 * the improved duplication of session cookie information.
	 * 
	 * To be used in conjunction with the {@link XSRFAttackFilter}.
	 */
	public static final class SecureUtil {
		private static String entrypoint = null;

		public static final MajiServiceAsync getInstance() {
			MajiServiceAsync instance = MajiServiceAsync.Util
					.getInstance();
			ServiceDefTarget target = (ServiceDefTarget) instance;

			if (entrypoint == null) {
				entrypoint = target.getServiceEntryPoint();
			}

			target.setServiceEntryPoint(entrypoint + "?JSESSIONID="
					+ Cookies.getCookie("JSESSIONID"));
			return instance;
		}

		private SecureUtil() {
			// Not to be instantiated
		}
	}
}
