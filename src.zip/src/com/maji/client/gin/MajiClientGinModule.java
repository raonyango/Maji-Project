package com.maji.client.gin;

import net.customware.gwt.presenter.client.DefaultEventBus;
import net.customware.gwt.presenter.client.gin.AbstractPresenterModule;
import net.customware.gwt.presenter.client.place.ParameterTokenFormatter;
import net.customware.gwt.presenter.client.place.PlaceManager;
import net.customware.gwt.presenter.client.place.TokenFormatter;

import com.google.inject.Singleton;
import com.maji.client.place.BillPlace;
import com.maji.client.place.ChargePlace;
import com.maji.client.place.ErrorPlace;
import com.maji.client.place.FeePlace;
import com.maji.client.place.HomePlace;
import com.maji.client.place.LoginPlace;
import com.maji.client.place.MainPlace;
import com.maji.client.place.MajiPlaceManager;
import com.maji.client.place.PersonPlace;
import com.maji.client.place.UnitPlace;
import com.maji.client.presenter.BillPresenter;
import com.maji.client.presenter.ChargePresenter;
import com.maji.client.presenter.ErrorPresenter;
import com.maji.client.presenter.FeePresenter;
import com.maji.client.presenter.HomePresenter;
import com.maji.client.presenter.LoginPresenter;
import com.maji.client.presenter.MainPresenter;
import com.maji.client.presenter.PersonPresenter;
import com.maji.client.presenter.UnitPresenter;
import com.maji.client.utils.ClientUtils;
import com.maji.client.view.BillView;
import com.maji.client.view.ChargeView;
import com.maji.client.view.ErrorView;
import com.maji.client.view.FeeView;
import com.maji.client.view.HomeView;
import com.maji.client.view.LoginView;
import com.maji.client.view.MainView;
import com.maji.client.view.PersonView;
import com.maji.client.view.UnitView;

public class MajiClientGinModule extends AbstractPresenterModule {

	@Override
	protected void configure() {		
		bind(PlaceManager.class).to(MajiPlaceManager.class).in(Singleton.class);
		bind(TokenFormatter.class).to(ParameterTokenFormatter.class);
				
		bind(net.customware.gwt.presenter.client.EventBus.class).to(DefaultEventBus.class).in(Singleton.class);
		bind(ClientUtils.class).in(Singleton.class);
		
		bindPresenter(MainPresenter.class, MainPresenter.IMainViewDisplay.class, MainView.class);		
		bindPresenter(LoginPresenter.class,LoginPresenter.ILoginViewDisplay.class, LoginView.class);
		//bindPresenter(ForgotPasswordPresenter.class,ForgotPasswordPresenter.IForgotPasswordViewDisplay.class, ForgotPasswordView.class);
		bindPresenter(HomePresenter.class, HomePresenter.IHomeViewDisplay.class, HomeView.class);
		bindPresenter(PersonPresenter.class, PersonPresenter.IPersonViewDisplay.class, PersonView.class);
		bindPresenter(UnitPresenter.class, UnitPresenter.IUnitViewDisplay.class, UnitView.class);
		bindPresenter(ChargePresenter.class, ChargePresenter.IChargeViewDisplay.class, ChargeView.class);
		bindPresenter(ErrorPresenter.class, ErrorPresenter.IErrorViewDisplay.class, ErrorView.class);		
		bindPresenter(BillPresenter.class, BillPresenter.IBillViewDisplay.class, BillView.class);
		bindPresenter(FeePresenter.class, FeePresenter.IFeeViewDisplay.class, FeeView.class);
		
		bind(MainPlace.class).in(Singleton.class);
		bind(LoginPlace.class).in(Singleton.class);
		//bind(ForgotPasswordPlace.class).in(Singleton.class);        
        bind(HomePlace.class).in(Singleton.class);
        bind(PersonPlace.class).in(Singleton.class);
        bind(ErrorPlace.class).in(Singleton.class);
        bind(UnitPlace.class).in(Singleton.class);
        bind(ChargePlace.class).in(Singleton.class);
        bind(BillPlace.class).in(Singleton.class);
        bind(FeePlace.class).in(Singleton.class);
        
        //bind(EventBus.class).to(SimpleEventBus.class).in(Singleton.class);
		//bind(BrainupPlaceFactory.class).in(Singleton.class);
		//bind(ActivityMapper.class).to(BrainupActivityMapper.class).in(Singleton.class);
		//bind(PlaceController.class).to(InjectablePlaceController.class);
		//bind(BrainupServiceAsync.class);		
		//bind(AppController.class).in(Singleton.class);		
	}
}
