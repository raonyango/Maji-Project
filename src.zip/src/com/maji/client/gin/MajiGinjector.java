package com.maji.client.gin;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.place.PlaceManager;

import com.google.gwt.inject.client.GinModules;
import com.google.gwt.inject.client.Ginjector;
import com.maji.client.AuthenticationServiceAsync;
import com.maji.client.MajiServiceAsync;
import com.maji.client.presenter.HomePresenter;
import com.maji.client.presenter.LoginPresenter;
import com.maji.client.presenter.PersonPresenter;
import com.maji.client.utils.ClientUtils;
import com.maji.shared.properties.MajiStrings;

@GinModules(MajiClientGinModule.class)
public interface MajiGinjector extends Ginjector {
	EventBus getEventBus();
	//BrainupPlaceFactory getPlaceFactory();
	//ActivityMapper getActivityMapper();
	//PlaceController getPlaceController();	
	
	MajiStrings getMajiConstants();	
	PlaceManager getPlaceManager();
		
	LoginPresenter getLoginPresenter();
	HomePresenter getHomePresenter();
	PersonPresenter getPersonPresenter();
	MajiServiceAsync getMajiService();
	ClientUtils getClientUtils();

	AuthenticationServiceAsync getAuthenticationService();
	
}
