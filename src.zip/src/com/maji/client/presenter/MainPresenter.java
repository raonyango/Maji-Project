package com.maji.client.presenter;

import net.customware.gwt.presenter.client.EventBus;

import com.google.gwt.event.logical.shared.AttachEvent;
import com.google.gwt.event.logical.shared.AttachEvent.Handler;
import com.google.inject.Inject;
import com.maji.client.event.ExpandEvent;
import com.maji.client.event.ExpandEventHandler;
import com.maji.client.event.LoginSuccessEvent;
import com.maji.client.event.LoginSuccessEventHandler;
import com.maji.client.event.LogoutEvent;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.place.PlaceTokens;
import com.maji.client.utils.ClientUtils;
import com.maji.client.view.uihandlers.HasUiHandlers;
import com.maji.client.view.uihandlers.MainViewUiHandlers;
import com.maji.client.widgets.NavigationPane;
import com.maji.client.widgets.NavigationPaneHeader;
import com.maji.client.widgets.WidgetContainerPresenter;
import com.maji.client.widgets.interfaces.WidgetContainerDisplay;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.widgets.layout.Layout;

public class MainPresenter extends
		WidgetContainerPresenter<MainPresenter.IMainViewDisplay> implements MainViewUiHandlers{

	public static final Object contextareacontent = "contextareacontent";
	private IMainViewDisplay display;
	private EventBus eventbus;
	private int presenterwidth, presenterheight;
	private PersonPresenter personpresenter;
	private UnitPresenter unitpresenter;
	private BillPresenter billpresenter;
	private UserLoginData logindata;
	private MajiStrings constants;
	private ErrorPresenter errorpresenter;
	private ClientUtils clientutils;
	private ChargePresenter chargepresenter;
	private FeePresenter feepresenter;
	
	public int getPresenterheight() {
		return presenterheight;
	}

	public void setPresenterheight(int presenterheight) {
		this.presenterheight = presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	public void setPresenterwidth(int presenterwidth) {
		setChildPresenterDimensions(presenterwidth, presenterheight);
		this.presenterwidth = presenterwidth;
	}

	public UserLoginData getLogindata() {
		return logindata;
	}

	public void setLogindata(UserLoginData logindata) {
		this.logindata = logindata;
	}

	@Inject
	public MainPresenter(MajiStrings constants, EventBus eventbus, ClientUtils clientutils, 
			IMainViewDisplay display, PersonPresenter ipersonpresenter,UnitPresenter iunitpresenter, 
			ChargePresenter ichargepresenter, BillPresenter ibillpresenter, FeePresenter ifeepresenter, ErrorPresenter errorpresenter) {
		
		super(display, eventbus, ipersonpresenter, iunitpresenter, ichargepresenter, 
				ibillpresenter,ifeepresenter,errorpresenter);
		
		this.constants = constants;
		this.display = display;
		this.eventbus = eventbus;
		this.clientutils = clientutils;
		this.personpresenter = ipersonpresenter;
		this.errorpresenter = errorpresenter;
		this.unitpresenter = iunitpresenter;
		this.chargepresenter = ichargepresenter;
		this.billpresenter = ibillpresenter;
		this.feepresenter = ifeepresenter;
		
		display.setUiHandlers(this);
	}

	public interface IMainViewDisplay extends WidgetContainerDisplay, HasUiHandlers<MainViewUiHandlers> {
		NavigationPaneHeader getNavigationPaneHeader();
		
		NavigationPane getNavigationPane();
		    
		Layout asWidget();

		void setSignedinUserdata(UserLoginData userdata);

		void setContextHeaderLabel(String text);

		void selectNavigationPaneRecord(String place);
	}

	@Override
	protected void onBind() {
		super.onBind();
		//----display.getNavigationPane().expandSection(constants.status_tab());
			
		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {
			
			@Override
			public void onRefreshApplication(RefreshEvent event) {
				logindata = event.getLogindata();
				display.setSignedinUserdata(logindata);			
			}
		});	
		
		eventbus.addHandler(LoginSuccessEvent.TYPE,
				new LoginSuccessEventHandler() {

			@Override
			public void onLoginSuccess(LoginSuccessEvent event) {
				//logindata = event.getUser();
				display.setSignedinUserdata(event.getUser());
			}
		});	
		
		eventbus.addHandler(ExpandEvent.TYPE, new ExpandEventHandler() {
			
			@Override
			public void onExpandService(ExpandEvent event) {
				/*if(!expandpresenter.isBound())
					expandpresenter.bind();
				if(logindata != null){
					display.setContextHeaderLabel(clientutils.getPlaceLabel(PlaceTokens.expand));
					display.selectNavigationPaneRecord(PlaceTokens.expand);
					expandpresenter.revealDisplay(logindata);
				}*/
			}
		});
		
		/*eventbus.addHandler(UserAccountEvent.TYPE, new UserAccountEventHandler() {

			@Override
			public void onShowAccount(UserAccountEvent event) {
				if(logindata == null)
					logindata = event.getUser();
				display.setSignedinUserdata(event.getUser());
			}

		});*/
		
		display.asWidget().addAttachHandler(new Handler() {
			
			@Override
			public void onAttachOrDetach(AttachEvent event) {
				//Log.info("attach handler called......................");
				setChildPresenterDimensions(presenterwidth, presenterheight);
			}
		});	
		
	}
		
	public void revealDisplay(UserLoginData logindata) {
		this.logindata = logindata;
		selectPresenter(PlaceTokens.main);
		display.setContextHeaderLabel(constants.bill_tab());
		
		revealDisplay();
	}
	
	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub

	}
	
	private void setChildPresenterDimensions(int width, int height){
		width = (width - display.getNavigationPane().getOffsetWidth());
		height = (height - display.getNavigationPane().getOffsetHeight());
		personpresenter.setPresenterDimensions(height, width);
		chargepresenter.setPresenterDimensions(height, width);
		billpresenter.setPresenterDimensions(height, width);
		unitpresenter.setPresenterDimensions(height, width);
		feepresenter.setPresenterDimensions(height, width);
	}

	@Override
	public void onNavigationPaneSectionClicked(String place) {
		selectPresenter(place);
	}

	@Override
	public void onNavigationPaneSectionHeaderClicked(String place) {
		selectPresenter(place);	
	}
	
	private void selectPresenter(String place){
		if(place.trim().length() != 0){
			if (place.trim().length() != 0) {
		        if ((place.equals(PlaceTokens.person))) {
		        	if(logindata != null){
		        		personpresenter.revealDisplay(logindata);	
		        	}
				}else if (place.equals(PlaceTokens.unit)) {		
					if(logindata != null){
						unitpresenter.revealDisplay(logindata);
					}						
				}else if (place.equals(PlaceTokens.charge)) {		
					if(logindata != null){
						chargepresenter.revealDisplay(logindata);
					}							
				}else if(place.equals(PlaceTokens.fee)){
					if(logindata != null){
						feepresenter.revealDisplay(logindata);
					}
				}else if(place.equals(PlaceTokens.bill) || (place.equals(PlaceTokens.main))){
					if(logindata != null){
						billpresenter.revealDisplay(logindata);
					}
				}else{
					errorpresenter.revealDisplay(false);
				}
				//revealDisplay();
		    }
	    }
	}

	@Override
	public void onLogoutButtonClicked() {
		if(logindata != null)
			eventbus.fireEvent(new LogoutEvent(logindata));
	}

}
