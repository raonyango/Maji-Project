package com.maji.client.presenter;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.History;
import com.google.inject.Inject;
import com.maji.client.AutoErrorHandlingAsyncCallback;
import com.maji.client.MajiServiceAsync;
import com.maji.client.event.FlashEvent;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.SessionExpireEvent;
import com.maji.client.event.SessionExpireEventHandler;
import com.maji.client.view.uihandlers.FeeViewUiHandlers;
import com.maji.client.view.uihandlers.HasUiHandlers;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.WidgetPresenter;
import com.maji.client.widgets.interfaces.WidgetDisplay;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.layout.Layout;

public class FeePresenter extends WidgetPresenter<FeePresenter.IFeeViewDisplay>
		implements FeeViewUiHandlers {

	private MajiStrings constants;
	private IFeeViewDisplay display;
	private MajiServiceAsync rpcservice;
	private EventBus eventbus;
	private UserLoginData userdata;

	private int presenterwidth, presenterheight;
	private int maxresults;
	@SuppressWarnings("unused")
	private int firstresult;
	private int pagenumber;
	private int numberofelements;

	// private boolean allservices_loaded, alladdons_loaded,
	// userservices_loaded, useraddons_loaded;
	private List<StandardCharge> fee_dtos;// , addon_dtos;

	public int getPresenterheight() {
		return presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	public void setPresenterDimensions(int presenterheight, int presenterwidth) {
		this.presenterheight = presenterheight;
		this.presenterwidth = presenterwidth;
	}

	@Inject
	public FeePresenter(MajiStrings constants, EventBus eventbus,
			IFeeViewDisplay display, MajiServiceAsync rpcService) {
		super(display, eventbus);
		this.display = display;
		rpcservice = rpcService;
		this.eventbus = eventbus;
		this.constants = constants;

		display.setUiHandlers(this);
	}

	public interface IFeeViewDisplay extends WidgetDisplay,
			HasUiHandlers<FeeViewUiHandlers> {

		Layout asWidget();

		void setPageNumber(int pagenumber);

		void setNumberSelected(int numberselected);

		void refreshStatusBar();

		void setResultSet(List<StandardCharge> resultset);

		void setNumberOfElements(int numberofelements);

		StatusBar getStatusBar();

		void setSaveNewSuccess();

		void setFeeDetails(StandardCharge fee);

		void setUpdateSuccess();

		void setSaveNewError(String title, String msg);

		void setUpdateError(String title, String msg);
	}

	public void revealDisplay(UserLoginData userdata) {
		this.userdata = userdata;
		if (fee_dtos == null) {
			retrieveGridRecords();
		} else {
			displayGridRecords();
		}

		revealDisplay();
	}

	@Override
	protected void onBind() {
		maxresults = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		firstresult = 0;
		pagenumber = 1;
		numberofelements = maxresults;

		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {

			@Override
			public void onRefreshApplication(RefreshEvent event) {
				if (History.getToken().trim().equals("")
						|| History.getToken().trim().equals("main")) {
					revealDisplay(event.getLogindata());
				}
			}
		});

		eventbus.addHandler(SessionExpireEvent.TYPE,
				new SessionExpireEventHandler() {

					public void onSessionExpireEvent(SessionExpireEvent event) {
						eventbus.fireEvent(new FlashEvent(constants
								.session_timed_out(), 4000));
					}

				});
	}

	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub
	}

	protected void retrieveGridRecords() {
		getAllStandardCharges();
	}

	protected void displayGridRecords() {
		try {
			if (fee_dtos != null)
				numberofelements = fee_dtos.size();

			// update Selected label e.g "0 of 50 selected"
			display.setNumberOfElements(numberofelements);
			display.setPageNumber(pagenumber);
			display.refreshStatusBar();

			// Log.debug("onSuccess() - firstResult: " + firstresult +
			// " pageNumber: " + pagenumber + " numberOfElements: " +
			// numberofelements);

			// enable/disable the pagination widgets
			if (pagenumber == 1) {
				display.getStatusBar().getResultSetFirstButton().disable();
				display.getStatusBar().getResultSetPreviousButton().disable();
			}

			// enable/disable the pagination widgets
			if (numberofelements < maxresults) {
				display.getStatusBar().getResultSetNextButton().disable();
			} else {
				display.getStatusBar().getResultSetNextButton().enable();
			}

			// pass the result set to the View
			if (fee_dtos != null)
				display.setResultSet(fee_dtos);
		} catch (Exception e) {
			Log.error(e.getLocalizedMessage(), e);
		}
	}

	@Override
	public void onRecordDoubleClicked(int recordId) {
		getStandardCharge(recordId);
	}

	@Override
	public void onResultSetFirstButtonClicked() {
		firstresult = 0;
		pagenumber = 1;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetNextButtonClicked() {
		firstresult += numberofelements;
		pagenumber++;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetPreviousButtonClicked() {
		firstresult -= maxresults;
		pagenumber--;

		retrieveGridRecords();
	}

	@Override
	public void onRefreshButtonClicked() {
		retrieveGridRecords();
	}

	protected void getAllStandardCharges() {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getAllStandardCharges(
								null,
								new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
										eventbus, this, constants) {

									@SuppressWarnings("unchecked")
									@Override
									public void onSuccess(
											StandardServerResponse response) {

										if (response != null) {
											if (response.isSuccess()) {
												numberofelements = response
														.getIntegerData();
												if (response.getListData() != null) {
													fee_dtos = (List<StandardCharge>) response
															.getListData();
												}
											} else {
												SC.say(constants.app_error(),
														constants
																.error_get_all_fees()
																+ (response
																		.getErrorData() == null ? ""
																		: " "
																				+ response
																						.getErrorData()));
												return;
											}
										} else {
											SC.say(constants.app_error(),
													constants
															.error_get_all_fees());
											return;
										}
										// allservices_loaded = true;
										if (fee_dtos != null) {
											displayGridRecords();
										}
									}

								});
			}
		};

		cmd.execute();
	}

	@Override
	public void onNewButtonClicked() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSaveNewButtonClicked(final StandardCharge fee) {
		fee.setCreatedBy(userdata.getUserId());

		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.addNewStandardCharge(
								fee,
								new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
										eventbus, this, constants) {

									@Override
									public void onSuccess(
											StandardServerResponse response) {

										if (response != null) {
											if (response.isSuccess()) {

												display.setSaveNewSuccess();
												onRefreshButtonClicked();
											} else {
												display.setSaveNewError(
														constants.app_error(),
														(response
																.getErrorData() == null ? constants
																.error_add_new_fee()
																: " "
																		+ response
																				.getErrorData()));
												return;
											}
										} else {
											display.setSaveNewError(constants
													.app_error(), constants
													.error_add_new_fee());
											return;
										}
									}

								});
			}
		};

		cmd.execute();
	}

	@Override
	public void onUpdateButtonClicked(final StandardCharge fee) {
		fee.setModifiedBy(userdata.getUserId());

		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.updateStandardCharge(
								fee,
								new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
										eventbus, this, constants) {

									@Override
									public void onSuccess(
											StandardServerResponse response) {

										if (response != null) {
											if (response.isSuccess()) {

												display.setUpdateSuccess();
												onRefreshButtonClicked();
											} else {
												display.setUpdateError(
														constants.app_error(),
														(response
																.getErrorData() == null ? constants
																.error_update_fee()
																: " "
																		+ response
																				.getErrorData()));
												getStandardCharge(fee
														.getStchargeId());
												return;
											}
										} else {
											display.setUpdateError(constants
													.app_error(), constants
													.error_update_fee());
											getStandardCharge(fee
													.getStchargeId());
											return;
										}
									}

								});
			}
		};

		cmd.execute();
	}

	private void getStandardCharge(final Integer fee_id) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getAllStandardCharges(
								fee_id,
								new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
										eventbus, this, constants) {

									@Override
									public void onSuccess(
											StandardServerResponse response) {

										if (response != null) {
											if (response.isSuccess()) {
												if (response.getListData() != null) {
													if (response.getListData()
															.size() > 0) {
														display.setFeeDetails((StandardCharge) response
																.getListData()
																.get(0));
													}
												}
											} else {
												SC.say(constants.app_error(),
														(response
																.getErrorData() == null ? constants
																.error_get_all_fees()
																: " "
																		+ response
																				.getErrorData()));
												return;
											}
										} else {
											SC.say(constants.app_error(),
													constants
															.error_get_all_fees());
											return;
										}
									}

								});
			}
		};

		cmd.execute();
	}
}
