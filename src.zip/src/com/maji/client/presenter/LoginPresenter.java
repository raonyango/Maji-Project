package com.maji.client.presenter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.core.client.GWT;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
//import com.allen_sauer.gwt.log.client.Log;
import com.maji.client.AutoErrorHandlingAsyncCallback;
import com.maji.client.MajiServiceAsync;
import com.maji.client.event.ErrorEvent;
import com.maji.client.event.FlashEvent;
import com.maji.client.event.LoginErrorEvent;
import com.maji.client.event.LoginErrorEventHandler;
import com.maji.client.event.LoginSuccessEvent;
import com.maji.client.event.SessionExpireEvent;
import com.maji.client.event.SessionExpireEventHandler;
import com.maji.client.event.UserAccountEvent;
import com.maji.client.place.PlaceTokens;
import com.maji.client.utils.ClientUtils;
import com.maji.client.view.uihandlers.HasUiHandlers;
import com.maji.client.view.uihandlers.LoginViewUiHandlers;
import com.maji.client.widgets.WidgetPresenter;
import com.maji.client.widgets.interfaces.WidgetDisplay;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.layout.Layout;

public class LoginPresenter extends
		WidgetPresenter<LoginPresenter.ILoginViewDisplay> implements LoginViewUiHandlers{

	private int minUsernameLength = 1;
	private int minPasswordLength = 1;
	private ILoginViewDisplay display;
	private MajiServiceAsync rpcservice;
	private MajiStrings constants;
	// private DispatchAsync dispatcher;
	private EventBus eventbus;
	private List<Command> commandsqueue = null;
	private String savedhtoken = "";


	@Inject
	public LoginPresenter(ClientUtils clientutils, MajiStrings constants,
			EventBus eventBus, ILoginViewDisplay display,
			MajiServiceAsync rpcService) {
		super(display, eventBus);
		this.display = display;
		rpcservice = rpcService;
		this.constants = constants;
		this.eventbus = eventBus;
		display.setUiHandlers(this);
	
	}

	public interface ILoginViewDisplay extends WidgetDisplay, HasUiHandlers<LoginViewUiHandlers> {
		
		Boolean getRememberMeValue();		

		void setLoading(boolean loading);		

		void setRememberMeValue(boolean value);

		void setLoginstatuslbl(String value, boolean iserror);

		String getUserNameValue();

		String getPasswordValue();

		void setPasswordValue(String value);

		void setUserNameValue(String value);

		void setFocusUserNameTxt(boolean focus);

		void showCloseDialog(boolean show);

		void showDialogBox(boolean show);

		void addPasswordStyle(String stylename);

		void removePasswordStyle(String stylename);

		void addUserNameStyle(String stylename);

		void removeUserNameStyle(String stylename);

		void reset();

		void onAttach();
		
		Layout asWidget();

	}

	@Override
	public void onBind() {
		//Log.debug("LoginPresenter:onBind()");
		display.setLoginstatuslbl(null, false);
		display.onAttach();		
		eventbus.addHandler(SessionExpireEvent.TYPE,
				new SessionExpireEventHandler() {

					public void onSessionExpireEvent(SessionExpireEvent event) {
						eventbus.fireEvent(new FlashEvent(constants
								.session_timed_out(), 4000));
					}

				});
		
		eventbus.addHandler(LoginErrorEvent.TYPE, new LoginErrorEventHandler() {

			@Override
			public void onNewError(LoginErrorEvent event) {
				if (event.getErrorMessage() != null)
					if (!event.getErrorMessage().trim().equals(""))
						display.setLoginstatuslbl(
								event.getErrorMessage(), true);
			}
		});	
		
	}

	public void revealDisplay(String username, Command command) {
		if (username != null)
			display.setUserNameValue(username);
		
		if (command == null){
			revealDisplay();
		}else {
			if(commandsqueue == null)
				commandsqueue = new ArrayList<Command>();
			commandsqueue.add(command);
			
			if(!History.getToken().trim().equals(PlaceTokens.login)){
				savedhtoken = History.getToken().trim();
				revealDisplay();
			}	
			display.setLoginstatuslbl(constants.session_expired_info(), false);
		}
	}

	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub
	}

	private void rememberUserLogin(String sessionid) {
		final long DURATION;
		Date expires;

		try {
			DURATION = 1000 * 60 * 60 * 24 * 14; // duration to remember login: 2 weeks.
			expires = new Date(System.currentTimeMillis() + DURATION);
			Cookies.setCookie(MajiConstants.USER_SESS_ID, sessionid,
					expires, null, "/", false); // TODO change to true when
												// https is set up
		} catch (Exception e) {
			eventbus.fireEvent(new ErrorEvent(constants.error(), constants
					.err_remember_user_login()));
		} finally {
			expires = null;
		}
	}

	@SuppressWarnings("unused")
	private void loginUser(final String username, final String password, final boolean rememberme) {
		// validate login form
		if (!validateUserInput(username, password))
			return;

		// validate credentials
		UserLoginData data = new UserLoginData();
		data.setUsername(username);
		data.setPassword(password);
		data.setRememberlogin(rememberme);
		//data.setRole(1);

		display.setLoading(true);
		rpcservice.authenticateUser(data,
				new AsyncCallback<StandardServerResponse>() {

					@Override
					public void onFailure(Throwable caught) {
						display.setLoading(false);
						eventbus.fireEvent(new FlashEvent(constants
								.err_login_user()
								+ ":" + caught.getMessage(), 4000));
						display.reset();
					}

					@Override
					public void onSuccess(StandardServerResponse response) {
						if (response.isSuccess()) {
							if (response.getListData() != null) {
								if (response.getListData().size() > 0) {
									if (response.getListData() != null) {
										if (response.getListData().size() > 0) {
											if (((UserLoginData) response.getListData().get(0)).isAuthenticated()) {
												if (rememberme == true)
													rememberUserLogin(((UserLoginData) response
															.getListData().get(0)).getSessionid());
												eventbus.fireEvent(new UserAccountEvent(
																(UserLoginData) response.getListData().get(0)));
											}
										}
									}
									display.reset();
								} else {
									// invalid credentials
									if (!response.getStringData().equals(null)) {
										if (!response.getStringData().trim()
												.equals("")) {
											eventbus
													.fireEvent(new LoginErrorEvent(
															response.getStringData()));
										} else {
											eventbus
													.fireEvent(new LoginErrorEvent(
															constants.invalid_login()));
										}
									} else {
										eventbus.fireEvent(new LoginErrorEvent(
												constants.invalid_login()));
									}
								}
							} else {
								// invalid credentials
								if (!response.getStringData().equals(null)) {
									if (!response.getStringData().trim()
											.equals("")) {
										eventbus.fireEvent(new LoginErrorEvent(
												response.getStringData()));
									} else {
										eventbus.fireEvent(new LoginErrorEvent(
												constants.invalid_login()));
									}
								} else {
									eventbus.fireEvent(new LoginErrorEvent(
											constants.invalid_login()));
								}
							}
						} else {
							eventbus.fireEvent(new LoginErrorEvent(constants
									.error()
									+ ": " + response.getErrorData()));
						}
						display.setLoading(false);
					}
				});
	}

	private void loginUserWithSpringSecurity(final String username, final String password, final boolean rememberme) {
		// validate login form
		if (!validateUserInput(username, password))
			return;

		// validate credentials
		final UserLoginData data = new UserLoginData();
		data.setUsername(username);
		data.setPassword(password);
		data.setRememberlogin(rememberme);
		//data.setRole("ROLE_USER");

		RequestBuilder rb = new RequestBuilder(RequestBuilder.POST, GWT
				.getHostPageBaseURL()
				+ "j_spring_security_check");
		rb.setHeader("Content-Type", "application/x-www-form-urlencoded");
		rb.setRequestData("j_username="	+ URL.encode(username)
						+ "&j_password=" + URL.encode(password)
						+ "&_spring_security_remember_me=" + rememberme);

		rb.setCallback(new RequestCallback() {
			public void onError(Request request, Throwable exception) {
				// eventbus.fireEvent(new ErrorEvent(constants.error(),
				// constants.err_login_user()));
				display.setLoginstatuslbl(constants.err_login_user(), true);
			}

			public void onResponseReceived(Request request, Response response) {
				if (response.getStatusCode() == 200) {
					String previousuname;
					try{
						if (rememberme == true)
							if(response.getHeader("JSESSIONID") != null)
								rememberUserLogin(response.getHeader("JSESSIONID"));
						//remember username
						previousuname = Cookies.getCookie(MajiConstants.USERNAME_COOKIE);
						if(previousuname != null){
							if(!username.trim().equalsIgnoreCase(previousuname.trim()))
								Cookies.setCookie(MajiConstants.USERNAME_COOKIE, username.trim().toLowerCase()); 
						}else{
							Cookies.setCookie(MajiConstants.USERNAME_COOKIE, username.trim().toLowerCase()); 
						}
						
						getLoginDetails(previousuname);
					}catch (Exception e) {
						// TODO: handle exception
					}finally{
						previousuname = null;
					}
				} else {
					eventbus.fireEvent(new LoginErrorEvent(constants.invalid_login())); //------------
				}
			}
		});

		try {
			rb.send();
		} catch (RequestException re) {
			re.printStackTrace();
		}
	}
	
	protected void getLoginDetails(final String previousuname) {
			rpcservice.getLoginData(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus) {

			@Override
			public void onSuccess(StandardServerResponse response) {
				if(response != null){
					if(response.isSuccess()){
						if(response.getListData() != null){
							UserLoginData data = null;
							try{
								data = (UserLoginData) response.getListData().get(0);
								// notify all interested components
								eventbus.fireEvent(new LoginSuccessEvent(data));
								display.reset();
								display.showCloseDialog(false);
		
								// issue the command that
								// triggered the dialog
								if (commandsqueue != null) {//if (command != null) {
									
									if(previousuname != null){
										if(data.getUsername().trim().equalsIgnoreCase(previousuname.trim())){
											try{
												for(Command cmd: commandsqueue)
													cmd.execute();							
											}catch (Exception e) {
											}finally{
												commandsqueue = null;
											}
											History.newItem(savedhtoken);
											History.fireCurrentHistoryState();
											return;
										}
									}
									eventbus.fireEvent(new UserAccountEvent(data));
									//display.showDialogBox(false);
								}else{												
									eventbus.fireEvent(new UserAccountEvent(data));
								}
							}catch (Exception e) {
								SC.say(constants.app_error(), "getLoginDetails(): " + e.getLocalizedMessage());
							}finally{
								data = null;
							}
						}
					}					
				}
			}
			
		});		
	}

	private boolean validateUserInput(String username, String password) {
		try {
			if (username == null
					|| username.equals("")) {
				display.addUserNameStyle(
						MajiCSS.login_txt_error);
				display.setFocusUserNameTxt(true);
				if (password == null
						|| password.equals("")) {
					display.addPasswordStyle(
							MajiCSS.login_txt_error);
					display.setLoginstatuslbl(
							constants.username_and_password_required(), true);
					return false;
				}
				display.setLoginstatuslbl(
						constants.username_required(), true);
				display.removePasswordStyle(
						MajiCSS.login_txt_error);

				return false;
			}

			if (password == null
					|| password.equals("")) {
				display.addPasswordStyle(
						MajiCSS.login_txt_error);
				display.setLoginstatuslbl(
						constants.password_required(), true);
				display.removeUserNameStyle(
						MajiCSS.login_txt_error);
				return false;
			}

			if (username.length() < minUsernameLength) {
				display.addUserNameStyle(
						MajiCSS.login_txt_error);
				display.setFocusUserNameTxt(true);
				if (password.length() < minPasswordLength) {
					display.addPasswordStyle(
							MajiCSS.login_txt_error);
					display.setLoginstatuslbl(
							constants.username_too_short() + minUsernameLength
									+ " -::- " + constants.password_too_short()
									+ minPasswordLength, true);
					return false;
				}
				display.setLoginstatuslbl(
						constants.username_too_short() + minUsernameLength, true);
				display.removePasswordStyle(
						MajiCSS.login_txt_error);
				return false;
			}

			if (password.length() < minPasswordLength) {
				display.addPasswordStyle(
						MajiCSS.login_txt_error);
				display.setLoginstatuslbl(
						constants.password_too_short() + minPasswordLength, true);
				display.removeUserNameStyle(
						MajiCSS.login_txt_error);
				return false;
			}

			display.removeUserNameStyle(
					MajiCSS.login_txt_error);
			display.removePasswordStyle(
					MajiCSS.login_txt_error);

			return true;
		} catch (Exception e) {
			eventbus.fireEvent(new ErrorEvent(constants.error(), constants
					.err_validate_login_form()));
			return false;
		}
	}

	@Override
	public void onCloseDialogButtonClicked() {
		display.reset();
		display.showCloseDialog(false);
		display.showDialogBox(false);
	}

	@Override
	public void onForgotPasswordLinkClicked() {
		//eventbus.fireEvent(new ForgotPasswordEvent());
	}
	
	@Override
	public void onRegisterLinkClicked() {
		//eventbus.fireEvent(new RegisterEvent());
	}

	@Override
	public void onLoginButtonClicked() {
		loginUserWithSpringSecurity(display.getUserNameValue(), display.getPasswordValue(), display.getRememberMeValue());
	}
	
	@Override
	public void onResetButtonClicked() {
		display.reset();
	}

}
