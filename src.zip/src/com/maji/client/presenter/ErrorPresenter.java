package com.maji.client.presenter;

import net.customware.gwt.presenter.client.EventBus;

import com.google.inject.Inject;
import com.maji.client.widgets.WidgetPresenter;
import com.maji.client.widgets.interfaces.WidgetDisplay;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.widgets.layout.Layout;

public class ErrorPresenter extends
		WidgetPresenter<ErrorPresenter.IErrorViewDisplay>{

	private IErrorViewDisplay display;
	private int presenterwidth, presenterheight;
	
	public int getPresenterheight() {
		return presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	
	@Inject
	public ErrorPresenter(MajiStrings constants, EventBus eventbus, IErrorViewDisplay display) {
		super(display, eventbus);
		this.display = display;
	}

	public interface IErrorViewDisplay extends WidgetDisplay {
		void setContents(boolean iserror);
		Layout asWidget();				
	}

	@Override
	protected void onBind() {
		
	}
	
	public void revealDisplay(boolean iserror) {
		
		display.setContents(iserror);
		revealDisplay();
	}

	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub

	}
	
	
}
