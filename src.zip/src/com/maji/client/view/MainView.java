package com.maji.client.view;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.maji.client.data.AdminDataSource;
import com.maji.client.data.ManageDataSource;
import com.maji.client.data.SetupDataSource;
import com.maji.client.place.PlaceTokens;
import com.maji.client.presenter.MainPresenter;
import com.maji.client.utils.ClientUtils;
import com.maji.client.view.uihandlers.MainViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.ApplicationMenu;
import com.maji.client.widgets.Masthead;
import com.maji.client.widgets.NavigationPane;
import com.maji.client.widgets.NavigationPaneHeader;
import com.maji.client.widgets.NavigationPaneSection;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.layout.events.SectionHeaderClickEvent;
import com.smartgwt.client.widgets.layout.events.SectionHeaderClickHandler;
import com.smartgwt.client.widgets.menu.Menu;
import com.smartgwt.client.widgets.menu.MenuItem;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;

public class MainView extends ViewWithUiHandlers<MainViewUiHandlers> implements
		MainPresenter.IMainViewDisplay {

	private static final String NAME = "name";

	private MajiStrings constants;
	private ClientUtils clientutils;

	private static final int NORTH_HEIGHT = 85;
	private static final int DEFAULT_MENU_WIDTH = 70;
	private static final String DEFAULT_MARGIN = "0px";
	private String currentplace = "";

	private final Masthead masthead;
	private final ApplicationMenu applicationMenu;
	private final NavigationPaneHeader navigationPaneHeader;
	private final NavigationPane navigationPane;

	private VLayout panel;
	private HLayout northLayout;
	private HLayout southLayout;
	private VLayout westLayout;
	private VLayout contentcontainer;
	private Layout center;

	@Inject
	public MainView(MajiStrings constants, ClientUtils clientutils,
			EventBus eventbus, Masthead masthead,
			ApplicationMenu applicationMenu,
			NavigationPaneHeader navigationPaneHeader,
			NavigationPane navigationPane) {
		this.constants = constants;
		this.masthead = masthead;
		this.applicationMenu = applicationMenu;
		this.navigationPaneHeader = navigationPaneHeader;
		this.navigationPane = navigationPane;
		this.clientutils = clientutils;

		Window.enableScrolling(false);
		Window.setMargin(DEFAULT_MARGIN);

		// initialise the main layout container
		panel = new VLayout();
		panel.setWidth100();
		panel.setHeight100();

		// initialise the North layout container
		northLayout = new HLayout();
		northLayout.setHeight(NORTH_HEIGHT);

		// initApplicationMenu();

		// initialise the nested layout container
		VLayout vLayout = new VLayout();
		vLayout.addMember(this.masthead);
		vLayout.addMember(this.applicationMenu);
		vLayout.addMember(this.navigationPaneHeader);

		// add the nested layout container to the North layout container
		northLayout.addMember(vLayout);

		// initNavigationPane();

		// initialise the West layout container
		westLayout = this.navigationPane;

		center = new VLayout();
		center.setWidth100();
		center.setHeight100();

		contentcontainer = new VLayout();
		contentcontainer.setAlign(Alignment.CENTER);
		contentcontainer.addChild(center);

		// initialise the South layout container
		southLayout = new HLayout();
		southLayout.setAlign(Alignment.CENTER);
		southLayout.setMembers(westLayout, contentcontainer);

		// add the North and South layout containers to the main layout
		// container
		panel.addMember(northLayout);
		panel.addMember(southLayout);

		bindCustomUiHandlers();
	}

	protected void bindCustomUiHandlers() {
		// Init menus and attach handlers handlers
		initApplicationMenu();
		initNavigationPane();
		initOtherHandlers();
	}

	private void onRecordClicked(RecordClickEvent event) {
		Record record = event.getRecord();
		currentplace = record.getAttributeAsString(NAME);

		if (getUiHandlers() != null) {
			setContextHeaderLabel(currentplace);
			getUiHandlers().onNavigationPaneSectionClicked(currentplace);
		}
	}
	
	@Override
	public void setContextHeaderLabel(String text){
		navigationPaneHeader.setContextAreaHeaderLabelContents(clientutils
				.getPlaceLabel(text));			
	}

	@Override
	public void selectNavigationPaneRecord(String place){
		navigationPane.selectRecord(place);
	}
	
	@Override
	public Layout asWidget() {
		return panel;
	}

	private void initApplicationMenu() {

		/*
		 * applicationMenu.addMenu("new", DEFAULT_MENU_WIDTH,
		 * constants.new_activity_menu_item_names(), null);
		 */
		applicationMenu.addMenu(constants.option_menu(), DEFAULT_MENU_WIDTH,
				constants.options_activity_menu_item_names(),
				new com.smartgwt.client.widgets.menu.events.ClickHandler() {

					@Override
					public void onClick(MenuItemClickEvent event) {
						// Log.info("clicked.............."+event.getItem().getTitle());
						getUiHandlers().onLogoutButtonClicked();
					}
				});
		
		
		Menu goToMenu = applicationMenu.addMenu(constants.setup_tab(), DEFAULT_MENU_WIDTH,
				new com.smartgwt.client.widgets.events.ClickHandler() {
					
					@Override
					public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
					}
				});	
		   
		MenuItem persons_mnu = new MenuItem(constants.person_menu());
		persons_mnu.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			
			@Override
			public void onClick(MenuItemClickEvent event) {
				if (getUiHandlers() != null) {
					currentplace = PlaceTokens.person;
					setContextHeaderLabel(currentplace);
					getUiHandlers().onNavigationPaneSectionClicked(currentplace);
				}
				
			}
		});
		
		MenuItem units_mnu = new MenuItem(constants.units_menu());
		units_mnu.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			
			@Override
			public void onClick(MenuItemClickEvent event) {
				if (getUiHandlers() != null) {
					currentplace = PlaceTokens.unit;
					setContextHeaderLabel(currentplace);
					getUiHandlers().onNavigationPaneSectionClicked(currentplace);
				}
				
			}
		});
		
		MenuItem charges_mnu = new MenuItem(constants.charges_tab());
		charges_mnu.addClickHandler(new com.smartgwt.client.widgets.menu.events.ClickHandler() {
			
			@Override
			public void onClick(MenuItemClickEvent event) {
				if (getUiHandlers() != null) {
					currentplace = PlaceTokens.charge;
					setContextHeaderLabel(currentplace);
					getUiHandlers().onNavigationPaneSectionClicked(currentplace);
				}
				
			}
		});
		
		
		goToMenu.addItem(persons_mnu);
		goToMenu.addItem(units_mnu);
		goToMenu.addItem(charges_mnu);
		
		  /*Menu goToMenu = applicationMenu.addMenu(Serendipity.getConstants().goToMenuName(),
		        DEFAULT_MENU_WIDTH - 30);
		    applicationMenu.addSubMenu(goToMenu, Serendipity.getConstants().salesMenuItemName(),
		        Serendipity.getConstants().salesMenuItemNames(),
		        null);
		    applicationMenu.addSubMenu(goToMenu, Serendipity.getConstants().settingsMenuItemName(),
		        Serendipity.getConstants().settingsMenuItemNames(),
		        null);
		    applicationMenu.addSubMenu(goToMenu, Serendipity.getConstants().resourceCentreMenuItemName(),
		        Serendipity.getConstants().resourceCentreMenuItemNames(),
		        null);
		    applicationMenu.addMenu(Serendipity.getConstants().toolsMenuName(),
		        DEFAULT_MENU_WIDTH - 30, Serendipity.getConstants().toolsMenuItemNames(),
		        null);
		    applicationMenu.addMenu(Serendipity.getConstants().helpMenuName(),
		        DEFAULT_MENU_WIDTH - 30, Serendipity.getConstants().helpMenuItemNames(),
		        null);*/
	}

	private void initNavigationPane() {
		//navigationPane.addSection(constants.setup_tab(), SetupDataSource
		//		.getInstance());
		navigationPane.addSection(constants.admin_tab(), AdminDataSource
				.getInstance());

		navigationPane.addSection(constants.manage_tab(), ManageDataSource
				.getInstance());
		
		navigationPane
				.addSectionHeaderClickHandler(new SectionHeaderClickHandler() {
					@Override
					public void onSectionHeaderClick(
							SectionHeaderClickEvent event) {
						SectionStackSection section = event.getSection();
						String name = ((NavigationPaneSection) section)
								.getSelectedRecord();

						// If there is no selected record (e.g. the data
						// hasn'passwordclonetxt finished loading)
						// then getSelectedRecord() will return an empty string.
						if (name.isEmpty()) {
							// default to the first item e.g. "Administration"
							// in Settings
							if (section.getTitle().equals(
									constants.manage_tab())) {
								name = ManageDataSource.DEFAULT_RECORD_NAME;
							}else if (section.getTitle()
									.equals(constants.setup_tab())) {
								name = SetupDataSource.DEFAULT_RECORD_NAME;
							} else if (section.getTitle().equals(
									constants.admin_tab())) {
								name = AdminDataSource.DEFAULT_RECORD_NAME;
							} 
						}

						if (getUiHandlers() != null) {
							navigationPaneHeader
									.setContextAreaHeaderLabelContents(clientutils
											.getPlaceLabel(name));
							getUiHandlers()
									.onNavigationPaneSectionHeaderClicked(name);
						}
					}
				});

		navigationPane.addRecordClickHandler(constants.manage_tab(),
				new RecordClickHandler() {
					@Override
					public void onRecordClick(RecordClickEvent event) {
						onRecordClicked(event);
					}
				});

		/*navigationPane.addRecordClickHandler(constants.setup_tab(),
				new RecordClickHandler() {
					@Override
					public void onRecordClick(RecordClickEvent event) {
						onRecordClicked(event);
					}
				});*/

		navigationPane.addRecordClickHandler(constants.admin_tab(),
				new RecordClickHandler() {
					@Override
					public void onRecordClick(RecordClickEvent event) {
						onRecordClicked(event);
					}
				});
	}

	@SuppressWarnings("deprecation")
	public void initOtherHandlers() {
		masthead.getLogoutlink().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				/*
				 * if(userdata != null){ eventbus.fireEvent(new
				 * LogoutEvent(userdata)); }
				 */

				getUiHandlers().onLogoutButtonClicked();
			}
		});

	}

	public ApplicationMenu getApplicationMenu() {
		return applicationMenu;
	}

	@Override
	public NavigationPaneHeader getNavigationPaneHeader() {
		return navigationPaneHeader;
	}

	@Override
	public NavigationPane getNavigationPane() {
		return navigationPane;
	}

	interface MainViewUiBinder extends UiBinder<Widget, MainView> {
	}

	@Override
	public void addWidget(Layout widget) {
		// Delay adding the widget until it is shown in showWidget()
	}

	@Override
	public void removeWidget(Layout widget) {
		center.removeMember(widget);
	}

	private Layout currentwidget;

	@Override
	public void showWidget(Layout widget) {
		if (currentwidget != null) {
			removeWidget(currentwidget);
		}
		center.addMember(widget);
		currentwidget = widget;
	}

	@Override
	public void setSignedinUserdata(UserLoginData userdata) {
		masthead.setSignedinUsername(userdata.getUsername());
	}

}
