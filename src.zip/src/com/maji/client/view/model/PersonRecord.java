package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.properties.MajiCSS;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class PersonRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String PERSON_ID = "person_id";
	public static final String FIRST_NAME = "first_name";
	public static final String LAST_NAME = "last_name";
	public static final String SURNAME = "surname";
	public static final String PERSON_ADDRESS = "address";
	public static final String CREATED_ON = "created_on";
	public static final String PERSON_TELEPHONE = "mobile_number";
	public static final String STATUS = "status_id";
	public static final String CREATED_BY = "created_by";
	public static final String CITY = "city_id";
	public static final String STATUS_NAME = "status_name";
	public static final String FULL_NAME = "full_name";
	
	public PersonRecord() {
	}

	public PersonRecord(String icon, int personid, String firstname,
			String Surname, String lastname,
			String mobilenumber, String address,
			int statusid, int createdby,  Date createdon, 
			int cityid, String status_name) {
		
		setPersonID(personid);
		setFirstName(firstname);
		setSurname(Surname);
		setLastName(lastname);
		setPhone(mobilenumber);
		setAddress(address);
		setStatus(statusid);
		setCreatedOn(createdon);
		setCreatedBy(createdby);
		setCity(cityid);
		setStatusName(status_name);
		setFullName(Surname + " " + firstname);
		//this.setCustomStyle(MajiCSS.grid_alternating);
	}

	public void setPersonID(int attribute) {
		setAttribute(PERSON_ID ,attribute);
	}

	public int getPersonID() {
		return getAttributeAsInt(PERSON_ID);
	}
	
	public void setStatusName(String name) {
		setAttribute(STATUS_NAME, name);
	}

	public String getStatusName() {
		return getAttributeAsString(STATUS_NAME);
	}
	
	public void setFullName(String name) {
		setAttribute(FULL_NAME, name);
	}

	public String getFullName() {
		return getAttributeAsString(FULL_NAME);
	}
	
	public void setFirstName(String name) {
		setAttribute(FIRST_NAME, name);
	}

	public String getFirstName() {
		return getAttributeAsString(FIRST_NAME);
	}
	
	public void setSurname(String name) {
		setAttribute(SURNAME, name);
	}

	public String getSurname() {
		return getAttributeAsString(SURNAME);
	}
	
	public void setLastName(String name) {
		setAttribute(LAST_NAME, name);
	}

	public String getLastName() {
		return getAttributeAsString(LAST_NAME);
	}
	
	public String getAddress() {
		return getAttributeAsString(PERSON_ADDRESS);
	}

	public void setAddress(String attribute) {
		setAttribute(PERSON_ADDRESS, attribute);
	}
	
	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public String getPhone() {
		return getAttributeAsString(PERSON_TELEPHONE);
	}

	public void setPhone(String attribute) {
		setAttribute(PERSON_TELEPHONE, attribute);
	}
	
	public int getStatus() {
		return getAttributeAsInt(STATUS);
	}

	public void setStatus(int attribute) {
		setAttribute(STATUS, attribute);
	}
	
	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY ,attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}
	
	public void setCity(int attribute) {
		setAttribute(CITY ,attribute);
	}

	public int getCity() {
		return getAttributeAsInt(CITY);
	}
}
