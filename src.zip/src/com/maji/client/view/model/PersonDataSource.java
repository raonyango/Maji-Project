package com.maji.client.view.model;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.fields.DataSourceIntegerField;
import com.smartgwt.client.data.fields.DataSourceTextField;
public class PersonDataSource extends DataSource {

	//private MajiGinjector injector = GWT.create(MajiGinjector.class);
    //private AuthenticationServiceAsync rpcservice = injector.getAuthenticationService();
   /* private MajiServiceAsync rpcservice = injector.getMajiService();
    private ClientUtils clientutils = injector.getClientUtils();
    private MajiStrings constants = injector.getMajiConstants();
    private boolean initialized = false;
     */
	public static PersonDataSource getInstance() {
		return new PersonDataSource();
	}

	public PersonDataSource() {
		super();
		setClientOnly(true);
		DataSourceIntegerField idfld = new DataSourceIntegerField(PersonRecord.PERSON_ID, "Person Id");
		idfld.setPrimaryKey(true);
		DataSourceTextField namefld = new DataSourceTextField(PersonRecord.FULL_NAME, "Full Name");
		namefld.setCanEdit(false);
		
		setFields(idfld, namefld);
	}
	
	/*   @Override
	   protected Object transformRequest(DSRequest request) {
		  request.setWillHandleError(true);
	      if (request.getOperationType() != null) {
	         switch (request.getOperationType()) {
	             case ADD:
	                 //executeAdd(lstRec, true);
	                 break;
	             case FETCH:
	                 executeFetch();
	                 break;
	             case REMOVE:
	                 //executeRemove(lstRec);
	                 break;
	             case UPDATE:
	                 //executeAdd(lstRec, false);
	                 break;

	             default:
	                 break;
	         }
	     }
	     return super.transformRequest(request);
	   }*/
			    
	   

}
