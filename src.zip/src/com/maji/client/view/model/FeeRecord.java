package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.ibatis.beans.StandardCharge;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class FeeRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String FEE_ID = "fee_id";
	public static final String FEE_AMOUNT = "fee_number";
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	public static final String FEE_DESC = "fee_desc";
	public static final String STATUS_NAME = "status_name";
	
	public FeeRecord() {
	}

	public FeeRecord(StandardCharge fee) {
		
		setFeeID(fee.getStchargeId());
		setFeeDescription(fee.getStchargeDescription());
		setFeeAmount(fee.getStchargeAmount().doubleValue());
		setCreatedOn(fee.getCreatedOn());
		setCreatedBy(fee.getCreatedBy());
		setStatusName(Integer.parseInt(String.valueOf(fee.getIsActive())));
	}

	public void setFeeID(int attribute) {
		setAttribute(FEE_ID ,attribute);
	}

	public int getFeeID() {
		return getAttributeAsInt(FEE_ID);
	}
	
	public void setFeeDescription(String attribute) {
		setAttribute(FEE_DESC, attribute);
	}

	public String getFeeDescription() {
		return getAttributeAsString(FEE_DESC);
	}
	
	public void setStatusName(Integer attribute) {
		setAttribute(STATUS_NAME, attribute);
	}

	public String getStatusName() {
		String s = "";
		if(getAttributeAsInt(STATUS_NAME) == 0){
			s= "Inactive";
		
		}else if(getAttributeAsInt(STATUS_NAME) == 1){
			s= "Active";
		}
				
		return s;
	}
	
	public void setFeeAmount(double attribute) {
		setAttribute(FEE_AMOUNT, attribute);
	}

	public double getFeeAmount() {
		return getAttributeAsDouble(FEE_AMOUNT);
	}
	
	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY ,attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}

}
