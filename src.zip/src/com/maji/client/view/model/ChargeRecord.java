package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.ibatis.beans.WaterCharge;
import com.maji.shared.properties.MajiCSS;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class ChargeRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String CHARGE_ID = "charge_id";
	public static final String AMOUNT = "amount_per_unit";
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	public static final String CURRENCY = "currency";
	public static final String ACTIVE =  "active";
	
	public ChargeRecord() {
	}

	public ChargeRecord(WaterCharge charge) {
		setChargeID(charge.getChargeId());
		setChargeAmount(charge.getAmountPerUnit());
		setCurrency(charge.getCurrency());
		setActive(charge.getActive());
		setCreatedOn(charge.getCreatedOn());
		setCreatedBy(charge.getCreatedBy());
		
		//this.setCustomStyle(MajiCSS.grid_alternating);
	}

	public void setChargeID(int attribute) {
		setAttribute(CHARGE_ID ,attribute);
	}

	public int getChargeID() {
		return getAttributeAsInt(CHARGE_ID);
	}
	
	public void setChargeAmount(double amount) {
		setAttribute(AMOUNT, amount);
	}

	public double getChargeAmount() {
		return getAttributeAsDouble(AMOUNT);
	}
	
	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY ,attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}

	public void setActive(boolean value) {
		setAttribute(ACTIVE, value);
	}

	public boolean setActive() {
		return getAttributeAsBoolean(ACTIVE);
	}
	
	public void setCurrency(String name) {
		setAttribute(CURRENCY, name);
	}

	public String getCurrency() {
		return getAttributeAsString(CURRENCY);
	}

}
