package com.maji.client.view;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.inject.Inject;
import com.maji.client.presenter.BillPresenter;
import com.maji.client.view.model.BillRecord;
import com.maji.client.view.model.ChargeDataSource;
import com.maji.client.view.model.ChargeRecord;
import com.maji.client.view.model.StatusDataSource;
import com.maji.client.view.model.UnitDataSource;
import com.maji.client.view.model.UnitRecord;
import com.maji.client.view.model.StatusRecord;
import com.maji.client.view.uihandlers.BillViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.ContextListGrid;
import com.maji.client.widgets.RecordToolBar;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.ToolBar;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterBillStatus;
import com.maji.shared.ibatis.beans.WaterCharge;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiMessages;
import com.maji.shared.properties.MajiStrings;
import com.maji.shared.properties.ToolbarConstants;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ButtonItem;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.form.fields.PickerIcon;
import com.smartgwt.client.widgets.form.fields.RowSpacerItem;
import com.smartgwt.client.widgets.form.fields.SectionItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.form.fields.events.FormItemClickHandler;
import com.smartgwt.client.widgets.form.fields.events.FormItemIconClickEvent;
import com.smartgwt.client.widgets.form.validator.CustomValidator;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class BillView extends ViewWithUiHandlers<BillViewUiHandlers> implements
		BillPresenter.IBillViewDisplay {

	private static final String CONTEXT_AREA_WIDTH = "100%";
	private Integer recordid;

	private final RecordToolBar toolbar, form_tbar, print_tbar;
	private final ContextListGrid listgrid;
	private final StatusBar statusbar;

	private VLayout maincontainer;
	// private ToolStripButton printpreviewbtn;

	private int numberofelements;
	private int numberselected;
	private int pageNumber;

	private MajiMessages messages;
	private ToolbarConstants tconstants;
	private MajiStrings constants;

	private static final String METER_READING = "meter_reading";
	private static final String PREV_METER_READING = "prev_meter_reading";
	private static final String UNITS_CONSUMED = "unitsconsumed";
	private static final String UNIT_CHARGE = "unitcharge";
	private static final String MONTH = "month";
	private static final String YEAR = "year";

	private static final String STATUS = "status";
	private static final String HOUSE_UNIT = "house_unit";
	private static final String CREATED_ON = "created_on";
	private static final String DUE_DATE = "due_date";
	private static final String BILLING_DATE = "billing_date";
	private static final String CANCEL_BTN = "cancel_btn";
	private static final String TOTAL_BILL_AMOUNT = "total_bill";
	private static final String BILL_ID = "bill_id";
	private static final String PRINT_OPTIONS = "print_options";
	private static final String PRINT_BTN = "print_btn";
	private static final String FORM_SECTION = "form_section";

	protected int bill_id;
	protected TextItem meter_reading;
	protected TextItem unitsconsumed;
	protected TextItem total_amount, prev_meter_reading, bill_id_txt;
	protected SelectItem month, year, status, unitcharge, print_options;
	protected SectionItem bill_section;

	protected DateItem duedate, billingdate;
	protected TextItem created_on;
	protected SelectItem houseunit;

	protected PickerIcon unit_charge_pki, house_unit_pki;
	protected DynamicForm form;

	protected DataSource status_ds, unit_ds, charge_ds;

	protected ButtonItem printbtn, cancelbtn;
	protected ListGrid pickListProperties;
	protected ListGridField unitField, tenantField;
	protected MyFloatValidator meterValidator;
	WaterBill bill;
	private ToolStripButton save_btn, save_close_btn, update_btn, print_btn;

	@Inject
	public BillView(RecordToolBar toolbar, RecordToolBar form_toolbar,
			RecordToolBar print_tbar, DynamicForm iform, BillListGrid listgrid,
			StatusBar statusbar, MajiMessages messages,
			ToolbarConstants tconstants, MajiStrings constants) {
		this.toolbar = toolbar;
		this.listgrid = listgrid;
		this.statusbar = statusbar;
		this.messages = messages;
		this.tconstants = tconstants;
		this.constants = constants;
		this.form_tbar = form_toolbar;
		this.form = iform;
		this.print_tbar = print_tbar;

		this.numberofelements = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		this.numberselected = 0;
		pageNumber = 1;

		maincontainer = new VLayout();

		// initialise the View's layout container
		maincontainer.setStyleName(MajiCSS.context_area);
		maincontainer.setWidth(CONTEXT_AREA_WIDTH);

		// add the Tool Bar, List Grid, and Status Bar to the View's layout
		// container
		maincontainer.addMember(this.toolbar);
		maincontainer.addMember(this.listgrid);
		maincontainer.addMember(this.statusbar);

		bindCustomUiHandlers();

		recordid = -1;
	}

	protected void bindCustomUiHandlers() {
		// register the ListGird handlers
		listgrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			@Override
			public void onSelectionChanged(SelectionEvent event) {

				ListGridRecord[] records = event.getSelection();

				numberselected = records.length;

				String selectedLabel = messages.selected(numberselected,
						numberofelements);
				statusbar.getSelectedLabel().setContents(selectedLabel);

			}
		});

		listgrid.addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(BillRecord.BILL_ID);

				if (maincontainer.hasMember(form)) {
					show_update_form(recordid);
				}
			}
		});

		// register the ListGird handlers
		listgrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(BillRecord.BILL_ID);

				show_update_form(recordid);
			}
		});

		// initialise the ToolBar and register its handlers
		initToolBar();

		// initialise the StatusBar and register its handlers
		initStatusBar();
	}

	protected void show_update_form(Integer recordid2) {
		if (getUiHandlers() != null) {
			getUiHandlers().onRecordDoubleClicked(recordid);

			build_add_form();

			if (maincontainer.hasMember(form_tbar)) {
				maincontainer.removeMember(form_tbar);
			}

			if (maincontainer.hasMember(form)) {
				maincontainer.removeMember(form);
			}

			if (maincontainer.hasMember(print_tbar)) {
				maincontainer.removeMember(print_tbar);
				// form = null;
			}

			if (!maincontainer.hasMember(form_tbar)) {
				maincontainer.addMember(form_tbar);
			}

			if (!maincontainer.hasMember(form)) {
				maincontainer.addMember(form);
				// form.show();
			}

			print_btn.disable();
			save_close_btn.disable();

		}
	}

	protected void initToolBar() {
		// ToolStripButton save_btn = new ToolStripButton(ToolBar.SAVE_BUTTON,
		// tconstants.savebtn_caption());

		print_btn = print_tbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(),
				tconstants.printpreviewbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onPrintButtonClicked(
									Integer.parseInt(print_options.getValue()
											.toString()), month.getValue().toString(),
									Integer.parseInt(year.getValue().toString()));
						}
					}
				});
		print_btn.disable();
		print_tbar.addSeparator();
		
		print_tbar.addButton(ToolBar.CANCEL_BUTTON,
				tconstants.cancelbtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(print_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}
					}
				});

		save_btn = form_tbar.addButton(ToolBar.SAVE_BUTTON,
				tconstants.savebtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							save_new_bill();

							resetForm();
						}
					}
				});
		save_btn.disable();
		
		save_close_btn = form_tbar.addButton(ToolBar.SAVE_AND_CLOSE_BUTTON,
				tconstants.save_close_btn_caption(),
				tconstants.save_close_btn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							if (validate_form()) {
								save_new_bill();

								maincontainer.removeMember(form_tbar);
								maincontainer.removeMember(form);
								// form = null;

							}
						}
					}
				});
		save_close_btn.disable();
		form_tbar.addSeparator();
		
		update_btn = form_tbar.addButton(ToolBar.UPDATE_BUTTON,
				tconstants.updatebtn_caption(), tconstants.updatebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							update_bill();

							resetForm();
						}
					}
				});
		update_btn.disable();
		form_tbar.addSeparator();
		
		form_tbar.addButton(ToolBar.CANCEL_BUTTON,
				tconstants.cancelbtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(form_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}
						
					}
				});

		toolbar.addButton(ToolBar.REFRESH_BUTTON,
				tconstants.refreshbtn_caption(),
				tconstants.refreshbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							// maincontainer.disable();
							getUiHandlers().onRefreshButtonClicked();
						}
					}
				});

		toolbar.addSeparator();

		toolbar.addButton(ToolBar.NEW_ACCOUNT_BUTTON,
				tconstants.new_btn_caption(), tconstants.new_btn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {

						if (getUiHandlers() != null) {
							getUiHandlers().onNewButtonClicked();

							build_add_form();
						}

						if (maincontainer.hasMember(form_tbar)) {
							maincontainer.removeMember(form_tbar);
							// form = null;
						}
						
						if (maincontainer.hasMember(print_tbar)) {
							maincontainer.removeMember(print_tbar);
							// form = null;
						}

						if (maincontainer.hasMember(form)) {
							maincontainer.removeMember(form);
							// form = null;
						}
						maincontainer.addMember(form_tbar);
						maincontainer.addMember(form);

						update_btn.disable();
					}
				});

		toolbar.addSeparator();

		toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(),
				tconstants.printpreviewbtn_tooltip(), new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							build_print_form();

							if (maincontainer.hasMember(form_tbar)) {
								maincontainer.removeMember(form_tbar);
								// form = null;
							}

							if (maincontainer.hasMember(print_tbar)) {
								maincontainer.removeMember(print_tbar);
								// form = null;
							}

							if (maincontainer.hasMember(form)) {
								maincontainer.removeMember(form);
								// form = null;
							}

							maincontainer.addMember(print_tbar);
							maincontainer.addMember(form);
						}
					}
				});

		toolbar.addButton(ToolBar.EXPORT_BUTTON,
				tconstants.export_btn_caption(),
				tconstants.export_btn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							// getUiHandlers().onExportButtonClicked();
						}

					}
				});

		// printpreviewbtn.disable();

	}

	class DueDateValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (duedate.getValue() == null) {
				// err = "Due date is required.";
				// setErrorMessage("Date is required");
				return false;
			} else {
				try {
					Date today = new Date();
					Date d = (Date) duedate.getValue();

					if (d.compareTo(today) < 0) {
						setErrorMessage("Must be a date equal to or after date today.");
						d = null;

						return false;
					} else {
						d = null;
						return true;
					}

				} catch (Exception e) {
					// err = "Invalid Due Date.";
					setErrorMessage("Invalid date value.");
					Log.info("validate err...................."
							+ e.getMessage());
					return false;
				}
			}
		}
	}

	class HouseUnitValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (houseunit.getValue() == null) {
				// err = "House Unit is required.";
				setErrorMessage("House unit is required");
				return false;
			} else if (Integer.parseInt(houseunit.getValue().toString()) < 1) {
				// err = "House Unit is required.";
				setErrorMessage("House unit is required");
				return false;
			} else {
				return true;
			}
		}
	}

	class MyFloatValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (meter_reading.getValue() == null) {
				// err = "House Unit is required.";
				setErrorMessage("Meter Reading is required");
				return false;
			} else {
				try {
					Double temp = Double.parseDouble(meter_reading.getValue()
							.toString());

					if (temp < 0) {
						setErrorMessage("Meter Reading cannot be a negative value.");
						return false;
					}

					return true;
				} catch (Exception e) {
					setErrorMessage("Invalid Meter Reading Value");
					return false;
				}
			}
		}
	}

	protected boolean validate_form() {
		/*
		 * String err = null;
		 * 
		 * if(err == null && form.validate()){ return true; }else{
		 * SC.say("Validation Error",err); return false; }
		 */

		if (form.validate()) {
			if (Double.parseDouble(meter_reading.getValue().toString()) < Double
					.parseDouble(prev_meter_reading.getValue().toString())) {
				SC.say("Validation Error",
						"Current meter reading cannot be less that the previous meter reading");
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}

	}

	protected void save_new_bill() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				bill = new WaterBill();
				bill.setHouseUnitId(Integer.parseInt(houseunit.getValue()
						.toString()));
				bill.setChargeId(Integer.parseInt(unitcharge.getValue()
						.toString()));
				bill.setMeterReading(Double.parseDouble(meter_reading
						.getValue().toString()));
				bill.setDueDate((Date) duedate.getValue());
				bill.setBillingDate((Date) billingdate.getValue());
				bill.setCreatedOn(d);
				bill.setUnitsConsumed(Double.parseDouble(unitsconsumed
						.getValue().toString()));
				bill.setStatusId(Integer.parseInt(status.getValue().toString()));
				bill.setMonth(month.getValue().toString());
				bill.setYear(Integer.parseInt(year.getValue().toString()));

				getUiHandlers().onSaveNewButtonClicked(bill);

			} catch (Exception e) {
				Log.info("BillView.Save New Error...................."
						+ e.getMessage());
			} finally {
				bill = null;
			}

		}

	}

	protected void update_bill() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				bill = new WaterBill();
				bill.setBillId(Integer.parseInt(bill_id_txt.getValue()
						.toString()));
				bill.setHouseUnitId(Integer.parseInt(houseunit.getValue()
						.toString()));
				bill.setChargeId(Integer.parseInt(unitcharge.getValue()
						.toString()));
				bill.setMeterReading(Double.parseDouble(meter_reading
						.getValue().toString()));
				bill.setDueDate((Date) duedate.getValue());
				bill.setBillingDate((Date) billingdate.getValue());
				bill.setModifiedOn(d);
				bill.setUnitsConsumed(Double.parseDouble(unitsconsumed
						.getValue().toString()));
				bill.setStatusId(Integer.parseInt(status.getValue().toString()));
				bill.setMonth(month.getValue().toString());
				bill.setYear(Integer.parseInt(year.getValue().toString()));

				getUiHandlers().onUpdateButtonClicked(bill);

			} catch (Exception e) {
				Log.info("BillView.Update Error...................."
						+ e.getMessage());
			} finally {
				bill = null;
			}

		}

	}

	protected void resetForm() {
		form.clearValue(HOUSE_UNIT);
		form.clearValue(METER_READING);
		form.clearValue(DUE_DATE);
		form.clearValue(BILLING_DATE);
		form.clearValue(UNITS_CONSUMED);
		form.clearValue(TOTAL_BILL_AMOUNT);
		form.clearValue(PREV_METER_READING);

		save_btn.disable();
		save_close_btn.disable();
		update_btn.disable();

		if (getUiHandlers() != null) {
			getUiHandlers().onNewButtonClicked();
		}
	}

	protected void initStatusBar() {

		// "0 of 50 selected"
		// statusbar.getSelectedLabel().setContents(Serendipity.getConstants().selectedLabel());

		statusbar.getResultSetFirstButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetFirstButtonClicked();
				}
			}
		});

		statusbar.getResultSetPreviousButton().addClickHandler(
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onResultSetPreviousButtonClicked();
						}
					}
				});

		// "Page 1"
		// statusbar.getPageNumberLabel().setContents(Serendipity.getConstants().pageNumberLabel());

		statusbar.getResultSetNextButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetNextButtonClicked();
				}
			}
		});
	}

	@Override
	public void setResultSet(List<WaterBill> resultset) {
		// resultSet == null when there are no items in table
		if (resultset != null) {

			try {
				((BillListGrid) listgrid).setServicesResultSet(resultset);
			} catch (Exception e) {
				Log.info("BillView.setResultSet Error...................."
						+ e.getMessage());
			}
		}
	}

	@Override
	public void refreshStatusBar() {
		// update Selected label e.g "0 of 50 selected"
		statusbar.getSelectedLabel().setContents(
				messages.selected(numberselected, numberofelements));
		// Log.info(numberofelements + "............REFRESH........");
		// update Page number label e.g "Page 1"
		statusbar.getPageNumberLabel().setContents(messages.page(pageNumber));
	}

	@Override
	public void setPageNumber(int pagenumber) {
		this.pageNumber = pagenumber;
	}

	@Override
	public void setNumberSelected(int numberselected) {
		this.numberselected = numberselected;
	}

	@Override
	public Layout asWidget() {
		return maincontainer;
	}

	@Override
	public StatusBar getStatusBar() {
		return statusbar;
	}

	@Override
	public void setNumberOfElements(int numberofelements) {
		this.numberofelements = numberofelements;

	}

	protected DueDateValidator duedateValidator;
	protected HouseUnitValidator hunitvalidator;

	@SuppressWarnings("deprecation")
	public void build_add_form() {
		meterValidator = new MyFloatValidator();

		meter_reading = new TextItem(METER_READING,
				constants.meter_reading_lbl());
		meter_reading.setSelectOnFocus(true);
		// meter_reading.setWrapTitle(false);
		// meter_reading.setDefaultValue("[Account Name]");
		meter_reading.setRequired(true);
		meter_reading.setValidators(meterValidator);
		meter_reading.disable();
		meter_reading.addChangedHandler(new ChangedHandler() {

			@Override
			public void onChanged(ChangedEvent event) {
				Object mreading = event.getValue();
				try {
					// ----------------------------------
					// test. dnt remove
					double x = Double.parseDouble((String) mreading);
					x = 0;
					// ----------------------------------

					if (mreading != null) {
						// if (mreading instanceof Double || mreading instanceof
						// Integer) {
						double diff = 0;
						diff = Double.parseDouble(String.valueOf(mreading))
								- Double.parseDouble(String.valueOf(form
										.getField("prev_meter_reading")
										.getValue()));

						form.getField("unitsconsumed").setValue(
								Math.round(diff * 100.0) / 100.0);

						double amnt = 0;
						amnt = Double.parseDouble(String.valueOf(form.getField(
								"unitcharge").getDisplayValue()))
								* diff;
						form.getField("total_bill").setValue(
								Math.round(amnt * 100.0) / 100.0);

						// }
					} else {
						form.getField("total_bill").setValue(0);
					}
				} catch (Exception e) {
					form.getField("total_bill").setValue(0);
				}

			}
		});

		prev_meter_reading = new TextItem(PREV_METER_READING,
				constants.prev_meter_reading_lbl());
		prev_meter_reading.setSelectOnFocus(true);
		prev_meter_reading.disable();

		month = new SelectItem(MONTH, constants.month_lbl());
		month.setType("comboBox");
		month.setValueMap(getMonthsValueMap());
		// month.setDefaultToFirstOption(true);
		// month.setValue();
		month.setRequired(true);
		month.disable();

		Date d = new Date();
		year = new SelectItem(YEAR, constants.year_lbl());
		year.setType("comboBox");
		year.setValueMap(getYearsValueMap());
		// year.setDefaultToFirstOption(true);
		year.setDefaultValue(String.valueOf(d.getYear() + 1900));
		year.setRequired(true);
		year.disable();

		unitsconsumed = new TextItem(UNITS_CONSUMED,
				constants.units_consumed_lbl());
		unitsconsumed.setRequired(true);
		unitsconsumed.disable();

		unit_charge_pki = new PickerIcon(PickerIcon.SEARCH,
				new FormItemClickHandler() {
					public void onFormItemClick(FormItemIconClickEvent event) {
						SC.say("Unit Charge clicked!");
					}
				});

		unitcharge = new SelectItem(UNIT_CHARGE,
				constants.charge_per_unit_lbl());
		// unitcharge.setIcons(unit_charge_pki);
		unitcharge.disable();
		unitcharge.setType("comboBox");
		unitcharge.setValueField("charge_id");
		unitcharge.setDisplayField("amount_per_unit");

		house_unit_pki = new PickerIcon(PickerIcon.SEARCH,
				new FormItemClickHandler() {
					public void onFormItemClick(FormItemIconClickEvent event) {
						SC.say("houseunit pki clicked!");
					}
				});

		pickListProperties = new ListGrid();
		pickListProperties.setShowFilterEditor(true);

		unitField = new ListGridField("unit_number");
		unitField.setWidth(85);
		tenantField = new ListGridField("tenant_name");
		tenantField.setWidth(155);

		hunitvalidator = new HouseUnitValidator();

		houseunit = new SelectItem(HOUSE_UNIT, constants.house_unit_lbl());
		// houseunit.setIcons(house_unit_pki);
		houseunit.setRequired(true);
		houseunit.setOptionDataSource(unit_ds);
		houseunit.setDisplayField("unit_number");
		houseunit.setValueField("unit_id");
		houseunit.setPickListWidth(240);
		houseunit.setPickListFields(tenantField, unitField);
		houseunit.setPickListProperties(pickListProperties);
		houseunit.setValidators(hunitvalidator);

		houseunit.addChangeHandler(new ChangeHandler() {

			@Override
			public void onChange(ChangeEvent event) {
				if (getUiHandlers() != null && event.getValue() != null) {
					getUiHandlers().onHouseUnitSelected(
							(Integer) event.getValue());
				}
			}
		});

		total_amount = new TextItem(TOTAL_BILL_AMOUNT,
				constants.total_bill_lbl());
		// total_amount.setRequired(true);
		total_amount.setValue(0); // System.currentTimeMillis()
		total_amount.disable();

		duedateValidator = new DueDateValidator();

		duedate = new DateItem(DUE_DATE, constants.bill_due_date_lbl());
		duedate.setRequired(true);
		duedate.setUseTextField(true);
		duedate.setValidators(duedateValidator);
		duedate.disable();

		billingdate = new DateItem(BILLING_DATE, constants.billing_date_lbl());
		billingdate.setRequired(true);
		billingdate.setUseTextField(true);
		billingdate.setValidators(duedateValidator);
		billingdate.disable();
		
		created_on = new TextItem(CREATED_ON, constants.created_on_lbl());
		// created_on.setRequired(true);
		created_on.setValue(d.toString()); // System.currentTimeMillis()
		created_on.disable();

		bill_id_txt = new TextItem(BILL_ID, "");
		bill_id_txt.setVisible(false);

		status = new SelectItem(STATUS, constants.bill_status_lbl());
		status.setType("comboBox");
		status.setRequired(true);
		status.setValueField("statusId");
		status.setDisplayField("statusName");
		status.disable();

		bill_section = new SectionItem();
		bill_section.setDefaultValue(constants.bill_info_section_name());
		bill_section.setItemIds(HOUSE_UNIT, PREV_METER_READING, METER_READING,
				"rowSpacer1", MONTH, YEAR, DUE_DATE, "rowSpacer2", STATUS, BILLING_DATE,
				CREATED_ON, "rowSpacer3", UNITS_CONSUMED, UNIT_CHARGE,
				TOTAL_BILL_AMOUNT, "rowSpacer4");

		RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer3 = new RowSpacerItem("rowSpacer3");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer4 = new RowSpacerItem("rowSpacer4");
		rowSpacer1.setStartRow(false);

		// form = new DynamicForm();
		// generalForm.setWidth100();
		form.setMargin(2);
		form.setNumCols(6);
		form.setCellPadding(2);
		form.setAutoFocus(false);
		form.setWrapItemTitles(false);
		form.setWidth("100%");

		// no ":" after the field name
		form.setTitleSuffix(" ");
		form.setRequiredTitleSuffix("*");
		form.setFields(bill_section, houseunit, prev_meter_reading,
				meter_reading, rowSpacer1, month, year, duedate, rowSpacer2,
				status, billingdate, created_on, rowSpacer3, unitsconsumed, unitcharge,
				total_amount, rowSpacer4);

	}

	@SuppressWarnings("deprecation")
	public void build_print_form() {

		month = new SelectItem(MONTH, constants.month_lbl());
		month.setType("comboBox");
		month.setValueMap(getMonthsValueMap());
		// month.setDefaultToFirstOption(true);
		// month.setValue();
		month.setRequired(true);
		month.disable();

		Date d = new Date();
		year = new SelectItem(YEAR, constants.year_lbl());
		year.setType("comboBox");
		year.setValueMap(getYearsValueMap());
		// year.setDefaultToFirstOption(true);
		year.setDefaultValue(String.valueOf(d.getYear() + 1900));
		year.setRequired(true);
		year.disable();

		print_options = new SelectItem(PRINT_OPTIONS,
				constants.print_options_lbl());
		print_options.setType("comboBox");
		print_options.setRequired(true);
		print_options.setValueMap(getPrintOptionsValueMap());
		print_options.addChangeHandler(new ChangeHandler() {

			@Override
			public void onChange(ChangeEvent event) {
				if (Integer.parseInt(event.getValue().toString()) == 3
						|| Integer.parseInt(event.getValue().toString()) == 4) {
					month.enable();
					year.enable();
				} else {
					month.disable();
					year.disable();
				}

				print_btn.enable();
			}
		});

		bill_section = new SectionItem(FORM_SECTION);
		bill_section.setDefaultValue(constants.print_bills_section());
		bill_section.setItemIds("rowSpacer1", PRINT_OPTIONS, "rowSpacer2",
				MONTH,  "rowSpacer3", YEAR, "rowSpacer4");

		RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer3 = new RowSpacerItem("rowSpacer3");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer4 = new RowSpacerItem("rowSpacer4");
		rowSpacer1.setStartRow(false);

		// form = new DynamicForm();
		// generalForm.setWidth100();
		form.setMargin(2);
		form.setNumCols(2);
		form.setCellPadding(2);
		form.setAutoFocus(false);
		form.setWrapItemTitles(false);
		form.setWidth("100%");

		// no ":" after the field name
		form.setTitleSuffix(" ");
		form.setRequiredTitleSuffix("*");
		form.setFields(bill_section, rowSpacer1, print_options, rowSpacer2,
				month,  rowSpacer3, year, rowSpacer4);

	}

	private LinkedHashMap<String, String> getPrintOptionsValueMap() {
		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

		hm.put("1", "Print All");
		hm.put("2", "Print All Pending");
		hm.put("3", "Print All In Month");
		hm.put("4", "Print Pending In Month");

		return hm;
	}

	@SuppressWarnings("deprecation")
	private LinkedHashMap<String, String> getMonthsValueMap() {

		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();

		int ctr = 0;
		Date d = new Date();

		String[] months = LocaleInfo.getCurrentLocale().getDateTimeFormatInfo()
				.monthsFull();

		for (String s : months) {
			hm.put(s, s);
			if (ctr == d.getMonth()) {
				month.setValue(s);
			}
			ctr++;
		}

		return hm;
	}

	@SuppressWarnings("deprecation")
	private LinkedHashMap<String, String> getYearsValueMap() {

		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
		// int ctr = 0;
		Date d = new Date();

		hm.put(String.valueOf(d.getYear() + 1900 - 1),
				String.valueOf(d.getYear() + 1900 - 1));
		hm.put(String.valueOf(d.getYear() + 1900),
				String.valueOf(d.getYear() + 1900));
		hm.put(String.valueOf(d.getYear() + 1900 + 1),
				String.valueOf(d.getYear() + 1900 + 1));

		return hm;
	}

	@Override
	public void setStatusDSource(List<WaterBillStatus> status_lst,
			boolean new_bill) {
		if (status_lst != null) {
			StatusRecord r;
			status_ds = StatusDataSource.getInstance();

			for (WaterBillStatus status : status_lst) {
				r = new StatusRecord();
				r.setStatusID(status.getStatusId());
				r.setStatusName(status.getStatusName());

				status_ds.addData(r);
			}

			status.setOptionDataSource(status_ds);

			if (new_bill) {
				status.setValue(1);
			}
		}
	}

	@Override
	public void setHouseUnitsDSource(List<HouseUnit> unit_dtos) {
		if (unit_dtos != null) {
			UnitRecord r;
			unit_ds = UnitDataSource.getInstance();

			for (HouseUnit unit : unit_dtos) {
				r = new UnitRecord();
				r.setUnitID(unit.getUnitId());
				r.setUnitNumber(unit.getUnitNumber());
				r.setTenantName(unit.getTenantName());

				unit_ds.addData(r);
			}

			houseunit.setOptionDataSource(unit_ds);
			houseunit.clearValue();
		}
	}

	@Override
	public void setActiveUnitChargeValue(WaterCharge unit_charge,
			boolean new_bill) {
		if (unit_charge != null) {
			ChargeRecord r;
			charge_ds = ChargeDataSource.getInstance();

			r = new ChargeRecord();
			r.setChargeID(unit_charge.getChargeId());
			r.setChargeAmount(unit_charge.getAmountPerUnit());

			charge_ds.addData(r);

			unitcharge.setOptionDataSource(charge_ds);

			if (new_bill) {
				unitcharge.setValue(r.getChargeID());
			}
		}
	}

	@Override
	public void setLastMeterReading(WaterBill last_bill) {
		meter_reading.enable();
		month.enable();
		year.enable();
		duedate.enable();
		billingdate.enable();
		status.enable();
		save_close_btn.enable();
		save_btn.enable();

		prev_meter_reading.setValue((last_bill.getMeterReading()));

	}

	@Override
	public void setSaveNewSuccess() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setBillDetails(WaterBill waterbill) {
		prev_meter_reading.setValue(waterbill.getMeterReading()
				- waterbill.getUnitsConsumed());
		meter_reading.setValue(waterbill.getMeterReading());
		unitcharge.setValue(waterbill.getChargeId());
		houseunit.setValue(waterbill.getHouseUnitId());
		status.setValue(waterbill.getStatusId());
		duedate.setValue(waterbill.getDueDate());
		billingdate.setValue(waterbill.getBillingDate());
		created_on.setValue(waterbill.getCreatedOn());
		unitsconsumed.setValue(waterbill.getUnitsConsumed());
		total_amount
				.setValue(Math.round((waterbill.getUnitsConsumed() * waterbill
						.getChargeAmount()) * 100.0) / 100.0);
		bill_section.setValue(bill_section.getValue());
		bill_id_txt.setValue(waterbill.getBillId());

		year.setValueMap(getYearsValueMap());
		month.setValueMap(getMonthsValueMap());

		year.setValue(waterbill.getYear());
		month.setValue(waterbill.getMonth());

		if (waterbill.getStatusId() == Integer.parseInt(constants
				.new_bill_status())) {
			meter_reading.enable();
			month.enable();
			year.enable();
			duedate.enable();
			billingdate.enable();
			status.enable();
			update_btn.enable();
			houseunit.enable();
		}else{
			meter_reading.disable();
			month.disable();
			year.disable();
			duedate.disable();
			billingdate.disable();
			status.disable();
			update_btn.disable();
			houseunit.disable();
		}
	}

	@Override
	public void setUpdateSuccess() {
		maincontainer.removeMember(form_tbar);
		maincontainer.removeMember(form);
		SC.say(constants.record_update_success());
	}

}