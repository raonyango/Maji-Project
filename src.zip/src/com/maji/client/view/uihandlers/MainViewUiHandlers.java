package com.maji.client.view.uihandlers;

public interface MainViewUiHandlers extends UiHandlers{
	void onNavigationPaneSectionHeaderClicked(String name);
	void onNavigationPaneSectionClicked(String name);
	void onLogoutButtonClicked();
}
