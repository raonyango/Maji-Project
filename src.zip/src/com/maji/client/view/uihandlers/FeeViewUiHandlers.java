package com.maji.client.view.uihandlers;

import com.maji.shared.ibatis.beans.StandardCharge;


public interface FeeViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(int recordid);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

	void onSaveNewButtonClicked(StandardCharge fee);

	void onUpdateButtonClicked(StandardCharge fee);

}
