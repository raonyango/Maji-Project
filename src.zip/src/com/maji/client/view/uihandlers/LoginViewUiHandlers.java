package com.maji.client.view.uihandlers;

public interface LoginViewUiHandlers extends UiHandlers {

	void onLoginButtonClicked();

	void onResetButtonClicked();

	void onCloseDialogButtonClicked();

	void onForgotPasswordLinkClicked();

	void onRegisterLinkClicked();
	
}
