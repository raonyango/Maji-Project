package com.maji.client.view.uihandlers;

public interface UiHandlers {

}
