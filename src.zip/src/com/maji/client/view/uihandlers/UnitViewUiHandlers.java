package com.maji.client.view.uihandlers;

import com.maji.shared.ibatis.beans.HouseUnit;


public interface UnitViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(int recordid);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

	void onSaveNewButtonClicked(HouseUnit unit);

	void onUpdateButtonClicked(HouseUnit unit);

}

