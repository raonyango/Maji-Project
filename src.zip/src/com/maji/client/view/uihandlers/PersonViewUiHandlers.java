package com.maji.client.view.uihandlers;

import com.maji.shared.ibatis.beans.Person;


public interface PersonViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(int recordId);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

	void onSaveNewButtonClicked(Person person);

	void onUpdateButtonClicked(Person person);

}
