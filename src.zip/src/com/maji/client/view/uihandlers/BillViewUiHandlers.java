package com.maji.client.view.uihandlers;

import com.maji.shared.ibatis.beans.WaterBill;


public interface BillViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(Integer recordId);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

	void onHouseUnitSelected(Integer houseunit_id);

	void onSaveNewButtonClicked(WaterBill bill);

	void onUpdateButtonClicked(WaterBill bill);

	void onPrintButtonClicked(int print_option, String month, int year);
}
