package com.maji.client.view;

import java.util.Date;
import java.util.List;

import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.maji.client.presenter.PersonPresenter;
import com.maji.client.view.model.CityDataSource;
import com.maji.client.view.model.CityRecord;
import com.maji.client.view.model.PersonRecord;
import com.maji.client.view.model.StatusDataSource;
import com.maji.client.view.model.StatusRecord;
import com.maji.client.view.uihandlers.PersonViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.ContextListGrid;
import com.maji.client.widgets.RecordToolBar;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.ToolBar;
import com.maji.shared.ibatis.beans.City;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.PersonStatus;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiMessages;
import com.maji.shared.properties.MajiStrings;
import com.maji.shared.properties.ToolbarConstants;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.RowSpacerItem;
import com.smartgwt.client.widgets.form.fields.SectionItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class PersonView extends ViewWithUiHandlers<PersonViewUiHandlers>
		implements PersonPresenter.IPersonViewDisplay {

	private static final String CONTEXT_AREA_WIDTH = "100%";
	private int recordid;

	private final RecordToolBar toolbar, form_tbar;
	private final ContextListGrid listgrid;
	private final StatusBar statusbar;

	private VLayout maincontainer;
	private ToolStripButton printpreviewbtn;

	private int numberofelements;
	private int numberselected;
	private int pageNumber;

	private MajiMessages messages;
	private ToolbarConstants tconstants;
	private ToolStripButton save_btn, save_close_btn, update_btn;
	protected DynamicForm form;
	private Person person;
	private MajiStrings constants;

	private static final String FNAME = "fname";
	private static final String MNAME = "mname";
	private static final String SURNAME = "surname";
	private static final String CITY = "city";
	private static final String ADDRESS = "address";
	private static final String MOBILE_NUM = "mobilenum";
	private static final String STATUS = "status";
	private static final String PERSON_ID = "pid";
	private static final String CREATED_ON = "created_on";
	private static final String FORM_SECTION = "form_section";

	protected TextItem fname, mname, surname, address, mobilenum, created_on,
			person_id_txt;
	protected SelectItem status, city;
	protected SectionItem form_section;
	protected DataSource status_ds, city_ds;

	@Inject
	public PersonView(RecordToolBar toolbar, RecordToolBar form_toolbar,
			PersonListGrid listgrid, StatusBar statusbar,
			MajiMessages messages, MajiStrings constants, DynamicForm iform,
			ToolbarConstants tconstants) {
		this.toolbar = toolbar;
		this.listgrid = listgrid;
		this.statusbar = statusbar;
		this.messages = messages;
		this.tconstants = tconstants;
		this.form_tbar = form_toolbar;
		this.constants = constants;
		this.numberofelements = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		this.numberselected = 0;
		this.form = iform;
		pageNumber = 1;

		maincontainer = new VLayout();

		// initialise the View's layout container
		// maincontainer.setStyleName(MajiCSS.context_area);
		maincontainer.setStyleName("crm-Entity-ContextArea");
		maincontainer.setWidth(CONTEXT_AREA_WIDTH);

		// add the Tool Bar, List Grid, and Status Bar to the View's layout
		// container
		maincontainer.addMember(this.toolbar);
		maincontainer.addMember(this.listgrid);
		maincontainer.addMember(this.statusbar);

		bindCustomUiHandlers();

		recordid = -1;
	}

	protected void bindCustomUiHandlers() {
		// register the ListGird handlers
		listgrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			@Override
			public void onSelectionChanged(SelectionEvent event) {

				ListGridRecord[] records = event.getSelection();

				numberselected = records.length;

				String selectedLabel = messages.selected(numberselected,
						numberofelements);
				statusbar.getSelectedLabel().setContents(selectedLabel);

				// Log.debug("onSelectionChanged() - records: " +
				// records.length);
			}
		});
		// initialise the ToolBar and register its handlers
		initToolBar();

		// register the ListGird handlers
		listgrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(PersonRecord.PERSON_ID);

				show_update_form(recordid);
			}
		});

		listgrid.addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(PersonRecord.PERSON_ID);

				if (maincontainer.hasMember(form)) {
					show_update_form(recordid);
				}
			}
		});

		// initialise the StatusBar and register its handlers
		initStatusBar();
	}

	protected void initToolBar() {
		save_btn = form_tbar.addButton(ToolBar.SAVE_BUTTON,
				tconstants.savebtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							save_new_person();

							resetForm();
						}
					}
				});
		save_btn.disable();

		save_close_btn = form_tbar.addButton(ToolBar.SAVE_AND_CLOSE_BUTTON,
				tconstants.save_close_btn_caption(),
				tconstants.save_close_btn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							if (validate_form()) {
								save_new_person();

								maincontainer.removeMember(form_tbar);
								maincontainer.removeMember(form);
								// form = null;

							}
						}
					}
				});
		save_close_btn.disable();
		form_tbar.addSeparator();

		update_btn = form_tbar.addButton(ToolBar.UPDATE_BUTTON,
				tconstants.updatebtn_caption(), tconstants.updatebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							update_person();

							resetForm();
						}
					}
				});
		update_btn.disable();
		form_tbar.addSeparator();

		form_tbar.addButton(ToolBar.CANCEL_BUTTON,
				tconstants.cancelbtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(form_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}

					}
				});

		toolbar.addButton(ToolBar.NEW_ACCOUNT_BUTTON,
				tconstants.new_btn_caption(), tconstants.new_btn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {

						if (getUiHandlers() != null) {
							getUiHandlers().onNewButtonClicked();

							build_add_form();
						}

						if (maincontainer.hasMember(form_tbar)) {
							maincontainer.removeMember(form_tbar);
							// form = null;
						}

						if (maincontainer.hasMember(form)) {
							maincontainer.removeMember(form);							
							// form = null;
						}
						
						resetForm();
						
						maincontainer.addMember(form_tbar);
						maincontainer.addMember(form);

						update_btn.disable();
						save_btn.enable();
						save_close_btn.enable();
					}
				});

		toolbar.addSeparator();

		toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(),
				tconstants.printpreviewbtn_tooltip(), new ClickHandler() {

					@Override
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {

						}
					}
				});

		toolbar.addButton(ToolBar.REFRESH_BUTTON,
				tconstants.refreshbtn_caption(),
				tconstants.refreshbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							// maincontainer.disable();
							getUiHandlers().onRefreshButtonClicked();
						}
					}
				});

		toolbar.addSeparator();

		printpreviewbtn = toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(),
				tconstants.printpreviewbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {

					}
				});

		printpreviewbtn.disable();

	}

	protected void initStatusBar() {

		// "0 of 50 selected"
		// statusbar.getSelectedLabel().setContents(Serendipity.getConstants().selectedLabel());

		statusbar.getResultSetFirstButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetFirstButtonClicked();
				}
			}
		});

		statusbar.getResultSetPreviousButton().addClickHandler(
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onResultSetPreviousButtonClicked();
						}
					}
				});

		// "Page 1"
		// statusbar.getPageNumberLabel().setContents(Serendipity.getConstants().pageNumberLabel());

		statusbar.getResultSetNextButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetNextButtonClicked();
				}
			}
		});
	}

	@Override
	public void setResultSet(List<Person> resultset) {
		// resultSet == null when there are no items in table
		if (resultset != null) {

			try {
				((PersonListGrid) listgrid).setServicesResultSet(resultset);
			} catch (Exception e) {
				Log.info("Error1...................." + e.getMessage());
			}
		}
	}

	@Override
	public void refreshStatusBar() {
		// update Selected label e.g "0 of 50 selected"
		statusbar.getSelectedLabel().setContents(
				messages.selected(numberselected, numberofelements));
		// Log.info(numberofelements + "............REFRESH........");
		// update Page number label e.g "Page 1"
		statusbar.getPageNumberLabel().setContents(messages.page(pageNumber));
	}

	@Override
	public void setPageNumber(int pagenumber) {
		this.pageNumber = pagenumber;
	}

	@Override
	public void setNumberSelected(int numberselected) {
		this.numberselected = numberselected;
	}

	@Override
	public Layout asWidget() {
		return maincontainer;
	}

	@Override
	public StatusBar getStatusBar() {
		return statusbar;
	}

	@Override
	public void setNumberOfElements(int numberofelements) {
		this.numberofelements = numberofelements;
		Log.info(numberofelements + " persons....................");
	}

	// -----------------------------------------------------------------------------------------------------------------

	protected void show_update_form(Integer recordid2) {
		if (getUiHandlers() != null) {
			getUiHandlers().onRecordDoubleClicked(recordid);

			build_add_form();

			if (maincontainer.hasMember(form_tbar)) {
				maincontainer.removeMember(form_tbar);
			}

			if (maincontainer.hasMember(form)) {
				maincontainer.removeMember(form);
			}

			if (!maincontainer.hasMember(form_tbar)) {
				maincontainer.addMember(form_tbar);
			}

			if (!maincontainer.hasMember(form)) {
				maincontainer.addMember(form);
				// form.show();
			}

			save_close_btn.disable();
			save_btn.disable();
			update_btn.enable();
		}
	}

	protected boolean validate_form() {
		/*
		 * String err = null;
		 * 
		 * if(err == null && form.validate()){ return true; }else{
		 * SC.say("Validation Error",err); return false; }
		 */

		if (form.validate()) {
			return true;
		} else {
			return false;
		}

	}

	protected void save_new_person() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				person = new Person();
				person.setFirstName(fname.getValueAsString());
				person.setAddress(address.getValueAsString());
				person.setLastName(mname.getValueAsString());
				person.setSurname(surname.getValueAsString());
				person.setMobileNumber(mobilenum.getValueAsString());
				person.setCreatedOn(d);
				person.setCityId(Integer.parseInt(city.getValue().toString()));
				person.setStatusId(Integer.parseInt(status.getValue()
						.toString()));

				getUiHandlers().onSaveNewButtonClicked(person);

			} catch (Exception e) {
				Log.info("PersonView.Save New Error...................."
						+ e.getMessage());
			} finally {
				person = null;
			}

		}

	}

	protected void update_person() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				person = new Person();
				person.setPersonId(Integer.parseInt(person_id_txt.getValue()
						.toString()));
				person.setFirstName(fname.getValueAsString());
				person.setAddress(address.getValueAsString());
				person.setLastName(mname.getValueAsString());
				person.setSurname(surname.getValueAsString());
				person.setMobileNumber(mobilenum.getValueAsString());
				person.setModifiedOn(d);
				person.setCityId(Integer.parseInt(city.getValue().toString()));
				person.setStatusId(Integer.parseInt(status.getValue()
						.toString()));

				getUiHandlers().onUpdateButtonClicked(person);

			} catch (Exception e) {
				Log.info("PersonView.Update Error...................."
						+ e.getMessage());
			} finally {
				person = null;
			}

		}

	}

	protected void resetForm() {
		form.clearValue(CITY);
		form.clearValue(FNAME);
		form.clearValue(MNAME);
		form.clearValue(MOBILE_NUM);
		form.clearValue(SURNAME);
		form.clearValue(ADDRESS);

		save_btn.disable();
		save_close_btn.disable();
		update_btn.disable();

		if (getUiHandlers() != null) {
			getUiHandlers().onNewButtonClicked();
		}
	}

	public void build_add_form() {
		fname = new TextItem(FNAME, constants.fname_lbl());
		fname.setSelectOnFocus(true);
		// fname.setWrapTitle(false);
		// fname.setDefaultValue("[Account Name]");
		fname.setRequired(false);

		mname = new TextItem(MNAME, constants.mname_lbl());
		mname.setSelectOnFocus(true);
		mname.setRequired(false);

		city = new SelectItem(CITY, constants.city_lbl());
		city.setType("comboBox");
		city.setDefaultToFirstOption(true);
		city.setRequired(true);
		city.setValueField(CityRecord.CITY_ID);
		city.setDisplayField(CityRecord.CITY_NAME);

		surname = new TextItem(SURNAME, constants.surname_lbl());
		surname.setRequired(true);

		address = new TextItem(ADDRESS, constants.address_lbl());
		// address.setIcons(unit_charge_pki);

		mobilenum = new TextItem(MOBILE_NUM, constants.mobile_num_lbl());
		// mobilenum.setRequired(true);
		
		Date d = new Date();
		created_on = new TextItem(CREATED_ON, constants.created_on_lbl());
		// created_on.setRequired(true);
		created_on.setValue(d.toString()); // System.currentTimeMillis()
		created_on.disable();

		person_id_txt = new TextItem(PERSON_ID, "");
		person_id_txt.setVisible(false);

		status = new SelectItem(STATUS, constants.person_status_lbl());
		status.setType("comboBox");
		status.setRequired(true);
		status.setValueField("statusId");
		status.setDisplayField("statusName");

		form_section = new SectionItem(FORM_SECTION);
		form_section.setDefaultValue(constants.person_info_section_name());
		form_section.setItemIds(SURNAME, MOBILE_NUM, CITY, "rowSpacer1", FNAME,
				STATUS, ADDRESS, "rowSpacer2", MNAME, CREATED_ON,"rowSpacer3");

		RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer3 = new RowSpacerItem("rowSpacer3");
		rowSpacer1.setStartRow(false);

		/*
		 * RowSpacerItem rowSpacer4 = new RowSpacerItem("rowSpacer4");
		 * rowSpacer1.setStartRow(false);
		 */

		form.setMargin(2);
		form.setNumCols(6);
		form.setCellPadding(2);
		form.setAutoFocus(false);
		form.setWrapItemTitles(false);
		form.setWidth("100%");

		// no ":" after the field name
		form.setTitleSuffix(" ");
		form.setRequiredTitleSuffix("*");
		form.setFields(form_section, surname, mobilenum, city, rowSpacer1,
				fname, status, address, rowSpacer2, mname, created_on,
				rowSpacer3);

	}

	@Override
	public void setStatusDSource(List<PersonStatus> status_lst,
			boolean new_person) {
		if (status_lst != null) {
			StatusRecord r;
			status_ds = StatusDataSource.getInstance();

			for (PersonStatus status : status_lst) {
				r = new StatusRecord();
				r.setStatusID(status.getStatusId());
				r.setStatusName(status.getStatusName());

				status_ds.addData(r);
			}

			status.setOptionDataSource(status_ds);

			if (new_person) {
				status.setValue(1);
			}
		}
	}

	@Override
	public void setCityDSource(List<City> city_dtos) {
		if (city_dtos != null) {
			CityRecord r;
			city_ds = CityDataSource.getInstance();

			for (City city : city_dtos) {
				r = new CityRecord();
				r.setCityID(city.getCityId());
				r.setCityName(city.getCityName());

				city_ds.addData(r);
			}

			city.setOptionDataSource(city_ds);
			city.setDefaultToFirstOption(true);
		}
	}

	@Override
	public void setSaveNewSuccess() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setPersonDetails(Person person) {
		fname.setValue(person.getFirstName());
		address.setValue(person.getAddress());
		mname.setValue(person.getLastName());
		status.setValue(person.getStatusId());
		created_on.setValue(person.getCreatedOn());
		surname.setValue(person.getSurname());
		mobilenum.setValue(person.getMobileNumber());
		form_section.setValue(form_section.getValue() + ": "
				+ person.getSurname().toUpperCase() + " "
				+ person.getFirstName().toUpperCase());
		person_id_txt.setValue(person.getPersonId());
city.setValue(person.getCityId());

		fname.enable();
		mname.enable();
		city.enable();
		address.enable();
		mobilenum.enable();
		status.enable();
		update_btn.enable();
		surname.enable();
	}

	@Override
	public void setUpdateSuccess() {
		maincontainer.removeMember(form_tbar);
		maincontainer.removeMember(form);
		SC.say(constants.record_update_success());
	}

	// -----------------------------------------------------------------------------------------------------------------
}