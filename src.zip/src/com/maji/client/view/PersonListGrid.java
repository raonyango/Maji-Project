package com.maji.client.view;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.maji.client.view.model.PersonRecord;
import com.maji.client.widgets.ContextListGrid;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ExpansionMode;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class PersonListGrid extends ContextListGrid {
	private static final String SERVICE_ICON = "dashboard";

	private static final int PERSON_NAME_COLUMN_WIDTH = 150;
	private static final int PERSON_ADDRESS_COLUMN_WIDTH = 190;
	private static final int CREATED_ON_COLUMN_WIDTH = 150; // 220
	private static final int TELEPHONE_COLUMN_WIDTH = 120;// 100
	private static final int STATUS_COLUMN_WIDTH = 90;
	/*private static final int SERVICE_DETAILS_COLUMN_WIDTH = 80;
	private static final int SERVICE_LAST_UPDATE_COLUMN_WIDTH = 90;
	private static final String HILITE_BOUGHT_ID = "0";*/

	private EventBus eventbus;
	private MajiStrings constants;
	private PersonRecord[] addonrecords;

	@Inject
	public PersonListGrid(MajiStrings constants, EventBus eventbus) {
		super();
		this.eventbus = eventbus;
		this.constants = constants;
		this.setCanExpandRecords(true);
		this.setExpansionMode(ExpansionMode.RELATED);// DETAIL_FIELD);
		// this.setDetailField(PersonRecord.SERVICE_ID);
		this.setShowRecordComponents(true);
		this.setShowRecordComponentsByCell(true);
		//this.setHiliteProperty(PersonRecord.SERVICE_HILITE);
		this.setEmptyMessage(constants.no_record_msg());

		//this.setStyleName(MajiCSS.context_area);
		//this.setAlternateRecordStyles(true);
		//this.setAlternateBodyStyleName(MajiCSS.grid_alternating);
		
		// initialise the List Grid fields
		ListGridField iconfield = new ListGridField(PersonRecord.ICON,
				PersonRecord.ICON_DISPLAY_NAME, ICON_COLUMN_WIDTH);
		iconfield.setImageSize(16);
		iconfield.setAlign(Alignment.CENTER);
		iconfield.setType(ListGridFieldType.IMAGE);
		iconfield.setImageURLPrefix(URL_PREFIX);
		iconfield.setImageURLSuffix(URL_SUFFIX);

		ListGridField surname_field = new ListGridField(
				PersonRecord.SURNAME, constants.surname_lbl(),
				PERSON_NAME_COLUMN_WIDTH);
		ListGridField first_name_field = new ListGridField(
				PersonRecord.FIRST_NAME, constants.first_name_lbl(),
				PERSON_NAME_COLUMN_WIDTH);
		ListGridField last_name_field = new ListGridField(
				PersonRecord.LAST_NAME, constants.last_name_lbl(),
				PERSON_NAME_COLUMN_WIDTH);
		ListGridField address_field = new ListGridField(
				PersonRecord.PERSON_ADDRESS, constants.person_address_lbl(),
				PERSON_ADDRESS_COLUMN_WIDTH);

		ListGridField telephone_field = new ListGridField(
				PersonRecord.PERSON_TELEPHONE,
				constants.person_telephone_lbl(), TELEPHONE_COLUMN_WIDTH);
		telephone_field.setCellAlign(Alignment.LEFT);
		// servicebuy_field.setType(ListGridFieldType.BOOLEAN);

		ListGridField created_on_field = new ListGridField(
				PersonRecord.CREATED_ON, constants.person_created_on_lbl(),
				CREATED_ON_COLUMN_WIDTH);
		created_on_field.setCellAlign(Alignment.LEFT);

		created_on_field.setType(ListGridFieldType.TIME);
		created_on_field.setDateFormatter(DateDisplayFormat.TOSERIALIZEABLEDATE);
		
		ListGridField status_field = new ListGridField(PersonRecord.STATUS_NAME,
				constants.person_status_lbl(), STATUS_COLUMN_WIDTH);

		/*
		 * ListGridField servicelastupdatetime_field = new ListGridField(
		 * PersonRecord.SERVICE_LAST_UPDATE_TIME, constants
		 * .service_last_update_time_lbl(), SERVICE_LAST_UPDATE_COLUMN_WIDTH);
		 * servicelastupdatetime_field.setType(ListGridFieldType.TIME);
		 * servicelastupdatetime_field.setCellAlign(Alignment.CENTER);
		 * servicelastupdatetime_field
		 * .setTimeFormatter(TimeDisplayFormat.TO24HOURTIME);
		 */

		ListGridField empty_field = new ListGridField(EMPTY_FIELD,
				EMPTY_FIELD_DISPLAY_NAME);

		// set the fields into the List Grid
		this.setFields(new ListGridField[] { iconfield, surname_field,first_name_field, last_name_field,
				telephone_field, address_field, status_field, created_on_field,
				empty_field });
	}

	public void setServicesResultSet(List<Person> person_dtos) {
		try {

			int ctr = 0, ctr2 = 0;
						
			PersonRecord[] personrecords = new PersonRecord[person_dtos.size()];
			addonrecords = new PersonRecord[ctr];
			ctr = 0;
			for (int i = 0; i < person_dtos.size(); i++) {
				personrecords[ctr2] = createServiceRecord(person_dtos.get(i));
				ctr2++;
			}
			
			// populate the List Grid
			this.setData(personrecords);
			//this.setHilites(hilites);
		} catch (Exception e) {
			Log.error("PersonListGrid Error...................." + e.getLocalizedMessage());
			Log.error( e.getStackTrace().toString());
		}
	}

	private PersonRecord createServiceRecord(Person person_dto) {
		return new PersonRecord(SERVICE_ICON, person_dto.getPersonId(),
				person_dto.getFirstName(), person_dto.getSurname(),
				person_dto.getLastName(), person_dto.getMobileNumber(),
				person_dto.getAddress(), person_dto.getStatusId(),
				person_dto.getCreatedBy(), person_dto.getCreatedOn(),
				person_dto.getCityId(), person_dto.getStatusName());
	}

/*	@Override
	protected Canvas createRecordComponent(final ListGridRecord record,
			Integer colNum) {
		String field = this.getFieldName(colNum);
		IButton button = null;
		if (field.equals(PersonRecord.PERSON_TELEPHONE)) {
			button = createGridButton("$");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(PersonRecord.PERSON_ID)));
				}
			});
			if (record.getAttributeAsBoolean(PersonRecord.PERSON_TELEPHONE)) {
				button.disable();
			}
			return button;
		} else if (field.equals(PersonRecord.CREATED_ON)) {
			button = createGridButton(">>");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(PersonRecord.PERSON_ID)));
				}
			});
			if (!record.getAttributeAsBoolean(PersonRecord.CREATED_ON)) {
				button.disable();
			}
			return button;
		} else {
			return null;// createRecordComponent(record, colNum);
		}
		
		return createRecordComponent(record, colNum);
	}*/

	private IButton createGridButton(String title) {
		IButton button = new IButton();
		button.setHeight(18);
		button.setWidth(35);
		// button.setIcon("flags/16/" + record.getAttribute("countryCode") +
		// ".png");
		button.setTitle(title);
		return button;
	}

	/*private static Hilite[] hilites = new Hilite[] { new Hilite() {
		{
			// setFieldNames(PersonRecord.FIRST_NAME);
			setId(HILITE_BOUGHT_ID);
			setTextColor("#18187C");
			setBackgroundColor("#DCDCDC");
			setCriteria(new Criterion(PersonRecord.PERSON_TELEPHONE,
					OperatorId.EQUALS, true));
			// setCriteria(new AdvancedCriteria(OperatorId.AND, new Criterion[]
			// {new Criterion(PersonRecord.PERSON_TELEPHONE, OperatorId.EQUALS,
			// true)}));
			// setCssText("font-weight:bolder;color:#18187C;background-color:#DCDCDC");
		}
	} };*/

	@Override
	protected Canvas getExpansionComponent(final ListGridRecord record) {
		final PersonListGrid grid = this;
		PersonRecord[] arr;
		ContextListGrid addonsgrid;

		VLayout layout = new VLayout(5);
		layout.setPadding(5);

		/*
		 * addonsgrid = new AddonsListGrid(constants, eventbus);
		 * addonsgrid.setWidth100();//500 addonsgrid.setHeight(134);//224
		 * addonsgrid.setCellHeight(22);
		 * addonsgrid.setHiliteProperty(PersonRecord.SERVICE_HILITE);
		 * addonsgrid.setEmptyMessage(constants.no_addons_msg() + " " +
		 * constants.formsg() + " " +
		 * record.getAttributeAsString(PersonRecord.FIRST_NAME));
		 * 
		 * arr =
		 * getRelatedAddons(record.getAttributeAsInt(PersonRecord.SERVICE_ID));
		 * if(arr != null){ addonsgrid.setData(arr);
		 * addonsgrid.setHilites(hilites); }
		 * //addonsgrid.setDataSource(getRelatedDataSource(record));
		 * //addonsgrid.fetchRelatedData(record,
		 * SupplyCategoryXmlDS.getInstance());
		 * 
		 * layout.addMember(addonsgrid);
		 */
		HLayout hcontainer = new HLayout(10);
		hcontainer.setAlign(Alignment.CENTER);

		Button close_btn = new Button(constants.hide_btn());
		close_btn.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				grid.collapseRecord(record);
			}
		});
		close_btn.setWidth(80);
		close_btn.setLayoutAlign(Alignment.RIGHT);
		hcontainer.addMember(close_btn);

		layout.addMember(hcontainer);

		return layout;
	}
}
