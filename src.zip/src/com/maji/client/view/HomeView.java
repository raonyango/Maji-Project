package com.maji.client.view;

import com.google.gwt.user.client.Window;
import com.google.inject.Inject;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.maji.client.presenter.HomePresenter;

public class HomeView implements HomePresenter.IHomeViewDisplay  {

	private Layout appContainer, centralContainer;
        
    @Inject
    public HomeView(MajiStrings constants) { 
    	centralContainer = new VLayout();
        centralContainer.addStyleName(MajiCSS.brainup_rnd_container_no_border);        
        centralContainer.addStyleName(MajiCSS.main_container);        
        
        appContainer = new VLayout();
    	appContainer.addStyleName(MajiCSS.app_container);
        appContainer.setWidth(Window.getClientWidth() + "px");
        appContainer.setHeight(Window.getClientHeight() + "px");       
        appContainer.setMembers(centralContainer);
        
    }

    public Layout asWidget() {
        return appContainer;
    }

    private Layout currentwidget;
    
    public void addWidget(Layout widget) {
    	//Delay adding the widget until it is shown in showWidget()
    }

    public void removeWidget(Layout widget) {
    	centralContainer.removeMember(widget);
    }

    public void showWidget(Layout widget) {
    	//appContainer.setMembers(widget);
    	//widget.addStyleName(MajiCSS.main_container);
    	if(currentwidget != null){
    		removeWidget(currentwidget);
    	}
    	centralContainer.addMember(widget);
    	currentwidget = widget;
    	
    }
}
