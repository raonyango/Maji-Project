package com.maji.client.widgets;

import com.extjs.gxt.ui.client.util.Point;
import com.extjs.gxt.ui.client.widget.Info;
import com.extjs.gxt.ui.client.widget.InfoConfig;

public class GXTInfoPopup extends Info {

	@Override
	protected void onShowInfo() {
		super.onShowInfo();
	}

	public static void show(String title, String message) {
		show(title, message, 4000);
	}

	public static void show(String title, String message, int miliseconds) {

		GXTInfoPopup info = new GXTInfoPopup();

		InfoConfig config = new InfoConfig(title, message);
		config.display = miliseconds;

		info.setBodyStyle("background-color: #E0E0E0; text-align: center; border: 0x solid black; padding: 3px; font-size: 12px; font-color: black; font-weight: bold;");
		info.setFrame(false);
		info.setAnimCollapse(true);
		info.show(config);

		/*info.setAutoHeight(true);
		info.setAutoWidth(false);
		info.setWidth(info.getWidth() + 30);*/
		Point p = info.position();
		p.x = ((p.x + info.getWidth()) / 2) - (info.getWidth() / 2);
		p.y = ((p.y + info.getHeight()) / 2) - (info.getHeight() / 2);
		
		info.setPosition(p.x, p.y);

	}
}