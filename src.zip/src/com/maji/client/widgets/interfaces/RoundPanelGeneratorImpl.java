package com.maji.client.widgets.interfaces;

import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Panel;
import com.maji.shared.properties.MajiCSS;

/**
 * Simple generator of rounded panels using css.
 * It works in FF, safari, chrome and opera.
 * 
 * It is needed to define this in your css.
 * <pre>
 *  div.rounded {
 *       border: 1px solid #7FAAFF 
 *       -moz-border-radius: 8px;
 *       -webkit-border-radius: 6px;
 *     }
 * </pre>
 *
 */
public class RoundPanelGeneratorImpl implements RoundPanelGenerator {

    public Panel roundPanel(Panel panel) {
        panel.addStyleName(MajiCSS.brainup_rnd_container);
        return panel;
    }

    public FlowPanel createPanel() {
        return new FlowPanel() {
            @Override
            public void setStyleName(String style) {
                super.setStyleName(style);
                super.addStyleName(MajiCSS.brainup_rnd_container);
            }
        };
    }
}
