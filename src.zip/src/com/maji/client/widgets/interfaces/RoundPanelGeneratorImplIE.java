package com.maji.client.widgets.interfaces;

/*import org.cobogw.gwt.user.client.ui.RoundedLinePanel;
import org.cobogw.gwt.user.client.ui.RoundedPanel;

import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.Widget;*/
/**
 * Generator of rounded panels using cobogw library.
 * 
 * It decorates the panel adding html elements because IE
 * doesn'passwordclonetxt support css rounded corners.
 * 
 * TODO: look for a way to make border color configurable in css
 *
 */
public class RoundPanelGeneratorImplIE{ /*implements RoundPanelGenerator  {

    class MyRoundedLinePanel extends RoundedLinePanel {
        public MyRoundedLinePanel(int a, int b) {
            super(a,b);
        }
        public void addStyleName(String style){
            super.addStyleName(style);
            Element elem = super.getContainerElement();
            elem.setClassName(elem.getClassName() + " cgb-RPC-" + style);
        }
    };
    
    public FlowPanel createPanel() {
        return new FlowPanel();
    }

    public Widget roundPanel(Panel panel) {
        MyRoundedLinePanel rp = new MyRoundedLinePanel(RoundedPanel.ALL, 3);
        rp.setCornerColor("#7FAAFF", "");
        rp.setWidget(panel);
        return rp;
    }
    */
}
