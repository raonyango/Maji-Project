package com.maji.client.widgets;

import com.google.gwt.dom.client.Element;
import com.google.gwt.i18n.shared.DirectionEstimator;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.ui.HTML;
import com.maji.shared.properties.MajiCSS;

public class FormHTML extends HTML{

	public FormHTML(){
		super();
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(SafeHtml html){
		super(html);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(String html){
		super(html);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(SafeHtml html, DirectionEstimator directionEstimator){
		super(html, directionEstimator);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(Element element){
		super(element);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(SafeHtml html, Direction dir){
		super(html, dir);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(String html, boolean wordWrap){
		super(html, wordWrap);
		this.addStyleName(MajiCSS.form_html);
	}
	
	public FormHTML(String html, Direction dir){
		super(html, dir);
		this.addStyleName(MajiCSS.form_html);
	}
}
