package com.maji.client.widgets;

import net.customware.gwt.presenter.client.EventBus;

import com.google.gwt.user.client.History;
import com.maji.client.data.NavigationPaneSectionDataSource;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.UserAccountEvent;
import com.maji.client.event.UserAccountEventHandler;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.SectionStackSection;
//import com.allen_sauer.gwt.log.client.Log;

public class NavigationPaneSection extends SectionStackSection {

	private NavigationPaneSectionListGrid listgrid;

	public NavigationPaneSection(EventBus eventbus, String sectionName,
			DataSource dataSource) {
		super(sectionName);

		this.setID(sectionName);

		listgrid = new NavigationPaneSectionListGrid(dataSource);

		this.addItem(listgrid);
		this.setExpanded(true);

		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {

			@Override
			public void onRefreshApplication(RefreshEvent event) {
				if (History.getToken() != null) {
					if (!History.getToken().trim().equals("")) {
						int index = getRecord(History.getToken());
						ListGridRecord[] records = listgrid.getRecords();
						//Log.info("....................................index:" + index + ":records:" + records.length);
						if (index != -1 && index < records.length) {
							listgrid.deselectAllRecords();
							selectRecord(index);
						}
					}
				}
			}
		});

		eventbus.addHandler(UserAccountEvent.TYPE, new UserAccountEventHandler() {
			
			@Override
			public void onShowAccount(UserAccountEvent event) {
				ListGridRecord[] records = listgrid.getRecords();
				if (records.length > 0) {
					listgrid.deselectAllRecords();
					selectRecord(0);
				}
			}
		});
	}

	public ListGrid getListGrid() {
		return listgrid;
	}

	public void selectRecord(int record) {
		listgrid.selectRecord(record);
	}

	public int getRecord(String name) {
		int result = -1;

		ListGridRecord[] records = listgrid.getRecords();
		ListGridRecord record = null;
		String recordName = "";

		/*if (Log.isDebugEnabled()) {
			if (records.length == 0) {
				// see NavigationPaneSectionListGrid -> onDataArrived()
				//Log.debug("No data has arrived...");
			}
		}*/

		for (int i = 0; i < records.length; i++) {

			record = listgrid.getRecord(i);
			// as per NavigationPaneSectionListGrid
			recordName = record
					.getAttributeAsString(NavigationPaneSectionDataSource.NAME);

			if (name.contentEquals(recordName)) {
				//Log.debug("name.contentEquals(recordName)");
				result = i;
				break;
			}
		}

		return result;
	}

	public String getSelectedRecord() {
		String name = "";

		ListGridRecord[] records = listgrid.getSelectedRecords();

		if (records.length != 0) {
			// get the name of the first selected record e.g. "person"
			name = records[0]
					.getAttributeAsString(NavigationPaneSectionDataSource.NAME);
		} else {
			//Log.debug("getSelectedRecord() - No selected record in ListGrid");

			ListGridRecord record = listgrid.getRecord(0);

			// see NavigationPaneSectionListGrid - DataArrivedHandler()
			if (record != null) {
				// get the name of the first record in the ListGrid e.g.
				// "person"
				name = record
						.getAttributeAsString(NavigationPaneSectionDataSource.NAME);
			}
		}

		//Log.debug("getSelectedRecord() - " + name);

		return name;
	}

	public void selectRecord(String name) {
		//Log.debug("selectRecord(name) - " + name);

		ListGridRecord[] records = listgrid.getRecords();
		ListGridRecord record = null;
		String recordName = "";

		for (int i = 0; i < records.length; i++) {

			record = listgrid.getRecord(i);
			recordName = record
					.getAttributeAsString(NavigationPaneSectionDataSource.NAME);

			if (name.contentEquals(recordName)) {
				//Log.debug("name.contentEquals(recordName)");
				listgrid.deselectAllRecords();
				listgrid.selectRecord(i);
				break;
			}
		}
	}

	public void addRecordClickHandler(RecordClickHandler clickHandler) {
		listgrid.addRecordClickHandler(clickHandler);
	}
}
