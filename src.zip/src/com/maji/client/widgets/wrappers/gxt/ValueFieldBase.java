package com.maji.client.widgets.wrappers.gxt;

import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.FocusEvent;
import com.google.gwt.event.dom.client.FocusHandler;
import com.google.gwt.event.dom.client.HasChangeHandlers;
import com.google.gwt.event.dom.client.HasFocusHandlers;
import com.google.gwt.event.dom.client.HasKeyUpHandlers;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.event.logical.shared.HasValueChangeHandlers;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.text.shared.Renderer;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.ui.Focusable;
import com.google.gwt.user.client.ui.HasName;
import com.google.gwt.user.client.ui.HasValue;

public class ValueFieldBase<T> extends
		com.extjs.gxt.ui.client.widget.form.TextField<T> implements Focusable,
		HasChangeHandlers, HasValueChangeHandlers<T>, HasFocusHandlers, HasKeyUpHandlers, HasName, HasValue<T> {

	private boolean valueChangeHandlerInitialized;
	private Renderer<T> renderer = null;
	
	protected ValueFieldBase(Renderer<T> renderer) {
	   this.renderer = renderer;	    
	}
	
	public ValueFieldBase() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setAccessKey(char key) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setFocus(boolean focused) {
		// TODO Auto-generated method stub

	}

	@Override
	public HandlerRegistration addChangeHandler(ChangeHandler handler) {
		return addDomHandler(handler, ChangeEvent.getType());
	}

	public void setText(String text) {
		DOM.setElementProperty(getElement(), "value", text != null ? text : "");

	}

	@Override
	public void setValue(T value, boolean fireEvents) {
		T oldValue = getValue();
		setText(renderer.render(value));
		if (fireEvents) {
			ValueChangeEvent.fireIfNotEqual(this, oldValue, value);
		}
	}

	@Override
	public HandlerRegistration addValueChangeHandler(
			ValueChangeHandler<T> handler) {
		// Initialization code
		if (!valueChangeHandlerInitialized) {
			valueChangeHandlerInitialized = true;
			addChangeHandler(new ChangeHandler() {
				public void onChange(ChangeEvent event) {
					ValueChangeEvent.fire(ValueFieldBase.this, getValue());
				}
			});
		}
		return addHandler(handler, ValueChangeEvent.getType());
	}

	@Override
	public HandlerRegistration addFocusHandler(FocusHandler handler) {
		return addDomHandler(handler, FocusEvent.getType());
	}

	@Override
	public HandlerRegistration addKeyUpHandler(KeyUpHandler handler) {
		return addDomHandler(handler, KeyUpEvent.getType());
	}

}