package com.maji.client.widgets;

import com.google.gwt.i18n.client.NumberFormat;
import com.smartgwt.client.widgets.grid.ListGrid;

public class ContextListGrid extends ListGrid {

	public static final String EMPTY_FIELD = "emptyfield";
	public static final String EMPTY_FIELD_DISPLAY_NAME = " ";

	public static final String URL_PREFIX = "icons/16/";
	public static final String URL_SUFFIX = ".png";
	public static final int ICON_COLUMN_WIDTH = 20; // 27
	//private List<PersonDto> tosave_lst;
	
	public ContextListGrid() {
		super();
		this.setShowAllRecords(true);
	}
	
	public String formatFloat(Object value){
		if (value == null) {
			return null;
		} else {
			NumberFormat nf;
			if (((Number) value).intValue() >= 1000) {
				nf = NumberFormat.getFormat("#,##0.00");
			} else {
				nf = NumberFormat.getFormat("##0.00");
			}

			try {
				return nf.format(((Number) value).floatValue());
			} catch (Exception e) {
				return value.toString();
			}
		}
	}
	
	public String formatInt(Object value){
		 if(value == null) 
         	return null;  
         
         if(((Number) value).intValue() >= 1000){
             NumberFormat nf = NumberFormat.getFormat("0,000");  
             try {  
                 return nf.format(((Number) value).intValue());  
             } catch (Exception e) {  
                 return value.toString();  
             } 
         }else{
         	return value.toString();
         }
	}
		
	/*public PersonDto createServiceDto(PersonRecord service_r) {
		PersonDto s = new PersonDto();
		s.setId(service_r.getId());
		s.setServiceid(service_r.getServiceId());							
		s.setNewquantity(service_r.getNewQuantity());
		s.setUpdated(service_r.getServiceUpdated());
		s.setDeleted(service_r.getServiceDeleted());
		
		return s;
	}*/
	

	/*public List<PersonDto> getToSaveList() {
		return tosave_lst;
	}*/
	
	public void initToSaveList() {
		//tosave_lst = new ArrayList<PersonDto>();
	}
	
	public void clearToSaveList(){
		//tosave_lst.clear();
	}
}
