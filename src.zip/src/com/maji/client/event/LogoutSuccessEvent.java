package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class LogoutSuccessEvent extends GwtEvent<LogoutSuccessEventHandler> {
	public static Type<LogoutSuccessEventHandler> TYPE = new Type<LogoutSuccessEventHandler>();
	private UserLoginData userLoginData;

	public LogoutSuccessEvent(UserLoginData userLoginData) {
		this.userLoginData = userLoginData;
	}

	@Override
	protected void dispatch(LogoutSuccessEventHandler handler) {
		handler.onLogoutSuccess(this);
	}

	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<LogoutSuccessEventHandler> getAssociatedType() {
		return TYPE;
	}

	public UserLoginData getUserLoginData() {
		return userLoginData;
	}

}
