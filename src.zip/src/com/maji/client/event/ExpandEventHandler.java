
package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ExpandEventHandler extends EventHandler{
    public void onExpandService(ExpandEvent event);
}
