package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface RefreshEventHandler extends EventHandler{
    public void onRefreshApplication(RefreshEvent event);
}
