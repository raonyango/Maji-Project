package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface LoginSuccessEventHandler extends EventHandler{
    
    public void onLoginSuccess(LoginSuccessEvent event);

}
