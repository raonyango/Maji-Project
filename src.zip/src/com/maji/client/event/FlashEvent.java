package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class FlashEvent extends GwtEvent<FlashEventHandler> {
    
    public static Type<FlashEventHandler> TYPE = new Type<FlashEventHandler>();
    
    public String getMessage() {
        return message;
    }

    public int getMillisec() {
        return millisec;
    }

    String message;
    int millisec;
    
    public FlashEvent(String message) {
        this(message, 0);
    }
    
    public FlashEvent(String message, int millisec) {
        this.message = message;
        this.millisec = millisec;
    }

    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<FlashEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(FlashEventHandler handler) {
        handler.onFlash(this);
    }
    
}
