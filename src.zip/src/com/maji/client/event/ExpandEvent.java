package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ExpandEvent extends GwtEvent<ExpandEventHandler> {
    
    public static Type<ExpandEventHandler> TYPE = new Type<ExpandEventHandler>();
    
    private int serviceid;
  
	public int getServiceid() {
		return serviceid;
	}
	
    public ExpandEvent(int serviceid) {
        this.serviceid = serviceid;
    }
    
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<ExpandEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(ExpandEventHandler handler) {
        handler.onExpandService(this);
    }   
}
