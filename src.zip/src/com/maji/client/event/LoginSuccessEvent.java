package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class LoginSuccessEvent extends GwtEvent<LoginSuccessEventHandler>{

    public static Type<LoginSuccessEventHandler> TYPE = new Type<LoginSuccessEventHandler>();
    private UserLoginData userLoginData;
    
	public LoginSuccessEvent(UserLoginData userLoginData) {
		this.userLoginData = userLoginData;
    }

	public UserLoginData getUser() {
        return userLoginData;
    }
	
    @Override
    public Type<LoginSuccessEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(LoginSuccessEventHandler handler) {
        handler.onLoginSuccess(this);
    }

}
