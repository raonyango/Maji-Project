package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface LoginErrorEventHandler extends EventHandler{
    public void onNewError(LoginErrorEvent event);
}
