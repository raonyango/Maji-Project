package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class LogoutEvent extends GwtEvent<LogoutEventHandler>{
    public static Type<LogoutEventHandler> TYPE = new Type<LogoutEventHandler>();
    private UserLoginData userLoginData;
    public LogoutEvent(UserLoginData userLoginData) {
        this.userLoginData = userLoginData;
    }

    @Override
    protected void dispatch(LogoutEventHandler handler) {
        handler.onLogout(this);
    }

    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<LogoutEventHandler> getAssociatedType() {
        return TYPE;
    }
    
    public UserLoginData getUserLoginData() {
        return userLoginData;
    }

}
