package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class SessionExpireEvent extends GwtEvent<SessionExpireEventHandler>{

    public final static Type<SessionExpireEventHandler> TYPE = new Type<SessionExpireEventHandler>();
    private UserLoginData userLoginData;
    @Override
    protected void dispatch(SessionExpireEventHandler handler) {
        handler.onSessionExpireEvent(this);
    }

    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<SessionExpireEventHandler> getAssociatedType() {
        return TYPE;
    }
    
    public SessionExpireEvent(UserLoginData userLoginData) {
        this.userLoginData = userLoginData;
    }
    
    public UserLoginData getUser() {
        return userLoginData;
    }
}
