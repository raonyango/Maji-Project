package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface LogoutSuccessEventHandler extends EventHandler{

    public void onLogoutSuccess(LogoutSuccessEvent logoutsuccessEvent);
}
