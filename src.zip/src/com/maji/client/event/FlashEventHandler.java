package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface FlashEventHandler extends EventHandler{
    public void onFlash(FlashEvent event);
}
