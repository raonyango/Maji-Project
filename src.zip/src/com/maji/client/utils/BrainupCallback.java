package com.maji.client.utils;

/*import net.customware.gwt.dispatch.client.DispatchAsync;
import net.customware.gwt.presenter.client.Display;

import com.brainup.client.event.LogoutEvent;
import com.brainup.client.event.ServerStatusEvent;
import com.brainup.client.event.ServerStatusEvent.ServerStatus;
import com.brainup.shared.exception.InvalidSessionException;
import com.brainup.shared.rpc.CheckSession;
import com.brainup.shared.rpc.CheckSessionResult;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;*/

public abstract class BrainupCallback{/*<T> implements AsyncCallback<T> {
    
    private DispatchAsync dispatcher = null;
    private EventBus eventBus = null;
    private ServerStatusEvent available = new ServerStatusEvent(ServerStatus.Available); 
    private ServerStatusEvent unavailable = new ServerStatusEvent(ServerStatus.Unavailable); 

    @SuppressWarnings("unused")
    private Display display = null;

    @Inject
    public BrainupCallback(DispatchAsync dispatcher, EventBus bus, Display display) {
        this(dispatcher, bus);
        this.display = display;
        
       //this.display.startProcessing();
    }
    
    @Inject
    public BrainupCallback(DispatchAsync dispatcher, EventBus bus) {
        this.dispatcher = dispatcher;
        this.eventBus = bus;
    }

    *//**
     * If you override this method, remember to call super.onFailure() 
     *//*
    public void onFailure(final Throwable originalCaught) {
        // Server's response is invalid due to:
        // server unaccessible, session error or server exception
        dispatcher.execute(new CheckSession(), new AsyncCallback<CheckSessionResult>() {
            public void onFailure(Throwable caught) {
                if (caught instanceof InvalidSessionException) {
                    eventBus.fireEvent(new LogoutEvent(null));
                } else {
                    // The server is unaccessible
                    eventBus.fireEvent(unavailable);
                }
                finish();
            }
            public void onSuccess(CheckSessionResult result) {
                if (!result.isValid()) {
                    // Server's connection is fine, but the user has not a valid session
                    eventBus.fireEvent(new LogoutEvent(null));
                } else {
                    // Server's connection is fine, and the user has a valid session
                    // So the original action failed because a server's exception 
                    eventBus.fireEvent(available);
                }
                finish();
            }

            private void finish() {
                callbackError(originalCaught);
                //if (display != null)
                    //display.stopProcessing();
            }
        });
    }
    
    *//**
     * If you override this method, remember to call super.onSuccess() 
     *//*
    public void onSuccess(T result) {
        // Server's response is valid,
        eventBus.fireEvent(available);
        // Execute the original method
        callback(result);
        // If display is being used, stop it
        //if (display != null)
            //display.stopProcessing();
    }
    
    *//**
     * The callback code which the user has to implement
     * @param result
     *//*
    public abstract void callback(T result); 

    *//**
     * The callback code in the case of error
     * Override this method, if you need this feature.
     *  
     * @param result
     *//*
    public void callbackError(Throwable caught) {
        System.out.println("BrainupCallBack Error: " + caught);
    }
*/
}

