package com.maji.client.utils;

import com.extjs.gxt.ui.client.widget.form.Field;
import com.extjs.gxt.ui.client.widget.form.Validator;
import com.google.inject.Inject;
import com.maji.shared.properties.MajiStrings;

public class FormValidator implements Validator{

	  private VType type;
	  @Inject
	  private MajiStrings constants;
	  
	  public FormValidator(VType type){
	    this.type = type;
	  }
	  
	  @Override
	  public String validate(Field<?> field, String value) {
	    String res = null;
	    if(!value.matches(type.regex)){
	      res = value + " " + constants.is_not_a_valid() + " " + type.name;
	    }
	    return res;
	  }
		public enum VType {
			  ALPHABET("^[a-zA-Z_]+$", "Alphabet"), 
			  ALPHANUMERIC("^[a-zA-Z0-9_]+$", "Alphanumeric"), 
			  NUMERIC("^[+0-9]+$", "Numeric"),
			  EMAIL("^(\\w+)([-+.][\\w]+)*@(\\w[-\\w]*\\.){1,5}([A-Za-z]){2,4}$", "Email"),
			  LENGTH("^.{1,50}$", "Length"),
			  URL_WITH_TOPLEVELDOMAIN("^((ftp|http|https)://[\\w@.\\-\\_]+\\.[a-zA-Z]{2,}(:\\d{1,5})?(/[\\w#!:.?+=&%@!\\_\\-/]+)*){1}$", "url_with_tld");
			  public String regex;
			  public String name;
		
			  VType(String regex, String name) {
			    this.regex = regex;
			    this.name = name;
			  }
		}
	
	}
