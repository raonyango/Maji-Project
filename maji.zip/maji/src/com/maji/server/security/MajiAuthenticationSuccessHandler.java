package com.maji.server.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

public class MajiAuthenticationSuccessHandler implements
		AuthenticationSuccessHandler {

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		
		//custom changes
		if(request.getParameter("_spring_security_remember_me") != null){
			if(Boolean.parseBoolean(request.getParameter("_spring_security_remember_me")) == true){
				request.getSession().setMaxInactiveInterval(14 * 24 * 60 * 60); // 2 weeks
				response.addHeader("JSESSIONID", request.getSession().getId());		        
			}else{
				request.getSession().setMaxInactiveInterval(10 * 60); // 10 minutes				
			}
		}else{
			request.getSession().setMaxInactiveInterval(10 * 60); // 10 minutes			
		}
        
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.sendError(HttpServletResponse.SC_OK, "Authentication accepted");
        
	}
}
