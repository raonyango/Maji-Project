package com.maji.server.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.maji.server.utils.LoginManager;
import com.maji.server.utils.SystemRolesManager;
import com.maji.server.utils.UserManager;
import com.maji.shared.beans.UserLoginData;

public class MajiAuthenticationProvider implements AuthenticationProvider {
	@Autowired
	private LoginManager loginmanager;
	@Autowired
	private SystemRolesManager sysrolesmanager;	
	@Autowired
	private UserManager usermanager;
	
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		String username = (String) authentication.getPrincipal();
		String password = (String) authentication.getCredentials();

		UserLoginData userdata = loginmanager.authenticateUserSpring(username, password,
				((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession());
		if (userdata == null) {
			throw new BadCredentialsException("::::Invalid Credentials. Username:" + username + "::::");
		}

		/*
		 * User user = usermanager.getUser(username); if(user == null) throw new
		 * UsernameNotFoundException("User not found");
		 * 
		 * String storedPass = user.getPassword();
		 * 
		 * if (!storedPass.equals(password)) throw new
		 * BadCredentialsException("Invalid password");
		 */

		Authentication brainupauthentication = new MajiAuthentication(
				getRole(userdata.getUserRoleId()), authentication); 
		
		try {
			//update last login date
			/*User user = new User();
			user.setId(userdata.getUserId());
			user.setLastlogin(new Date());
			user.setModifiedby(usermanager.getUserSystem().getId()); //user 'SYSTEM'
			user.setModifiedon(new Date());
			
			if(usermanager.updateUser(user)){
				brainupauthentication.setAuthenticated(true);			
			}*/
			
			brainupauthentication.setAuthenticated(true); //--remove on uncommenting
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return brainupauthentication;
	}

	@Override
	public boolean supports(Class<? extends Object> authentication) {
		return UsernamePasswordAuthenticationToken.class
				.isAssignableFrom(authentication);
	}

	private String getRole(int role){		
		/*List<UserRole> systemroles = sysrolesmanager.getSystemRoles();
		if(systemroles != null){
			for(UserRole r: systemroles){
				if(r.getId() == role){
					return r.getRole().toUpperCase();
				}
			}
		}
		return null;*/
		
		return "admin";
	}
}
