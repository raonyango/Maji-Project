package com.maji.server.utils;

import java.io.Console;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.WeakHashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.maji.server.security.BCrypt;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.User;
import com.maji.shared.properties.MajiConstants;

public class LoginManager {
	
	//private static final Logger logger = Logger.getLogger(LoginManager.class);
	@Autowired
	private MajiUtils brainuputils;	
	private ResourceBundle appproperties;
	@Autowired
	private UserManager usermanager;
	
	public LoginManager(){
		
	}
	
	public MajiUtils getBrainuphelper() {
		return brainuputils;
	}

	public void setBrainuphelper(MajiUtils brainuputils) {
		this.brainuputils = brainuputils;
	}
	
	public UserManager getUsermanager() {
		return usermanager;
	}

	public void setUsermanager(UserManager usermanager) {
		this.usermanager = usermanager;
	}

	public ResourceBundle getAppproperties() {
		return appproperties;
	}

	public void setAppproperties(ResourceBundle appproperties) {
		this.appproperties = appproperties;
	}
		
	public StandardServerResponse checkUserSession(UserLoginData logindata, HttpSession session, SessionUtils sessionutils){
		StandardServerResponse response = new StandardServerResponse();
		UserLoginData userdata = null;
		List<UserLoginData> userdatalst = new ArrayList<UserLoginData>();
		try {
			try{
				if(logindata != null){
					if(!logindata.getSessionid().equals(null))
						if(session != null)
							if(session.getAttribute(MajiConstants.USER_SESS_ATTR) != null)
								if(session.getId().equals(logindata.getSessionid()))
									userdata = (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);	
						
				}else{
					if(session != null)
						if(session.getAttribute(MajiConstants.USER_SESS_ATTR) != null)
							userdata = (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
				}
			}catch (Exception e) {					
				e.printStackTrace();
			}
			if(userdata != null){
				if(userdata.isAuthenticated()){
					userdatalst.add(userdata);
					response.setListData(userdatalst);
				}
			}
			
			response.setSuccess(true);
		} catch (Exception e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("checksession_error"));
			
			//logger.error("LoginManager.checkUserSession()");
			//logger.error(e.getStackTrace());
			e.printStackTrace();
		}finally{
			userdata = null;
			userdatalst  = null;
		}
		
		return response;
	}
	
	public StandardServerResponse checkUserSession2(UserLoginData logindata, HttpSession session,  WeakHashMap<String, HttpSession> usersessions, SessionUtils sessionutils){
		StandardServerResponse response = new StandardServerResponse();
		UserLoginData userdata = null;
		List<UserLoginData> userdatalst = new ArrayList<UserLoginData>();
		//session = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest().getSession();
		
		try {
			if(sessionutils.getSessionFromList(session) != null){
				try{
					if(logindata != null)
						if(!logindata.getSessionid().equals(null))
							if(session != null)
								if(session.getAttribute(MajiConstants.USER_SESS_ATTR) != null)
									if(session.getId().equals(logindata.getSessionid()))
										userdata = (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);	
							
					else
						if(session != null)
							if(session.getAttribute(MajiConstants.USER_SESS_ATTR) != null)
								userdata = (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
					
				}catch (Exception e) {					
					e.printStackTrace();
				}
				if(userdata != null){
					if(userdata.isAuthenticated()){
						userdatalst.add(userdata);
						response.setListData(userdatalst);
					}
				}
			}
			response.setSuccess(true);
		} catch (Exception e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("checksession_error"));
			
			//logger.error("LoginManager.checkUserSession()");
			//logger.error(e.getStackTrace());
			e.printStackTrace();
		}finally{
			userdata = null;
			userdatalst  = null;
		}
		
		return response;
	}
	
	public StandardServerResponse logoutUser(String username, HttpSession session, SessionUtils sessionutils){
		StandardServerResponse response = new StandardServerResponse();
		List<UserLoginData>  data;
		UserLoginData userdata = null;
		
		try {
			//remove session from sessions list
			sessionutils.removeSessionFromList(session);
			
			if(session != null){
				//reverse authentication
				userdata = (UserLoginData)session.getAttribute(MajiConstants.USER_SESS_ATTR);
				if(userdata != null)
					userdata.setAuthenticated(false);
							
				//clear session attributes
				sessionutils.cleanSessionAttributes(session);
			}
			data = new ArrayList<UserLoginData>();
			data.add(userdata);
			response.setListData(data);
			response.setSuccess(true);
		} catch (Exception e) {
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("logout_error"));
			
			//logger.error("LoginManager.logoutUser()");	
			//logger.error(e.getStackTrace());
			e.printStackTrace();
		}finally{
			data = null;
			userdata = null;
		}
		return response;
		
	}
	
	public StandardServerResponse authenticateUser(UserLoginData logindata, HttpSession session, SessionUtils sessionutils){
		StandardServerResponse response = new StandardServerResponse();
		
		if(session != null){
			sessionutils.cleanSessionAttributes(session);			
		}else{
			response.setSuccess(true);
    		response.setStringData(appproperties.getString("null_session"));
    		return response;
		}
		
		UserLoginData userdata;
		List<UserLoginData>  data;
		User user;
        try {  
        	if(logindata != null){
        		if(!logindata.getUsername().equals(null) && !logindata.getPassword().equals(null)){
		        	user = getUser(logindata.getUsername());        			
		        	if(user!= null){
		        		if(validatePassword(logindata.getPassword(), user.getPassword())){
		        			//construct a new userlogindata object
		                	userdata = new UserLoginData();
		                	userdata.setUserId(user.getUserId());
		                	userdata.setUsername(logindata.getUsername());
		                    userdata.setAuthenticated(true);
		                    userdata.setLastLoginDate(new Date());
		                    userdata.setSessionid(session.getId());
		                    
		                    //userdata.setSettings(settingsProvider.get());
		                    
		                    session.setAttribute(MajiConstants.USER_SESS_ATTR, userdata);
		                    if(logindata.isRememberlogin())
		                    	session.setMaxInactiveInterval(14 * 24 * 60 * 60); //2 weeks. Otherwise session lasts for 30 minutes(default)
		                    //---sessionutils.addToSessionsList(usersessions, session, userdata.getUserid());
		                   	                   
		                    //logger.debug("Logged user: " + username);
		                    data = new ArrayList<UserLoginData>();
		                    data.add(userdata);
		                    response.setSuccess(true);
		                    response.setListData(data);                    
		        		}else{
		        			response.setSuccess(true);
		        			response.setStringData(appproperties.getString("invalid_login"));
		        		}
		        	}else{
		        		response.setSuccess(true);
		        		response.setStringData(appproperties.getString("invalid_login"));
		        	}  
        		}else{
        			response.setSuccess(true);
	        		response.setStringData(appproperties.getString("invalid_login"));
        		}
        	}else{
        		response.setSuccess(true);
        		response.setStringData(appproperties.getString("invalid_login"));
        	}
        } catch (Exception e) {
            //logger.error("Unable to authenticate user: " + username, e);
        	response.setSuccess(false);
        	response.setErrorData(appproperties.getString("login_error"));
        	
        	//logger.error("LoginManager.authenticateUser()");			
        	//logger.error(e.getStackTrace());
        	e.printStackTrace();
        }finally{
        	logindata = null;
        	user = null;
        	data = null;
        }
		return response;
	}
	
	public UserLoginData authenticateUserSpring(String username, String password, HttpSession session){
		//User user = null;
		UserLoginData userdata = null;
		
        try {          	
			if(!username.equals(null) && !password.equals(null)){
	        	//user = getUser(username);
				userdata = usermanager.getUserLoginData(username);
	        	if(userdata != null){
	        		if(validatePassword(password, userdata.getPassword())){
	        			userdata.setAuthenticated(true);
	        			userdata.setLastLoginDate(new Date());
	                    userdata.setSessionid(session.getId());
	                    //userdata.setSettings(settingsProvider.get());
	                    
	                    session.setAttribute(MajiConstants.USER_SESS_ATTR, userdata);
	                    session.setAttribute(MajiConstants.PRE_AUTH_SESSION_ID, session.getId());
	                    //sessionutils.addToSessionsList(usersessions, session, userdata.getUserid()); use PRE_AUTH_SESSION_ID to retrieve session; nt session id	                    
	        		}else{
	        			return null;
	        		}
	        	}else{
	        		System.out.println("-----------Login:User data is null-----------");
	        	}
			}     	
        } catch (Exception e) {
            //logger.error("Unable to authenticate user: " + username, e);     	
        	//logger.error("LoginManager.authenticateUser()");			
        	//logger.error(e.getStackTrace());
        	System.out.println("-----------Error getting user login data-----------");
        	e.printStackTrace();
        }finally{        	
        	//user = null;        	
        }
        
        return userdata;
	}
	
	public User getUser(String username){
		return usermanager.getUser(username);
		/*User user = new User();
		user.setPassword("$2a$10$BsinCv8hr7S8eVIzYI0pQeLuLdS0ea6itnM9Y6.tJ/v2b2dsawsRq"); //1
		user.setId(1);
		return user;*/
	}
	
	public boolean validatePassword(String userpassword, String hashedpasswordfromdb){		
		try {
			return brainuputils.compareEncryptedAndPlainString(userpassword, hashedpasswordfromdb);
		} catch (Exception e) {
			//logger.error("LoginManager.validatePassword()");
			//logger.error(e.getStackTrace());
			e.printStackTrace();
			return false;
		}	    
	}
	
	public static void main(String[] args){
		//LoginManager l = new LoginManager();
		MajiUtils m = new MajiUtils();
		String x  = m.encryptString("a");
		System.out.println("result: " + m.compareEncryptedAndPlainString("a", x) + "->" + x);
		System.out.println(m.compareEncryptedAndPlainString("a", "$2a$10$bcYz9LhyOTbYy67l5pBMpu4R7URdqCNSC0sxgh0n4D6d/vOw9PRmO"));
		//System.out.println(BCrypt.checkpw(" ", "$10$5D/4v2YiNNSXZQjWuImuTOqyxFItuGv6FW8rTzoZfq9yslKBFey3S"));		
	}
}
