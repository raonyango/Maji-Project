package com.maji.server.utils;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.maji.server.ibatis.dao.UserDAO;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.exception.BrainupException;
import com.maji.shared.ibatis.beans.User;
import com.maji.shared.ibatis.beans.UserExample;
import com.maji.shared.properties.MajiConstants;

public class UserManager {
	
	//private static final Logger logger = Logger.getLogger(UserManager.class);
	@Autowired
	private MajiUtils brainuputils;
	@Autowired
	private ResourceBundle appproperties;	
	@Autowired
	private UserDAO userdao;
	private UserExample userexample;	
	//private CompanyUserExample couserexample;
	@Autowired
	private TransactionTemplate sharedTransactionTemplate = null;

	private User system_user = null;
	
	public MajiUtils getBrainuphelper() {
		return brainuputils;
	}

	public void setBrainuphelper(MajiUtils brainuputils) {
		this.brainuputils = brainuputils;
	}

	public UserDAO getUserdao() {
		return userdao;
	}

	public void setUserdao(UserDAO userdao) {
		this.userdao = userdao;
	}

	public ResourceBundle getAppproperties() {
		return appproperties;
	}

	public void setAppproperties(ResourceBundle appproperties) {
		this.appproperties = appproperties;
	}
	
	public UserLoginData getUserLoginData(String username) {
		List<UserLoginData> userlst;
		try{
			userexample = new UserExample();
			userexample.createCriteria().andUserNameEqualTo(username.toLowerCase()).andIsActiveEqualTo(true);
			if(userdao != null){
				userlst = userdao.selectUserLoginDataByExample (userexample);
				if(userlst != null){
					if(userlst.size() > 0){		
						return userlst.get(0);
					}
				}
			}
			return null;
		}catch(Exception e){
			//logger.error("UserManager.getUser()");
			//logger.error(e.getStackTrace());
			System.out.println("-----------Error getUserLoginData-----------");
			e.printStackTrace();
			return null;
		}
	}
	
	public User getUser(String username){
		List<User> userlst;
		try{
			userexample = new UserExample();
			userexample.createCriteria().andUserNameEqualTo(username.toLowerCase());
			if(userdao != null){
				userlst = userdao.selectUserByExample(userexample);
				if(userlst != null){
					if(userlst.size() > 0){	
						return userlst.get(0);
					}
				}
			}
			return null;
		}catch(Exception e){
			//logger.error("UserManager.getUser()");
			//logger.error(e.getStackTrace());
			e.printStackTrace();
			return null;
		}
	}
	

	public User getUser(int userid) {
		List<User> userlst;
		try{
			userexample = new UserExample();
			userexample.createCriteria().andUserIdEqualTo(userid);
			if(userdao != null){
				userlst = userdao.selectUserByExample(userexample);
				if(userlst != null){
					if(userlst.size() > 0){	
						return userlst.get(0);
					}
				}
			}
			return null;
		}catch(Exception e){
			//logger.error("UserManager.getUser()");
			//logger.error(e.getStackTrace());
			e.printStackTrace();
			return null;
		}
	}
	
	public User getUserProfile(String username, boolean newsession) {
		List<User> userlst;
		try{
			userexample = new UserExample();
			userexample.createCriteria().andUserNameEqualTo(username.toLowerCase());
			if(userdao != null){
				userlst = userdao.selectUserByExample(userexample);
				if(userlst != null){
					if(userlst.size() > 0){
						return userlst.get(0);						
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			userlst = null;
		}
		
		return null;
	}
	
	@SuppressWarnings("unused")
	private void saveUserDataInSession(User user){
		HttpSession session = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest().getSession();
		
		UserLoginData userdata = new UserLoginData();
    	userdata.setUserId(user.getUserId());
    	userdata.setUsername(user.getUserName());
        userdata.setPassword(user.getPassword());            
        userdata.setAuthenticated(true);
        userdata.setLastLoginDate(new Date());
        userdata.setSessionid(session.getId());
        //userdata.setSettings(settingsProvider.get());
        
        session.setAttribute(MajiConstants.USER_SESS_ATTR, userdata);
	}

	public boolean updateUser(User updatedprofile) {
		try{
			if(updatedprofile != null){
				if(userdao != null){
					if(userdao.updateUserByPrimaryKeySelective(updatedprofile) == 1){
						return true;
					}
				}
			}
			return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			updatedprofile = null;
		}		
	}	
	
	/*public StandardServerResponse resetPassword(final ForgotPasswordData data) {
		final StandardServerResponse response = new StandardServerResponse();	
		final List<User> lst;
		
		try{
			if(data != null)
				if(userdao != null){
					userexample = new UserExample();
					userexample.createCriteria().andUsernameEqualTo(data.getUserName().toLowerCase())
													.andEMailEqualTo(data.getEmail().toLowerCase());
					lst = userdao.selectUserByExample(userexample);
					if(lst != null){
						if(lst.size() == 1){
							final String newpwd = String.valueOf(brainuputils.generateSecureRandomInteger());
							
							if(sharedTransactionTemplate != null){
								sharedTransactionTemplate.execute(new TransactionCallbackWithoutResult() {
									
									@Override
									protected void doInTransactionWithoutResult(TransactionStatus status) {
										try{
							            	if(updateUserPassword(lst.get(0), newpwd)){
							            		String from = getUserSystem().geteMail();
												String subject = appproperties.getString("reset_password_subject");
												String message = appproperties.getString("reset_password_email_1") + " " +  
																	data.getUserName().toUpperCase() + "," + " " + 
																	appproperties.getString("reset_password_email_2") +
																	" " + newpwd + " " + appproperties.getString("reset_password_email_3") + " " + 
																	data.getUserName().toLowerCase() + " " + 
																	appproperties.getString("reset_password_email_4");
												
												EmailStatus estatus = emailhelper.sendEmail(from, appproperties.getString("brainup_admin_name"), data.getEmail(), null, subject, message);
												if(estatus.isSent() || (!estatus.isSent() && !estatus.isError())){
													response.setSuccess(true);
												}else{
													response.setErrorData(appproperties.getString("reset_password_email_err"));
												}
												if(estatus.isSent()){
													//add to br_sent_mail
													SentMail smail = new SentMail();
													smail.setSender(getUserSystem().getId());
													smail.setReceipient(data.getEmail());
													smail.setSubject(subject);
													smail.setEmailmsg(message);
													smail.setEmailcategoryId(emailmanager.getEmailCategory(DatabaseConstants.PASSWORD_RESET).getId());
													smail.setDatesent(new Date());
													smail.setCreatedby(getUserSystem().getId());
													smail.setCreatedon(new Date());
													
													if(emailmanager.addSentMail(smail)){
														response.setSuccess(true);	
													}else{
														response.setSuccess(false);	
														response.setErrorData(appproperties.getString("err_add_sent_mail"));
													}																			
												}else {
													if(estatus.isError()){		
														response.setSuccess(false);
														response.setErrorData(appproperties.getString("reset_password_email_err"));						
													}else{
														response.setSuccess(false);
														response.setErrorData(appproperties.getString("reset_password_email_err"));
													}
													//add to br_unsent_mail
													UnSentMail usmail = new UnSentMail();
													usmail.setSender(getUserSystem().getId());
													usmail.setReceipient(data.getEmail());
													usmail.setSubject(subject);
													usmail.setEmailmsg(message);
													usmail.setEmailcategoryId(emailmanager.getEmailCategory(DatabaseConstants.PASSWORD_RESET).getId());
													usmail.setDuedate(new Date());
													usmail.setCreatedby(getUserSystem().getId());
													usmail.setCreatedon(new Date());
													emailmanager.addUnsentMail(usmail);
												}
											}else{
												response.setErrorData(appproperties.getString("reset_password_err"));
											}
							                //return response;
										}catch (BrainupException be) {
											be.printStackTrace();
											response.setErrorData(be.getMessage());
											response.setSuccess(false);
											status.setRollbackOnly();
										}catch (Exception e) {
											e.printStackTrace();
											response.setErrorData(appproperties.getString("reset_password_err"));
											response.setSuccess(false);
											status.setRollbackOnly();
										}						            	
						            }
						        });

							}							
						}else{
							response.setErrorData(appproperties.getString("email_pwd_not_found"));
						}
					}else{
						response.setErrorData(appproperties.getString("email_pwd_not_found"));
					}
				}
		}catch(Exception e){
			response.setSuccess(false);
			response.setErrorData(appproperties.getString("password_reset_error"));
			e.printStackTrace();
		}finally{
		
		}
		
		return response;
	}*/

	private boolean updateUserPassword(User user, String newpassword){
		if(user != null && newpassword != null){
			user.setPassword(brainuputils.encryptString(newpassword));
			if(userdao != null){
				userexample = new UserExample();
				userexample.createCriteria().andUserNameEqualTo(user.getUserName().toLowerCase());
				if(userdao.updateUserByExample(user, userexample) == 1){
					return true;
				}
			}
		}
		return false;
	}
	
	public int addUser(User adminuser) {
		try{
			if(adminuser != null){
				if(userdao != null){
					return userdao.insertUserSelective(adminuser);
				}
			}
			return -1;
		}catch(Exception e){
			e.printStackTrace();
			return -1;
		}finally{
			//adminuser = null;
		}		
	}
	
	public User getUserSystem() throws Exception {		
		if(system_user == null){
			User u = getUser("SYSTEM");
			if(u != null)
				system_user = u;
			else
				throw new BrainupException(appproperties.getString("user_system_not_found"));
		}
		
		return system_user;
	}

	public User getUserSystem(String user) throws Exception {		
		if(system_user == null){
			User u = getUser(user);
			if(u != null)
				system_user = u;
			else
				throw new BrainupException(appproperties.getString("user_system_not_found"));
		}
		
		return system_user;
	}
	
	
	public void test(){
		User u = new User();
		u.setFirstName("mimi");
		u.setPassword("...");
		u.setUserId(1);
		u.setUserName("asd");
		//u.setUserRoleId(1);
		Object o = new Object();
		String s="";
		Field[] fs = u.getClass().getDeclaredFields();
		for(Field f: fs){
			try {
				if(!f.isAccessible())
					f.setAccessible(true);
				if(f.getType() != Integer.class && f.getType() != Double.class && f.getType() != Float.class )	
					if(f.getType() == String.class){
						if(f.get(s) == null){
							System.out.println(f.getName() + "....null");
						}
					}else {
						if(f.get(o) == null){
							System.out.println(f.getName() + "....null");
						}
					}
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args){
		UserManager u = new UserManager();
		//System.out.println(BCrypt.hashpw("a", BCrypt.gensalt()));
		u.test();
	}


	
}
