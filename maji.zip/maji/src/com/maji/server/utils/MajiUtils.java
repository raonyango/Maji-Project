/**
 * @author Rosemary A. Onyango
 *
 */
package com.maji.server.utils;

import java.math.BigInteger;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.maji.server.security.BCrypt;

public class MajiUtils {
	@Autowired
	private ResourceBundle appproperties = null;
	
	@Autowired
	private SecureRandom random;

	public ResourceBundle getAppproperties() {
		return appproperties;
	}

	public void setAppproperties(ResourceBundle appproperties) {
		this.appproperties = appproperties;
	}
	
	public MajiUtils(){
		
	}

	public ArrayList<HttpSession> addToSessionsList(ArrayList<HttpSession> sessionlist, HttpSession session, int userid){
		for(HttpSession hs: sessionlist){
			if(hs.getId().equals(session.getId())){				
				//System.out.println("------------------------------------------session exists!!----------------------------");
				return sessionlist;
			}
		}
		
		//System.out.println("------------------------------------------session added...----------------------------");
		sessionlist.add(session);
		return sessionlist;				
	}
	

	@SuppressWarnings("unchecked")
	public HashMap getHashMapFromSession(String key, HttpSession session) {
		// If the session does not contain anything, create a new HashMap
		if (session.getAttribute(key) == null) {
			   session.setAttribute(key, new HashMap());
		}
		  
		// Return the HashMap
		return (HashMap) session.getAttribute(key);
	}
	
	@SuppressWarnings("deprecation")
	public String getDecodedSearchString(String searchString) {
		return URLDecoder.decode(searchString);
	}
		
	public int getIntValue(String intstringvalue){
    	if(intstringvalue == null){
    		return (getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1));
    	}else if(intstringvalue.toString().trim().equalsIgnoreCase("")){
    		return (getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1));
    	}else{
    		try{
    			return Integer.parseInt(intstringvalue.toString().trim());
    		}catch(NumberFormatException nfe){
    			return (getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1));
    		}
    	}
    }
    
    public Double getDoubleValue(String doublestringvalue){
    	if(doublestringvalue == null){
    		return Double.parseDouble(String.valueOf((getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1))));
    	}else if(doublestringvalue.toString().trim().equalsIgnoreCase("")){
    		return Double.parseDouble(String.valueOf((getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1))));
    	}else{
    		try{
    			return Double.parseDouble(doublestringvalue.toString().trim());
    		}catch(NumberFormatException nfe){
    			return Double.parseDouble(String.valueOf((getRandomInteger(-1000, -1) - getRandomInteger(-1000, -1))));
    		}
    	}
    }
    
    public int getRandomInteger(int Start, int End){
		try{
		    if ( Start > End ) {
		    	return Start;
		    }
		    //get the range, casting to long to avoid overflow problems
		    long range = (long)End - (long)Start + 1;
		    // compute a fraction of the range, 0 <= frac < range
		    Random aRandom = new Random();
		    long fraction = (long)(range * aRandom.nextDouble());
		    
		    return (int)(fraction + Start);    
		}catch(Exception e){
			return Start;
		}
    }
    
    public String formatDate(Date date, String format){
    	try{
	    	Format formatter = new SimpleDateFormat(format);
			return formatter.format(date);
    	}catch(Exception e){
    		e.printStackTrace();
    		return date.toString();
    	}
    }    
	
	public String encryptString(String toencrypt){
		return BCrypt.hashpw(toencrypt, BCrypt.gensalt());
	}
	
	public boolean compareEncryptedAndPlainString(String plaintext, String hashed){
		/*String password = (get password from incoming JSON or GWT-RPC request);
	    String hash = BCrypt.hashpw(password, BCrypt.genSalt());
	    //(create new user entry in db storing ONLY username and hash, *NOT* the password).*/
		return BCrypt.checkpw(plaintext, hashed);
	}
		
	public String generateSecureRandomInteger(){
		try{
			return new BigInteger(60, random).toString(32);			
		}catch(Exception e){
			e.printStackTrace();
			return Long.toHexString(Double.doubleToLongBits(Math.random()));
		}
    }
		
}
