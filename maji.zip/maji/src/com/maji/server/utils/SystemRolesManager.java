package com.maji.server.utils;


public class SystemRolesManager {

/*	@Autowired
	UserRoleDAO userroledao;
	UserRoleExample userroleexample;
	
	public List<UserRole> getSystemRoles() {
		List<UserRole> roles = null;
		try {
			if(userroledao != null){
				userroleexample = new UserRoleExample();			
				roles = userroledao.selectUserRoleByExample(userroleexample);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return roles;
	}

	public UserRole getRole(String name) {
		List<UserRole> roles = null;		
		try {
			if(userroledao != null){
				userroleexample = new UserRoleExample();
				userroleexample.createCriteria().andRoleEqualTo(name);
				roles = userroledao.selectUserRoleByExample(userroleexample);
				if(roles != null)
					if(roles.size() > 0)
						return roles.get(0);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}*/
}
