package com.maji.server.utils;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfReader;

public class FileUtility {

	public void merge_files(List<String> input_files, String output_file) {
		try {
			Document PDFCombineUsingJava = new Document();
			PdfCopy copy = new PdfCopy(PDFCombineUsingJava,
					new FileOutputStream(output_file));
			PDFCombineUsingJava.open();
			PdfReader ReadInputPDF;
			int number_of_pages;
			for (int i = 0; i < input_files.size(); i++) {
				ReadInputPDF = new PdfReader(input_files.get(i));
				number_of_pages = ReadInputPDF.getNumberOfPages();
				for (int page = 0; page < number_of_pages;) {
					copy.addPage(copy.getImportedPage(ReadInputPDF, ++page));
				}
			}
			PDFCombineUsingJava.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public static void main(String[] args){
		FileUtility fu  = new FileUtility();
		List<String> files =  new LinkedList<String>();
		files.add("S:\\BA018635.pdf");
		files.add("S:\\jreport.pdf");
		
		fu.merge_files(files, "S:\\CombinedPDFDocument.pdf");
	}
}
