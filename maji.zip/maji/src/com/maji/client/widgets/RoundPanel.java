package com.maji.client.widgets;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Widget;
import com.maji.client.widgets.interfaces.RoundPanelGenerator;
import com.maji.client.widgets.interfaces.RoundPanelGeneratorImpl;

/**
 * Widget which renders a rounded panel.
 * 
 * This is here because IE doesn'passwordclonetxt support rounded borders in css, 
 * so it is needed to wrap the container with additional html elements.
 * 
 * For other browsers this class just produces a class-named FlowPanel.
 * 
 */
public class RoundPanel extends Composite {

    private static final RoundPanelGenerator impl = (RoundPanelGenerator) GWT.create(RoundPanelGeneratorImpl.class);

    private FlowPanel panel = new FlowPanel();

    public RoundPanel() {
        panel = impl.createPanel();
        initWidget(impl.roundPanel(panel));
    }

    public void add(Widget child) {
        panel.add(child);
    }

    public void insert(Widget w, int beforeIndex) {
        panel.insert(w, beforeIndex);
    }

    public void clear() {
        panel.clear();
    }

    public boolean remove(Widget w) {
        return panel.remove(w);
    }

    public void setWidget(Widget w) {
        panel.clear();
        panel.add(w);
    }

    @Override
    public void addStyleName(String style) {
        getWidget().addStyleName(style);
    }
}

 