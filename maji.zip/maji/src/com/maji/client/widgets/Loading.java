package com.maji.client.widgets;

import com.maji.shared.properties.MajiCSS;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.HTMLFlow;
import com.smartgwt.client.widgets.layout.HLayout;

public class Loading extends HLayout {
    
	private HTMLFlow h;
    public Loading(String loadingMsg) {
    	h = new HTMLFlow(loadingMsg);
    	h.setAlign(Alignment.CENTER);    	
        
    	addMember(h);
        addStyleName(MajiCSS.loading);
        setHeight(20);
        setLayoutAlign(Alignment.CENTER);
        setAlign(Alignment.RIGHT);
    }
    
    public Loading() {
        this("");
    }
    
    /**
     * Show the Loading image
     */
    public void show() {
        setVisible(true);
    }
    
    /**
     * Hide the Loading image
     */
    public void hide() {
        setVisible(false);
    }

    public void setMessage(String message){
    	if(h != null){
    		h.setContents(message);
    	}
    }
}
