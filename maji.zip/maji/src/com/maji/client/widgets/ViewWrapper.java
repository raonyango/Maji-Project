package com.maji.client.widgets;

import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.event.logical.shared.HasAttachHandlers;
import com.smartgwt.client.widgets.layout.VLayout;

public class ViewWrapper extends VLayout implements HasAttachHandlers{

	public ViewWrapper() {
		super();
	}

	public ViewWrapper(JavaScriptObject jsObj) {
		super(jsObj);
	}

	public ViewWrapper(int membersMargin) {
		super(membersMargin);
	}
}
