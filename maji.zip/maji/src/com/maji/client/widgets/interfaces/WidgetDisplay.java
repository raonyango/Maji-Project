package com.maji.client.widgets.interfaces;

import net.customware.gwt.presenter.client.Display;

import com.smartgwt.client.widgets.layout.Layout;

public interface WidgetDisplay extends Display{
	 Layout asWidget();
}
