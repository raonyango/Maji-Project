package com.maji.client.widgets.interfaces;

import com.smartgwt.client.widgets.layout.Layout;

public interface WidgetContainerDisplay extends WidgetDisplay {
	void addWidget(Layout widget);

	void removeWidget(Layout widget);

	void showWidget(Layout widget);
}
