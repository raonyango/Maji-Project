package com.maji.client.widgets;

import net.customware.gwt.presenter.client.EventBus;

import com.google.gwt.user.client.History;
import com.google.inject.Inject;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.UserAccountEvent;
import com.maji.client.event.UserAccountEventHandler;
import com.maji.client.place.PlaceTokens;
import com.maji.client.utils.ClientUtils;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.Overflow;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.layout.HLayout;

public class NavigationPaneHeader extends HLayout {

  private static final String WEST_WIDTH = "20%";
  private static final String NAVIGATION_PANE_HEADER_HEIGHT = "27px";
  private Label navigationPaneHeaderLabel;
  private Label contextAreaHeaderLabel;
  
  //private ClientUtils clientutils;
  //private MajiStrings constants;
  
  @Inject
  public NavigationPaneHeader(EventBus eventbus, MajiStrings constants, final ClientUtils clientutils) {
    super();
        
    // Log.debug("NavigationPaneHeader()");
    // initialise the Navigation Pane Header layout container
    //this.setStyleName(MajiCSS.navigation_pane_header);
    this.setStyleName("crm-NavigationPane-Header");
    this.setHeight(NAVIGATION_PANE_HEADER_HEIGHT);

    // initialise the Navigation Pane Header Label
    navigationPaneHeaderLabel = new Label();
    //navigationPaneHeaderLabel.setStyleName(MajiCSS.navigation_pane_header_lbl);
    navigationPaneHeaderLabel.setStyleName("crm-NavigationPane-Header-Label");
    navigationPaneHeaderLabel.setWidth(WEST_WIDTH);
    navigationPaneHeaderLabel.setContents(constants.main_navigator_section_header());
    navigationPaneHeaderLabel.setAlign(Alignment.LEFT);
    navigationPaneHeaderLabel.setOverflow(Overflow.HIDDEN);

    // initialise the Context Area Header Label
    
    contextAreaHeaderLabel = new Label();
    //contextAreaHeaderLabel.setStyleName(MajiCSS.context_area_header_lbl);
    contextAreaHeaderLabel.setStyleName("crm-ContextArea-Header-Label");
    contextAreaHeaderLabel.setContents(clientutils.getPlaceLabel(PlaceTokens.person));
    contextAreaHeaderLabel.setAlign(Alignment.LEFT);
    contextAreaHeaderLabel.setOverflow(Overflow.HIDDEN);
    
    eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {
		
		@Override
		public void onRefreshApplication(RefreshEvent event) {
			contextAreaHeaderLabel.setContents(clientutils.getPlaceLabel(History.getToken()));		    
		}
	});
    
    eventbus.addHandler(UserAccountEvent.TYPE, new UserAccountEventHandler() {
		
		@Override
		public void onShowAccount(UserAccountEvent event) {
			contextAreaHeaderLabel.setContents(clientutils.getPlaceLabel(PlaceTokens.person));
		}
	});
    
    // add the Labels to the Navigation Pane Header layout container
    this.addMember(navigationPaneHeaderLabel);
    this.addMember(contextAreaHeaderLabel);
  }

  public Label getNavigationPaneHeaderLabel() {
    return navigationPaneHeaderLabel;
  }

  public Label getContextAreaHeaderLabel() {
    return contextAreaHeaderLabel;
  }

  public void setNavigationPaneHeaderLabelContents(String contents) {
    navigationPaneHeaderLabel.setContents(contents);
  }

  public String getNavigationPaneHeaderLabelContents() {
    return navigationPaneHeaderLabel.getContents();
  }

  public void setContextAreaHeaderLabelContents(String contents) {
    contextAreaHeaderLabel.setContents(contents);
  }

  public String getContextAreaHeaderLabelContents() {
    return contextAreaHeaderLabel.getContents();
  }
}
