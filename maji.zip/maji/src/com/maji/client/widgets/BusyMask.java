package com.maji.client.widgets;

import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.ClickMaskMode;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.layout.VLayout;

public class BusyMask extends Window {
	private VLayout infocontainer;
	private Canvas mask;

	public BusyMask(String message) {
		super();
		createModalWindow(message);
	}

	private void createModalWindow(String message) {
		Img i = new Img();
		i.setSrc("cursors/loader-bar-grey.gif");
		i.setWidth(220);
		i.setHeight(19);
		
		Float x, y;
		y = Float.valueOf(String.valueOf(i.getOffsetHeight() / 2));
		x = Float.valueOf(String.valueOf(i.getOffsetWidth() / 2));
		
		infocontainer = new VLayout();
		infocontainer.setAutoHeight();
		infocontainer.setAutoWidth();
		infocontainer.setLayoutAlign(Alignment.CENTER);		
		infocontainer.addMember(i);
		infocontainer.showClickMask(null, ClickMaskMode.HARD, null);
		infocontainer.setTop((com.google.gwt.user.client.Window.getClientHeight() / 2) - y.intValue());
		infocontainer.setLeft((com.google.gwt.user.client.Window.getClientWidth() / 2) - x.intValue());
		
		mask = new Canvas();
		mask.setWidth(com.google.gwt.user.client.Window.getClientWidth());
		mask.setHeight(com.google.gwt.user.client.Window.getClientHeight());
		mask.setBackgroundColor("#333333");
		mask.setOpacity(60);
		mask.bringToFront();
		
		infocontainer.bringToFront();
	}

	public void show() {
		com.google.gwt.user.client.Window.scrollTo(
				com.google.gwt.user.client.Window.getScrollTop(),
				com.google.gwt.user.client.Window.getScrollLeft());
		infocontainer.draw();
		mask.draw();
	}

	public void hide() {
		infocontainer.removeFromParent();
		infocontainer.destroy();

		mask.removeFromParent();
		mask.destroy();
	}
}
