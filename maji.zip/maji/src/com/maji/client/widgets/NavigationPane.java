package com.maji.client.widgets;

import net.customware.gwt.presenter.client.EventBus;

//import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.VisibilityMode;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.SectionStack;
import com.smartgwt.client.widgets.layout.SectionStackSection;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.layout.events.SectionHeaderClickHandler;

public class NavigationPane extends VLayout {

	private static final String WEST_WIDTH = "20%";
	private static final String SECTION_STACK_WIDTH = "100%";

	// private static final int HEADER_HEIGHT = 31;

	private SectionStack sectionstack;
	private EventBus eventbus;

	@Inject
	public NavigationPane(EventBus eventbus) {
		super();
		this.eventbus = eventbus;

		// initialise the Navigation Pane layout container
		//this.setStyleName(MajiCSS.navigation_pane);
		 this.setStyleName("crm-NavigationPane");
		this.setWidth(WEST_WIDTH);
		// this.setShowResizeBar(true);

		// initialise the Section Stack
		sectionstack = new SectionStack();
		sectionstack.setWidth(SECTION_STACK_WIDTH);
		sectionstack.setVisibilityMode(VisibilityMode.MUTEX);
		sectionstack.setShowExpandControls(true);
		sectionstack.setAnimateSections(true);

		// sectionstack.setHeaderHeight(HEADER_HEIGHT);
		// can only set this in a derived class

		// add the Section Stack to the Navigation Pane layout container
		this.addMember(sectionstack);
	}

	public void addSection(String sectionName, DataSource dataSource) {
		sectionstack.addSection(new NavigationPaneSection(eventbus,
				sectionName, dataSource));
	}

	public void expandSection(int section) {
		sectionstack.expandSection(section);
	}

	public void expandSection(String name) {
		sectionstack.expandSection(name);
	}

	public void selectRecord(String name) {

		//Log.debug("selectRecord(place) - " + name);

		SectionStackSection[] sections = sectionstack.getSections();

		// Log.debug("Number of sections: " + sections.length);

		for (int i = 0; i < sections.length; i++) {
			SectionStackSection sectionStackSection = sections[i];

			if (((NavigationPaneSection) sectionStackSection).getRecord(name) != -1) {

				if (!sectionstack.sectionIsExpanded(i)) {
					//Log.debug("sectionstack.expandSection(i)");
					sectionstack.expandSection(i);
				}

				((NavigationPaneSection) sectionStackSection)
						.selectRecord(name);
				break;
			}
		}
	}

	public void addSectionHeaderClickHandler(
			SectionHeaderClickHandler clickHandler) {
		sectionstack.addSectionHeaderClickHandler(clickHandler);
	}

	public void addRecordClickHandler(String sectionName,
			RecordClickHandler clickHandler) {

		// Log.debug("addRecordClickHandler(sectionName, clickHandler) - " +
		// sectionName);

		SectionStackSection[] sections = sectionstack.getSections();

		for (int i = 0; i < sections.length; i++) {
			SectionStackSection sectionStackSection = sections[i];

			if (sectionName.contentEquals(sections[i].getTitle())) {
				((NavigationPaneSection) sectionStackSection)
						.addRecordClickHandler(clickHandler);
			}
		}
	}
}
