package com.maji.client.widgets;

import com.google.gwt.core.client.GWT;
import com.maji.client.gin.MajiGinjector;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.widgets.grid.ListGrid;

public class DualListGrid extends ListGrid {

	private MajiGinjector injector = GWT.create(MajiGinjector.class);
    private MajiStrings constants = injector.getMajiConstants();
   	
	public DualListGrid() {
        setWidth(230);
        setCellHeight(24);
        setImageSize(16);
        setShowEdges(true);
        setBorder("0px");
        setBodyStyleName("normal");
        setShowHeader(true);
        setLeaveScrollbarGap(false);    
        setTooltip(constants.drag_drop_ttp());
	}
}
