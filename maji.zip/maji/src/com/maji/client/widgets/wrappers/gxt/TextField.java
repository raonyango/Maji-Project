package com.maji.client.widgets.wrappers.gxt;

import com.google.gwt.text.shared.Renderer;

public class TextField<T> extends ValueFieldBase<T> {

	protected TextField(Renderer<T> renderer) {
		super(renderer);
		// TODO Auto-generated constructor stub
	}

	public TextField(){
		super();
	}
}