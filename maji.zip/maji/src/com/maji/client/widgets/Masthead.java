package com.maji.client.widgets;

import com.google.gwt.user.client.ui.Hyperlink;
import com.google.inject.Inject;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.layout.HLayout;

public class Masthead extends HLayout {

	private static final int MASTHEAD_HEIGHT = 58;
	private static final int IMAGE_SIZE = 48;

	private static final String WEST_WIDTH = "50%";
	private static final String EAST_WIDTH = "50%";
	private static final String LOGO = "logo.png";
	private static final String NAME_LABEL = MajiConstants.APP_NAME;
	private String SIGNED_IN_USER_LABEL = "username here";
	private MajiStrings constants = null;
	private Hyperlink logoutlink;
	private Label signedInUser;
	
	@Inject
	public Masthead(MajiStrings constants) {
		super();
		this.constants = constants;
		// Log.debug("Masthead()");

		// initialise the Masthead layout container
		this.setStyleName("crm-Masthead"); //(MajiCSS.top_container);
		this.setHeight(MASTHEAD_HEIGHT);

		// initialise the Logo image
		Img logo = new Img(LOGO, IMAGE_SIZE, IMAGE_SIZE);
		//logo.setStyleName(MajiCSS.logo_container);
		 logo.setStyleName("crm-Masthead-Logo");
		 
		// initialise the Name label
		Label name = new Label();
		//name.setStyleName(MajiCSS.appnamelbl);
		name.setContents(NAME_LABEL);
		 name.setStyleName("crm-Masthead-Name");
		 
		// initialise the West layout container
		HLayout westLayout = new HLayout();
		westLayout.setHeight(MASTHEAD_HEIGHT);
		westLayout.setWidth(WEST_WIDTH);
		westLayout.addMember(logo);
		westLayout.addMember(name);

		// initialise the Signed In User label
		signedInUser = new Label();
		//signedInUser.setStyleName(MajiCSS.signedin_user_lbl);
		 signedInUser.setStyleName("crm-Masthead-SignedInUser");
		
		//logout link
		logoutlink = new Hyperlink();
		logoutlink.setText(constants.logout_button());
		logoutlink.setStylePrimaryName(MajiCSS.logout_link);
		/*VerticalPanel eastmembers = new VerticalPanel();
		eastmembers.add(signedInUser);
		eastmembers.add(logoutlink);
		eastmembers.setHeight(MASTHEAD_HEIGHT + "px");
		eastmembers.setWidth(EAST_WIDTH);
		*/
		// initialise the East layout container
		HLayout eastLayout = new HLayout();
		eastLayout.setAlign(Alignment.RIGHT);
		eastLayout.setHeight(MASTHEAD_HEIGHT);
		eastLayout.setWidth(EAST_WIDTH);
		eastLayout.addMember(signedInUser);
		//eastLayout.addMember(logoutlink);
		//eastLayout.addMember(eastmembers);
		
		// add the West and East layout containers to the Masthead layout
		// container
		this.addMember(westLayout);
		this.addMember(eastLayout);
	}

	public String getSIGNED_IN_USER_LABEL() {
		return SIGNED_IN_USER_LABEL;
	}

	public void setSignedinUsername(String uname) {
		SIGNED_IN_USER_LABEL = "<b>" + constants.project_name() + "</b><br/>" + uname;
		signedInUser.setContents(SIGNED_IN_USER_LABEL);
	}

	public Hyperlink getLogoutlink() {
		return logoutlink;
	}

	public void setLogoutlink(Hyperlink logoutlink) {
		this.logoutlink = logoutlink;
	}
}
