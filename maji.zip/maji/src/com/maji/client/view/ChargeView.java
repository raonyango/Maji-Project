package com.maji.client.view;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.maji.client.presenter.ChargePresenter;
import com.maji.client.view.model.ChargeRecord;
import com.maji.client.view.uihandlers.ChargeViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.ContextListGrid;
import com.maji.client.widgets.RecordToolBar;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.ToolBar;
import com.maji.shared.ibatis.beans.WaterCharge;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiMessages;
import com.maji.shared.properties.MajiStrings;
import com.maji.shared.properties.ToolbarConstants;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.RowSpacerItem;
import com.smartgwt.client.widgets.form.fields.SectionItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.validator.CustomValidator;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class ChargeView extends ViewWithUiHandlers<ChargeViewUiHandlers>
		implements ChargePresenter.IChargeViewDisplay {

	private static final String CONTEXT_AREA_WIDTH = "100%";
	private int recordid;

	private final RecordToolBar toolbar, form_tbar;
	private final ContextListGrid listgrid;
	private final StatusBar statusbar;

	private VLayout maincontainer;
	private ToolStripButton printpreviewbtn, save_btn, save_close_btn,
			update_btn;
	protected DynamicForm form;

	private int numberofelements;
	private int numberselected;
	private int pageNumber;

	private MajiMessages messages;
	private ToolbarConstants tconstants;

	private WaterCharge charge;

	protected MyFloatValidator floatValidator;

	private static final String STATUS = "status";
	private static final String CURRENCY = "currency";
	private static final String AMOUNT = "amount";
	private static final String CHARGE_ID = "pid";
	private static final String CREATED_ON = "created_on";
	private static final String MODIFIED_ON = "modified_on";
	private static final String FORM_SECTION = "form_section";

	protected TextItem amount, currency, created_on, charge_id_txt, modified_on;
	protected SelectItem status;
	protected SectionItem form_section;
	private MajiStrings constants;

	@Inject
	public ChargeView(RecordToolBar toolbar, ChargeListGrid listgrid,
			RecordToolBar form_toolbar, DynamicForm iform, StatusBar statusbar,
			MajiMessages messages, ToolbarConstants tconstants,
			MajiStrings constants) {
		this.toolbar = toolbar;
		this.listgrid = listgrid;
		this.statusbar = statusbar;
		this.messages = messages;
		this.tconstants = tconstants;
		this.form_tbar = form_toolbar;
		this.form = iform;
		this.constants = constants;

		this.numberofelements = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		this.numberselected = 0;
		pageNumber = 1;

		maincontainer = new VLayout();

		// initialise the View's layout container
		maincontainer.setStyleName(MajiCSS.context_area);
		maincontainer.setWidth(CONTEXT_AREA_WIDTH);

		// add the Tool Bar, List Grid, and Status Bar to the View's layout
		// container
		maincontainer.addMember(this.toolbar);
		maincontainer.addMember(this.listgrid);
		maincontainer.addMember(this.statusbar);

		bindCustomUiHandlers();

		recordid = -1;
	}

	protected void bindCustomUiHandlers() {
		// register the ListGird handlers
		listgrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			@Override
			public void onSelectionChanged(SelectionEvent event) {

				ListGridRecord[] records = event.getSelection();

				numberselected = records.length;

				String selectedLabel = messages.selected(numberselected,
						numberofelements);
				statusbar.getSelectedLabel().setContents(selectedLabel);

			}
		});
		// initialise the ToolBar and register its handlers
		initToolBar();

		listgrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(ChargeRecord.CHARGE_ID);

				show_update_form(recordid);
			}
		});

		listgrid.addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(ChargeRecord.CHARGE_ID);

				if (maincontainer.hasMember(form)) {
					show_update_form(recordid);
				}
			}
		});

		// initialise the StatusBar and register its handlers
		initStatusBar();
	}

	protected void initToolBar() {
		save_btn = form_tbar.addButton(ToolBar.SAVE_BUTTON,
				tconstants.savebtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							save_new_unit();

							resetForm();
						}
					}
				});
		save_btn.disable();

		save_close_btn = form_tbar.addButton(ToolBar.SAVE_AND_CLOSE_BUTTON,
				tconstants.save_close_btn_caption(),
				tconstants.save_close_btn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							if (validate_form()) {
								save_new_unit();

								maincontainer.removeMember(form_tbar);
								maincontainer.removeMember(form);
								// form = null;

							}
						}
					}
				});
		save_close_btn.disable();
		form_tbar.addSeparator();

		update_btn = form_tbar.addButton(ToolBar.UPDATE_BUTTON,
				tconstants.updatebtn_caption(), tconstants.updatebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							update_unit();

							resetForm();
						}
					}
				});
		update_btn.disable();
		form_tbar.addSeparator();

		form_tbar.addButton(ToolBar.CANCEL_BUTTON,
				tconstants.cancelbtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(form_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}

					}
				});

		toolbar.addButton(ToolBar.NEW_ACCOUNT_BUTTON,
				tconstants.new_btn_caption(), tconstants.new_btn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {

						onNewButtonClicked();
					}
				});

		toolbar.addSeparator();
		toolbar.addButton(ToolBar.REFRESH_BUTTON,
				tconstants.refreshbtn_caption(),
				tconstants.refreshbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							// maincontainer.disable();
							getUiHandlers().onRefreshButtonClicked();
						}
					}
				});

		toolbar.addSeparator();

		printpreviewbtn = toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(),
				tconstants.printpreviewbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {

					}
				});

		printpreviewbtn.disable();

	}

	protected void initStatusBar() {

		// "0 of 50 selected"
		// statusbar.getSelectedLabel().setContents(Serendipity.getConstants().selectedLabel());

		statusbar.getResultSetFirstButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetFirstButtonClicked();
				}
			}
		});

		statusbar.getResultSetPreviousButton().addClickHandler(
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onResultSetPreviousButtonClicked();
						}
					}
				});

		// "Page 1"
		// statusbar.getPageNumberLabel().setContents(Serendipity.getConstants().pageNumberLabel());

		statusbar.getResultSetNextButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetNextButtonClicked();
				}
			}
		});
	}

	@Override
	public void setResultSet(List<WaterCharge> resultset) {
		// resultSet == null when there are no items in table
		if (resultset != null) {

			try {
				((ChargeListGrid) listgrid).setServicesResultSet(resultset);
			} catch (Exception e) {
				Log.info("ChargeView.setResultSet Error...................."
						+ e.getMessage());
			}
		}
	}

	@Override
	public void refreshStatusBar() {
		// update Selected label e.g "0 of 50 selected"
		statusbar.getSelectedLabel().setContents(
				messages.selected(numberselected, numberofelements));
		// Log.info(numberofelements + "............REFRESH........");
		// update Page number label e.g "Page 1"
		statusbar.getPageNumberLabel().setContents(messages.page(pageNumber));
	}

	@Override
	public void setPageNumber(int pagenumber) {
		this.pageNumber = pagenumber;
	}

	@Override
	public void setNumberSelected(int numberselected) {
		this.numberselected = numberselected;
	}

	@Override
	public Layout asWidget() {
		return maincontainer;
	}

	@Override
	public StatusBar getStatusBar() {
		return statusbar;
	}

	@Override
	public void setNumberOfElements(int numberofelements) {
		this.numberofelements = numberofelements;
	}

	// -----------------------------------------------------------------------------------------------------------------

	protected void onNewButtonClicked() {
		if (getUiHandlers() != null) {
			getUiHandlers().onNewButtonClicked();

			build_add_form();
		}

		if (maincontainer.hasMember(form_tbar)) {
			maincontainer.removeMember(form_tbar);
			// form = null;
		}

		if (maincontainer.hasMember(form)) {
			maincontainer.removeMember(form);
			// form = null;
		}

		resetForm();

		maincontainer.addMember(form_tbar);
		maincontainer.addMember(form);

		update_btn.disable();
		save_btn.enable();
		save_close_btn.enable();
	}

	protected void show_update_form(Integer recordid2) {
		if (getUiHandlers() != null) {
			getUiHandlers().onRecordDoubleClicked(recordid);

			build_add_form();

			if (maincontainer.hasMember(form_tbar)) {
				maincontainer.removeMember(form_tbar);
			}

			if (maincontainer.hasMember(form)) {
				maincontainer.removeMember(form);
			}

			if (!maincontainer.hasMember(form_tbar)) {
				maincontainer.addMember(form_tbar);
			}

			if (!maincontainer.hasMember(form)) {
				maincontainer.addMember(form);
				// form.show();
			}

			save_close_btn.disable();
			save_btn.disable();
			update_btn.enable();
		}
	}

	protected boolean validate_form() {
		/*
		 * String err = null;
		 * 
		 * if(err == null && form.validate()){ return true; }else{
		 * SC.say("Validation Error",err); return false; }
		 */

		if (form.validate()) {
			return true;
		} else {
			return false;
		}

	}

	protected void save_new_unit() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				charge = new WaterCharge();
				charge.setCurrency(currency.getValueAsString().toUpperCase());
				charge.setAmountPerUnit(Double.parseDouble(amount.getValue()
						.toString()));
				charge.setActive(true); // Boolean.parseBoolean(status.getValueAsString()));
				charge.setCreatedOn(d);

				getUiHandlers().onSaveNewButtonClicked(charge);

			} catch (Exception e) {
				Log.info("ChargeView.Save New Error...................."
						+ e.getMessage());
			} finally {
				charge = null;
			}

		}

	}

	protected void update_unit() {
		if (getUiHandlers() != null) {
			try {
				// VALIDATE FORM!!
				Date d = new Date();

				charge = new WaterCharge();
				charge.setChargeId(Integer.parseInt(charge_id_txt.getValue()
						.toString()));
				charge.setCurrency(currency.getValueAsString().toUpperCase());
				charge.setAmountPerUnit(Double.parseDouble(amount.getValue()
						.toString()));
				charge.setActive(true); //Boolean.parseBoolean(status.getValueAsString()));
				charge.setModifiedOn(d);

				getUiHandlers().onUpdateButtonClicked(charge);

			} catch (Exception e) {
				Log.info("ChargeView.Update Error...................."
						+ e.getMessage());
			} finally {
				charge = null;
			}

		}

	}

	protected void resetForm() {
		form.clearValue(CURRENCY);
		form.clearValue(AMOUNT);

		currency.setValue("KES");
		
		save_btn.disable();
		save_close_btn.disable();
		update_btn.disable();

		if (getUiHandlers() != null) {
			getUiHandlers().onNewButtonClicked();
		}
	}

	public void build_add_form() {
		currency = new TextItem(CURRENCY, constants.currency_lbl());
		currency.setSelectOnFocus(true);
		currency.setRequired(true);
		currency.setValue("KES");
		
		Date d = new Date();
		created_on = new TextItem(CREATED_ON, constants.charge_created_on_lbl());
		// created_on.setRequired(true);
		created_on.setValue(d.toString()); // System.currentTimeMillis()
		created_on.disable();

		charge_id_txt = new TextItem(CHARGE_ID, "");
		charge_id_txt.setVisible(false);
		
		modified_on = new TextItem(MODIFIED_ON, constants.charge_modified_on_lbl());
		modified_on .disable();

		charge_id_txt = new TextItem(CHARGE_ID, "");
		charge_id_txt.setVisible(false);

		floatValidator = new MyFloatValidator();

		amount = new TextItem(AMOUNT, constants.form_fee_amount_lbl());
		amount.setRequired(true);
		amount.setSelectOnFocus(true);
		amount.setValidators(floatValidator);

		/*
		 * status = new SelectItem(STATUS, constants.fee_status_lbl());
		 * status.setType("comboBox"); status.setRequired(true);
		 * status.setValueMap(getStatusValueMap());
		 */

		form_section = new SectionItem(FORM_SECTION);
		form_section.setDefaultValue(constants.charge_info_section_name());
		form_section.setItemIds("rowSpacer2", CURRENCY, AMOUNT, CREATED_ON, "rowSpacer1", MODIFIED_ON, "rowSpacer3");

		RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
		rowSpacer1.setStartRow(false);

		RowSpacerItem rowSpacer3 = new RowSpacerItem("rowSpacer3");
		rowSpacer1.setStartRow(false);
		
		form.setMargin(2);
		form.setNumCols(6);
		form.setCellPadding(2);
		form.setAutoFocus(false);
		form.setWrapItemTitles(false);
		form.setWidth("100%");

		// no ":" after the field name
		form.setTitleSuffix(" ");
		form.setRequiredTitleSuffix("*");
		form.setFields(form_section, rowSpacer2, currency, amount, created_on, rowSpacer1, modified_on, rowSpacer3);

	}

	@Override
	public void setSaveNewSuccess() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setChargeDetails(WaterCharge charge) {
		currency.setValue(charge.getCurrency());
		amount.setValue(charge.getAmountPerUnit());
		created_on.setValue(charge.getCreatedOn());
		form_section.setValue(constants.unit_info_section_name());
		charge_id_txt.setValue(charge.getChargeId());
		// status.setValue(charge.getActive());
modified_on.setValue(charge.getModifiedOn());

		if (charge.getActive() == true) {
			currency.enable();
			amount.enable();
			update_btn.enable();
			//status.enable();
		} else {
			currency.disable();
			amount.disable();
			update_btn.disable();
			//status.enable();
		}
		
	}

	@Override
	public void setUpdateSuccess() {
		maincontainer.removeMember(form_tbar);
		maincontainer.removeMember(form);
		SC.say(constants.record_update_success());
	}

	@Override
	public void setSaveNewError(String title, String msg) {
		onNewButtonClicked();
		SC.say(title, msg);
	}

	@Override
	public void setUpdateError(String title, String msg) {
		SC.say(title, msg);
	}

	private LinkedHashMap<String, String> getStatusValueMap() {
		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
		// int ctr = 0;

		hm.put("1", "Active");
		hm.put("0", "Inactive");

		//status.setValue("1");

		return hm;
	}

	class MyFloatValidator extends CustomValidator {

		@Override
		protected boolean condition(Object value) {
			if (value == null) {
				// err = "House Unit is required.";
				setErrorMessage("A value is required");
				return false;
			} else {
				try {
					Double temp = Double.parseDouble(value.toString());

					if (temp < 0) {
						setErrorMessage("Value cannot be a negative value.");
						return false;
					}

					return true;
				} catch (Exception e) {
					setErrorMessage("Invalid Value");
					return false;
				}
			}
		}
	}
	// -----------------------------------------------------------------------------------------------------------------

}