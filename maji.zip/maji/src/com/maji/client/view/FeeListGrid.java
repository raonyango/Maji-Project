package com.maji.client.view;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.maji.client.view.model.FeeRecord;
import com.maji.client.widgets.ContextListGrid;
import com.maji.shared.ibatis.beans.StandardCharge;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.DateDisplayFormat;
import com.smartgwt.client.types.ExpansionMode;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class FeeListGrid extends ContextListGrid {
	//private static final String SERVICE_ICON = "dashboard";

	private static final int AMNT_COLUMN_WIDTH = 180;
	private static final int DESC_COLUMN_WIDTH = 210;
	private static final int CREATED_COLUMN_WIDTH = 100; // 220
	
	private EventBus eventbus;
	private MajiStrings constants;

	@Inject
	public FeeListGrid(MajiStrings constants, EventBus eventbus) {
		super();
		this.eventbus = eventbus;
		this.constants = constants;
		this.setCanExpandRecords(true);
		this.setExpansionMode(ExpansionMode.RELATED);// DETAIL_FIELD);
		// this.setDetailField(FeeRecord.SERVICE_ID);
		this.setShowRecordComponents(true);
		this.setShowRecordComponentsByCell(true);
		//this.setHiliteProperty(FeeRecord.SERVICE_HILITE);
		this.setEmptyMessage(constants.no_record_msg());

		
		// initialise the List Grid fields
		ListGridField iconfield = new ListGridField(FeeRecord.ICON,
				FeeRecord.ICON_DISPLAY_NAME, ICON_COLUMN_WIDTH);
		iconfield.setImageSize(16);
		iconfield.setAlign(Alignment.CENTER);
		iconfield.setType(ListGridFieldType.IMAGE);
		iconfield.setImageURLPrefix(URL_PREFIX);
		iconfield.setImageURLSuffix(URL_SUFFIX);

		ListGridField fee_amnt_field = new ListGridField(
				FeeRecord.FEE_AMOUNT, constants.fee_amount_lbl(),
				AMNT_COLUMN_WIDTH);
		ListGridField fee_desc_field = new ListGridField(
				FeeRecord.FEE_DESC, constants.fee_desc_lbl(),
				DESC_COLUMN_WIDTH);
		ListGridField status_field = new ListGridField(
				FeeRecord.STATUS_NAME, constants.status_name_lbl(),
				CREATED_COLUMN_WIDTH);
		ListGridField created_on_field = new ListGridField(
				FeeRecord.CREATED_ON, constants.person_created_on_lbl(),
				CREATED_COLUMN_WIDTH);
		created_on_field.setCellAlign(Alignment.CENTER);

		created_on_field.setType(ListGridFieldType.TIME);
		created_on_field.setCellAlign(Alignment.CENTER);
		created_on_field.setDateFormatter(DateDisplayFormat.TOSERIALIZEABLEDATE);

		ListGridField empty_field = new ListGridField(EMPTY_FIELD,
				EMPTY_FIELD_DISPLAY_NAME);

		// set the fields into the List Grid
		this.setFields(new ListGridField[] { iconfield, fee_desc_field, fee_amnt_field, status_field,created_on_field,
				empty_field });
	}

	public void setServicesResultSet(List<StandardCharge> fee_dtos) {
		try {

			int ctr2 = 0;
						
			FeeRecord[] feerecords = new FeeRecord[fee_dtos.size()];
			for (int i = 0; i < fee_dtos.size(); i++) {
				feerecords[ctr2] = createServiceRecord(fee_dtos.get(i));
				ctr2++;
			}

			// populate the List Grid
			this.setData(feerecords);
			
		} catch (Exception e) {
			Log.error("FeeListGrid Error...................." + e.getLocalizedMessage());
			Log.error( e.getStackTrace().toString());
		}
	}

	private FeeRecord createServiceRecord(StandardCharge fee_dto) {
		return new FeeRecord(fee_dto);
	}

/*	@Override
	protected Canvas createRecordComponent(final ListGridRecord record,
			Integer colNum) {
		String field = this.getFieldName(colNum);
		IButton button = null;
		if (field.equals(FeeRecord.UNIT_TELEPHONE)) {
			button = createGridButton("$");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(FeeRecord.FEE_ID)));
				}
			});
			if (record.getAttributeAsBoolean(FeeRecord.UNIT_TELEPHONE)) {
				button.disable();
			}
			return button;
		} else if (field.equals(FeeRecord.CREATED_ON)) {
			button = createGridButton(">>");
			button.addClickHandler(new ClickHandler() {
				public void onClick(ClickEvent event) {
					eventbus.fireEvent(new ExpandEvent(record
							.getAttributeAsInt(FeeRecord.FEE_ID)));
				}
			});
			if (!record.getAttributeAsBoolean(FeeRecord.CREATED_ON)) {
				button.disable();
			}
			return button;
		} else {
			return null;// createRecordComponent(record, colNum);
		}
		
		return createRecordComponent(record, colNum);
	}*/

	private IButton createGridButton(String title) {
		IButton button = new IButton();
		button.setHeight(18);
		button.setWidth(35);
		// button.setIcon("flags/16/" + record.getAttribute("countryCode") +
		// ".png");
		button.setTitle(title);
		return button;
	}

	/*private static Hilite[] hilites = new Hilite[] { new Hilite() {
		{
			// setFieldNames(FeeRecord.FEE_AMOUNT);
			setId(HILITE_BOUGHT_ID);
			setTextColor("#18187C");
			setBackgroundColor("#DCDCDC");
			setCriteria(new Criterion(FeeRecord.UNIT_TELEPHONE,
					OperatorId.EQUALS, true));
			// setCriteria(new AdvancedCriteria(OperatorId.AND, new Criterion[]
			// {new Criterion(FeeRecord.UNIT_TELEPHONE, OperatorId.EQUALS,
			// true)}));
			// setCssText("font-weight:bolder;color:#18187C;background-color:#DCDCDC");
		}
	} };*/

	@Override
	protected Canvas getExpansionComponent(final ListGridRecord record) {
		final FeeListGrid grid = this;
		FeeRecord[] arr;
		ContextListGrid addonsgrid;

		VLayout layout = new VLayout(5);
		layout.setPadding(5);

		/*
		 * addonsgrid = new AddonsListGrid(constants, eventbus);
		 * addonsgrid.setWidth100();//500 addonsgrid.setHeight(134);//224
		 * addonsgrid.setCellHeight(22);
		 * addonsgrid.setHiliteProperty(FeeRecord.SERVICE_HILITE);
		 * addonsgrid.setEmptyMessage(constants.no_addons_msg() + " " +
		 * constants.formsg() + " " +
		 * record.getAttributeAsString(FeeRecord.FEE_AMOUNT));
		 * 
		 * arr =
		 * getRelatedAddons(record.getAttributeAsInt(FeeRecord.SERVICE_ID));
		 * if(arr != null){ addonsgrid.setData(arr);
		 * addonsgrid.setHilites(hilites); }
		 * //addonsgrid.setDataSource(getRelatedDataSource(record));
		 * //addonsgrid.fetchRelatedData(record,
		 * SupplyCategoryXmlDS.getInstance());
		 * 
		 * layout.addMember(addonsgrid);
		 */
		HLayout hcontainer = new HLayout(10);
		hcontainer.setAlign(Alignment.CENTER);

		Button close_btn = new Button(constants.hide_btn());
		close_btn.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				grid.collapseRecord(record);
			}
		});
		close_btn.setWidth(80);
		close_btn.setLayoutAlign(Alignment.RIGHT);
		hcontainer.addMember(close_btn);

		layout.addMember(hcontainer);

		return layout;
	}
}
