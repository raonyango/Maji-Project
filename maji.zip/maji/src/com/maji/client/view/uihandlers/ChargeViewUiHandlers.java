package com.maji.client.view.uihandlers;

import com.maji.shared.ibatis.beans.WaterCharge;


public interface ChargeViewUiHandlers extends UiHandlers{

	void onRecordDoubleClicked(int recordid);

	void onResultSetFirstButtonClicked();

	void onResultSetPreviousButtonClicked();

	void onResultSetNextButtonClicked();

	void onRefreshButtonClicked();

	void onNewButtonClicked();

	void onSaveNewButtonClicked(WaterCharge charge);

	void onUpdateButtonClicked(WaterCharge charge);

}
