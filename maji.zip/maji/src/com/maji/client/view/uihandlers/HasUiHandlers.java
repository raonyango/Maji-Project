package com.maji.client.view.uihandlers;

public interface HasUiHandlers<T extends UiHandlers> {

	/**
	 * Sets the {@link UiHandlers} subclass associated with this object.
	 * 
	 * @param uiHandlers
	 *            The {@link UiHandlers} subclass (of type {@code C}) to
	 *            associate with this object.
	 */
	void setUiHandlers(T uiHandlers);

}
