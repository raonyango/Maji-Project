package com.maji.client.view.uihandlers;

import com.google.gwt.user.client.ui.Widget;


public abstract class ViewImpl implements View {

	  @Override
	  public void addToSlot(Object slot, Widget content) {
	  }

	  @Override
	  public void removeFromSlot(Object slot, Widget content) {
	  }

	  @Override
	  public void setInSlot(Object slot, Widget content) {
	  }
	}
