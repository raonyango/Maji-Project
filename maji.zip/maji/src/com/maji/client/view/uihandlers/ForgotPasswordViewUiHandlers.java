package com.maji.client.view.uihandlers;

public interface ForgotPasswordViewUiHandlers extends UiHandlers {

	void onSendButtonClicked();

	void onResetButtonClicked();

	void onCloseDialogButtonClicked();

}
