package com.maji.client.view;

import java.util.Date;
import java.util.List;

import com.allen_sauer.gwt.log.client.Log;
import com.google.inject.Inject;
import com.maji.client.presenter.UnitPresenter;
import com.maji.client.view.model.BlockDataSource;
import com.maji.client.view.model.BlockRecord;
import com.maji.client.view.model.PersonDataSource;
import com.maji.client.view.model.PersonRecord;
import com.maji.client.view.model.UnitRecord;
import com.maji.client.view.uihandlers.UnitViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.ContextListGrid;
import com.maji.client.widgets.RecordToolBar;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.ToolBar;
import com.maji.shared.ibatis.beans.Block;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiMessages;
import com.maji.shared.properties.MajiStrings;
import com.maji.shared.properties.ToolbarConstants;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.RowSpacerItem;
import com.smartgwt.client.widgets.form.fields.SectionItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;

public class UnitView extends ViewWithUiHandlers<UnitViewUiHandlers>
		implements UnitPresenter.IUnitViewDisplay {

	private static final String CONTEXT_AREA_WIDTH = "100%";
	private int recordid;

	private final RecordToolBar toolbar, form_tbar;
	private final ContextListGrid listgrid;
	private final StatusBar statusbar;
	
	private VLayout maincontainer;
	private ToolStripButton printpreviewbtn, save_btn, save_close_btn, update_btn;
	protected DynamicForm form;
	
	private int numberofelements;
	private int numberselected;
	private int pageNumber;

	private MajiMessages messages;
	private ToolbarConstants tconstants;
private HouseUnit unit;

	private static final String UNITNUM = "unitnum";
	private static final String METERNUM = "meternum";
	private static final String BLOCK = "block";
	private static final String TENANT = "tenant";
	private static final String OWNER = "owner";
	private static final String UNIT_ID = "pid";
	private static final String CREATED_ON = "created_on";
	private static final String FORM_SECTION = "form_section";

	protected TextItem unitnum, meternum, surname, address, created_on,
			unit_id_txt;
	protected SelectItem owner, block, tenant;
	protected SectionItem form_section;
	protected DataSource person_ds, block_ds;
	private  MajiStrings constants;
	
	@Inject
	public UnitView(RecordToolBar toolbar, UnitListGrid listgrid,RecordToolBar form_toolbar,DynamicForm iform,
			StatusBar statusbar, MajiMessages messages, ToolbarConstants tconstants,  MajiStrings constants) {
		this.toolbar = toolbar;
		this.listgrid = listgrid;
		this.statusbar = statusbar;
		this.messages = messages;
		this.tconstants = tconstants;
		this.form_tbar = form_toolbar;
		this.form = iform;
		this.constants=constants;
		
		this.numberofelements = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		this.numberselected = 0;
		pageNumber = 1;

		maincontainer = new VLayout();
		
		// initialise the View's layout container
		maincontainer.setStyleName(MajiCSS.context_area);
		maincontainer.setWidth(CONTEXT_AREA_WIDTH);
	
		// add the Tool Bar, List Grid, and Status Bar to the View's layout
		// container
		maincontainer.addMember(this.toolbar);
		maincontainer.addMember(this.listgrid);
		maincontainer.addMember(this.statusbar);

		bindCustomUiHandlers();

		recordid = -1;
	}

	protected void bindCustomUiHandlers() {
		// register the ListGird handlers
		listgrid.addSelectionChangedHandler(new SelectionChangedHandler() {
			@Override
			public void onSelectionChanged(SelectionEvent event) {

				ListGridRecord[] records = event.getSelection();

				numberselected = records.length;

				String selectedLabel = messages.selected(numberselected,
						numberofelements);
				statusbar.getSelectedLabel().setContents(selectedLabel);

			}
		});
		// initialise the ToolBar and register its handlers
		initToolBar();

		listgrid.addRecordDoubleClickHandler(new RecordDoubleClickHandler() {
			@Override
			public void onRecordDoubleClick(RecordDoubleClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(UnitRecord.UNIT_ID);

				show_update_form(recordid);
			}
		});

		listgrid.addRecordClickHandler(new RecordClickHandler() {

			@Override
			public void onRecordClick(RecordClickEvent event) {
				Record record = event.getRecord();
				recordid = record.getAttributeAsInt(UnitRecord.UNIT_ID);

				if (maincontainer.hasMember(form)) {
					show_update_form(recordid);
				}
			}
		});

		// initialise the StatusBar and register its handlers
		initStatusBar();
	}

	protected void initToolBar() {
		save_btn = form_tbar.addButton(ToolBar.SAVE_BUTTON,
				tconstants.savebtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							save_new_unit();

							resetForm();
						}
					}
				});
		save_btn.disable();

		save_close_btn = form_tbar.addButton(ToolBar.SAVE_AND_CLOSE_BUTTON,
				tconstants.save_close_btn_caption(),
				tconstants.save_close_btn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							if (validate_form()) {
								save_new_unit();

								maincontainer.removeMember(form_tbar);
								maincontainer.removeMember(form);
								// form = null;

							}
						}
					}
				});
		save_close_btn.disable();
		form_tbar.addSeparator();

		update_btn = form_tbar.addButton(ToolBar.UPDATE_BUTTON,
				tconstants.updatebtn_caption(), tconstants.updatebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (validate_form()) {
							update_unit();

							resetForm();
						}
					}
				});
		update_btn.disable();
		form_tbar.addSeparator();

		form_tbar.addButton(ToolBar.CANCEL_BUTTON,
				tconstants.cancelbtn_caption(), tconstants.savebtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							maincontainer.removeMember(form_tbar);
							maincontainer.removeMember(form);
							// form = null;
						}

					}
				});

		toolbar.addButton(ToolBar.NEW_ACCOUNT_BUTTON,
				tconstants.new_btn_caption(), tconstants.new_btn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {

						onNewButtonClicked();
					}
				});

		toolbar.addSeparator();
		
		toolbar.addButton(ToolBar.REFRESH_BUTTON, tconstants
				.refreshbtn_caption(), tconstants.refreshbtn_tooltip(),
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							//maincontainer.disable();
							getUiHandlers().onRefreshButtonClicked();
						}
					}
				});

		toolbar.addSeparator();

		printpreviewbtn = toolbar.addButton(ToolBar.PRINT_PREVIEW_BUTTON,
				tconstants.prinpreviewbtn_caption(), tconstants
						.printpreviewbtn_tooltip(), new ClickHandler() {
					public void onClick(ClickEvent event) {
						
					}
				});

		printpreviewbtn.disable();

	}

	protected void initStatusBar() {

		// "0 of 50 selected"
		// statusbar.getSelectedLabel().setContents(Serendipity.getConstants().selectedLabel());

		statusbar.getResultSetFirstButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetFirstButtonClicked();
				}
			}
		});

		statusbar.getResultSetPreviousButton().addClickHandler(
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						if (getUiHandlers() != null) {
							getUiHandlers().onResultSetPreviousButtonClicked();
						}
					}
				});

		// "Page 1"
		// statusbar.getPageNumberLabel().setContents(Serendipity.getConstants().pageNumberLabel());

		statusbar.getResultSetNextButton().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if (getUiHandlers() != null) {
					getUiHandlers().onResultSetNextButtonClicked();
				}
			}
		});
	}

	@Override
	public void setResultSet(List<HouseUnit> resultset) {
		// resultSet == null when there are no items in table
		if (resultset != null) {
			
			try{
				((UnitListGrid) listgrid).setServicesResultSet(resultset);
			}catch (Exception e){
				Log.info("UnitView.setResultSet Error...................." + e.getMessage());
			}
		}
	}

	@Override
	public void refreshStatusBar() {
		// update Selected label e.g "0 of 50 selected"
		statusbar.getSelectedLabel().setContents(messages.selected(numberselected,
				numberofelements));
		//Log.info(numberofelements + "............REFRESH........");
		// update Page number label e.g "Page 1"
		statusbar.getPageNumberLabel().setContents(messages.page(pageNumber));
	}

	@Override
	public void setPageNumber(int pagenumber) {
		this.pageNumber = pagenumber;
	}

	@Override
	public void setNumberSelected(int numberselected) {
		this.numberselected = numberselected;
	}

	@Override
	public Layout asWidget() {
		return maincontainer;
	}

	@Override
	public StatusBar getStatusBar() {
		return statusbar;
	}

	@Override
	public void setNumberOfElements(int numberofelements) {
		this.numberofelements = numberofelements;
		Log.info(numberofelements + " units....................");
	}
	
	// -----------------------------------------------------------------------------------------------------------------

	protected void onNewButtonClicked() {
		if (getUiHandlers() != null) {
			getUiHandlers().onNewButtonClicked();

			build_add_form();
		}

		if (maincontainer.hasMember(form_tbar)) {
			maincontainer.removeMember(form_tbar);
			// form = null;
		}

		if (maincontainer.hasMember(form)) {
			maincontainer.removeMember(form);							
			// form = null;
		}
		
		resetForm();
		
		maincontainer.addMember(form_tbar);
		maincontainer.addMember(form);

		update_btn.disable();
		save_btn.enable();
		save_close_btn.enable();
	}
	
		protected void show_update_form(Integer recordid2) {
			if (getUiHandlers() != null) {
				getUiHandlers().onRecordDoubleClicked(recordid);

				build_add_form();

				if (maincontainer.hasMember(form_tbar)) {
					maincontainer.removeMember(form_tbar);
				}

				if (maincontainer.hasMember(form)) {
					maincontainer.removeMember(form);
				}

				if (!maincontainer.hasMember(form_tbar)) {
					maincontainer.addMember(form_tbar);
				}

				if (!maincontainer.hasMember(form)) {
					maincontainer.addMember(form);
					// form.show();
				}

				save_close_btn.disable();
				save_btn.disable();
				update_btn.enable();
			}
		}

		protected boolean validate_form() {
			/*
			 * String err = null;
			 * 
			 * if(err == null && form.validate()){ return true; }else{
			 * SC.say("Validation Error",err); return false; }
			 */

			if (form.validate()) {
				return true;
			} else {
				return false;
			}

		}

		protected void save_new_unit() {
			if (getUiHandlers() != null) {
				try {
					// VALIDATE FORM!!
					Date d = new Date();

					unit = new HouseUnit();
					unit.setBlockId(Integer.parseInt(block.getValue()
							.toString()));
					unit.setMeterNumber(meternum.getValueAsString().toUpperCase());
					unit.setOwnerId(Integer.parseInt(owner.getValue()
							.toString()));
					unit.setTenantId(Integer.parseInt(tenant.getValue()
							.toString()));
					unit.setUnitNumber(unitnum.getValueAsString().toUpperCase());
					unit.setCreatedOn(d);
					
					getUiHandlers().onSaveNewButtonClicked(unit);

				} catch (Exception e) {
					Log.info("UnitView.Save New Error...................."
							+ e.getMessage());
				} finally {
					unit = null;
				}

			}

		}

		protected void update_unit() {
			if (getUiHandlers() != null) {
				try {
					// VALIDATE FORM!!
					Date d = new Date();

					unit = new HouseUnit();
					unit.setUnitId(Integer.parseInt(unit_id_txt.getValue()
							.toString()));
					unit.setBlockId(Integer.parseInt(block.getValue()
							.toString()));
					unit.setMeterNumber(meternum.getValueAsString().toUpperCase());
					unit.setOwnerId(Integer.parseInt(owner.getValue()
							.toString()));
					unit.setTenantId(Integer.parseInt(tenant.getValue()
							.toString()));
					unit.setUnitNumber(unitnum.getValueAsString().toUpperCase());
					unit.setModifiedOn(d);
					
					getUiHandlers().onUpdateButtonClicked(unit);

				} catch (Exception e) {
					Log.info("UnitView.Update Error...................."
							+ e.getMessage());
				} finally {
					unit = null;
				}

			}

		}

		protected void resetForm() {
			form.clearValue(BLOCK);
			form.clearValue(UNITNUM);
			form.clearValue(METERNUM);
			form.clearValue(TENANT);
			form.clearValue(OWNER);
			
			save_btn.disable();
			save_close_btn.disable();
			update_btn.disable();

			if (getUiHandlers() != null) {
				getUiHandlers().onNewButtonClicked();
			}
		}

		public void build_add_form() {
			unitnum = new TextItem(UNITNUM, constants.unit_number_lbl());
			unitnum.setSelectOnFocus(true);
			// unitnum.setWrapTitle(false);
			// unitnum.setDefaultValue("[Account Name]");
			unitnum.setRequired(true);

			meternum = new TextItem(METERNUM, constants.meter_no_lbl());
			meternum.setSelectOnFocus(true);
			meternum.setRequired(true);

			block = new SelectItem(BLOCK, constants.block_lbl());
			block.setType("comboBox");
			block.setRequired(true);
			block.setValueField(BlockRecord.BLOCK_ID);
			block.setDisplayField(BlockRecord.BLOCK_NUMBER);

			
			Date d = new Date();
			created_on = new TextItem(CREATED_ON, constants.created_on_lbl());
			// created_on.setRequired(true);
			created_on.setValue(d.toString()); // System.currentTimeMillis()
			created_on.disable();

			unit_id_txt = new TextItem(UNIT_ID, "");
			unit_id_txt.setVisible(false);

			owner = new SelectItem(OWNER, constants.owner_lbl());
			owner.setType("comboBox");
			owner.setRequired(true);
			owner.setValueField(PersonRecord.PERSON_ID);
			owner.setDisplayField(PersonRecord.FULL_NAME);

			tenant = new SelectItem(TENANT, constants.tenant_lbl());
			tenant.setType("comboBox");
			tenant.setRequired(true);
			tenant.setValueField(PersonRecord.PERSON_ID);
			tenant.setDisplayField(PersonRecord.FULL_NAME);
			
			form_section = new SectionItem(FORM_SECTION);
			form_section.setDefaultValue(constants.unit_info_section_name());
			form_section.setItemIds(UNITNUM, OWNER, TENANT,  "rowSpacer1", 
					BLOCK, METERNUM, CREATED_ON, "rowSpacer2");

			RowSpacerItem rowSpacer1 = new RowSpacerItem("rowSpacer1");
			rowSpacer1.setStartRow(false);

			RowSpacerItem rowSpacer2 = new RowSpacerItem("rowSpacer2");
			rowSpacer1.setStartRow(false);

			form.setMargin(2);
			form.setNumCols(6);
			form.setCellPadding(2);
			form.setAutoFocus(false);
			form.setWrapItemTitles(false);
			form.setWidth("100%");

			// no ":" after the field name
			form.setTitleSuffix(" ");
			form.setRequiredTitleSuffix("*");
			form.setFields(form_section, unitnum, owner, tenant,  rowSpacer1,
					block, meternum,created_on, rowSpacer2);

		}

		@Override
		public void setPersonDSource(List<Person> person_lst) {
			if (person_lst != null) {
				PersonRecord r;
				person_ds = PersonDataSource.getInstance();

				for (Person person : person_lst) {
					r = new PersonRecord();
					r.setPersonID(person.getPersonId());
					r.setFullName(person.getSurname() + " " + person.getFirstName());

					person_ds.addData(r);
				}

				owner.setOptionDataSource(person_ds);
				tenant.setOptionDataSource(person_ds);
								
			}
		}

		@Override
		public void setBlockDSource(List<Block> block_dtos) {
			if (block_dtos != null) {
				BlockRecord r;
				block_ds = BlockDataSource.getInstance();

				for (Block block : block_dtos) {
					r = new BlockRecord();
					r.setBlockId(block.getBlockId());
					r.setBlockNumber(block.getBlockName());

					block_ds.addData(r);
				}

				block.setOptionDataSource(block_ds);
				//block.setDefaultToFirstOption(true);
			}
		}

		@Override
		public void setSaveNewSuccess() {
			// TODO Auto-generated method stub

		}

		@Override
		public void setUnitDetails(HouseUnit unit) {
			unitnum.setValue(unit.getUnitNumber());
			meternum.setValue(unit.getMeterNumber());
			owner.setValue(unit.getOwnerId());
			created_on.setValue(unit.getCreatedOn());
			block.setValue(unit.getBlockId());
			tenant.setValue(unit.getTenantId());
			form_section.setValue(constants.unit_info_section_name() + ": "
					+ unit.getUnitNumber().toUpperCase());
			unit_id_txt.setValue(unit.getUnitId());
	
			unitnum.enable();
			meternum.enable();
			block.enable();
			tenant.enable();
			owner.enable();
			update_btn.enable();
		}

		@Override
		public void setUpdateSuccess() {
			maincontainer.removeMember(form_tbar);
			maincontainer.removeMember(form);
			SC.say(constants.record_update_success());
		}

		@Override
		public void setSaveNewError(String title, String msg) {
			onNewButtonClicked();
			SC.say(title, msg);
		}

		@Override
		public void setUpdateError(String title, String msg) {
			SC.say(title, msg);
		}

		// -----------------------------------------------------------------------------------------------------------------

}