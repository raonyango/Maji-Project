package com.maji.client.view;

import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.inject.Inject;
import com.maji.client.view.uihandlers.LoginViewUiHandlers;
import com.maji.client.view.uihandlers.ViewWithUiHandlers;
import com.maji.client.widgets.Loading;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.FormErrorOrientation;
import com.smartgwt.client.types.Overflow;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.EventHandler;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickEvent;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.DrawEvent;
import com.smartgwt.client.widgets.events.DrawHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.LinkItem;
import com.smartgwt.client.widgets.form.fields.PasswordItem;
import com.smartgwt.client.widgets.form.fields.RowSpacerItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.KeyUpEvent;
import com.smartgwt.client.widgets.form.fields.events.KeyUpHandler;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.maji.client.presenter.LoginPresenter;

public class LoginView extends ViewWithUiHandlers<LoginViewUiHandlers> implements KeyUpHandler, LoginPresenter.ILoginViewDisplay {
	
	private MajiStrings constants;
	
	private VLayout widgetcontainer, maincontainer;
	private HLayout header;
	private String MEMBER_WIDTH_PERCENTAGE = "50%", FORM_WIDTH = "25%";
	private DynamicForm loginform, linksform; 
	private boolean VALIDATE_ON_EXIT = true;
    private Button loginbtn;
    private Button resetbtn;
    private TextItem usernametxt;
    private PasswordItem passwordtxt;
    private Loading loading;
    private com.google.gwt.user.client.ui.Label infolbl;
    //private HTMLFlow titlelbl;
    private LinkItem forgotpasswordlnk, registerlnk;
    private CheckboxItem remembermechk;
    private Button closedialogbtn;
    private Window dialogbox;
    
    @Inject
    public LoginView(MajiStrings constants) { 
    	this.constants = constants;
    	initWidgets();
    	
    	initHandlers();
    }
    
    private VLayout initWidgets(){   
        VLayout infobar = new VLayout();
        infobar.setLayoutAlign(Alignment.CENTER);
        infobar.setWidth100();
        infobar.setHeight(20);
       
       /* titlelbl = new HTMLFlow(constants.login_title());
        titlelbl.setStyleName(MajiCSS.brainup_titlelbl);
        titlelbl.setLayoutAlign(Alignment.LEFT);
        titlelbl.setVisible(false);
        infobar.addMember(titlelbl); */
        
        infolbl = new com.google.gwt.user.client.ui.Label();
        infolbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
        infolbl.setHeight(MajiConstants.LABEL_HEIGHT + "px");
        //infolbl.setImage("help.png", "[SKIN]/actions/help.png"); 
        infobar.addMember(infolbl);
        
        loginbtn = new Button(constants.login_button());
        loginbtn.setLayoutAlign(Alignment.CENTER);
        loginbtn.addStyleName(MajiCSS.login_form_button);
        
        resetbtn = new Button(constants.reset_button());  
        resetbtn.addStyleName(MajiCSS.login_form_button);
        resetbtn.setLayoutAlign(Alignment.CENTER);
        
        closedialogbtn = new Button(constants.close_button());
        closedialogbtn.addStyleName(MajiCSS.login_form_button);  
        closedialogbtn.setLayoutAlign(Alignment.CENTER);
    	closedialogbtn.setVisible(false);
    	
        forgotpasswordlnk = new LinkItem("forgotpwdlink");
        forgotpasswordlnk.setLinkTitle(constants.forgot_password());
        forgotpasswordlnk.setTitle("");
        
        registerlnk = new LinkItem("registerlink");
        registerlnk.setLinkTitle(constants.register());
        registerlnk.setTitle("");
        
        remembermechk = new CheckboxItem("remembermechk");
        remembermechk.setTitle(constants.remember_me());        
        //remembermechk.setVisible(false);
        
        usernametxt = new TextItem("username", constants.username_label());
        usernametxt.setWidth(MajiConstants.FORM_FIELD_WIDTH);
        usernametxt.setValidateOnExit(VALIDATE_ON_EXIT);
        usernametxt.setLength(50);
        usernametxt.setErrorMessageWidth(MajiConstants.ERROR_MSG_WIDTH);
        usernametxt.addKeyUpHandler(this);
       	usernametxt.setValue("admin");
       	
        passwordtxt = new PasswordItem("password", constants.password_label());
        passwordtxt.setWidth(MajiConstants.FORM_FIELD_WIDTH);
        passwordtxt.setValidateOnExit(VALIDATE_ON_EXIT);
        passwordtxt.setLength(50);
        passwordtxt.setErrorMessageWidth(MajiConstants.ERROR_MSG_WIDTH);
        passwordtxt.addKeyUpHandler(this);
        passwordtxt.setValue("a");
        
        HLayout buttonbar = new HLayout();
        buttonbar.setMembersMargin(5);        
        buttonbar.addMember(loginbtn);
        buttonbar.addMember(resetbtn);
        buttonbar.addMember(closedialogbtn);
        buttonbar.setLayoutAlign(Alignment.CENTER);
        buttonbar.setWidth(FORM_WIDTH);
        buttonbar.setHeight(loginbtn.getOffsetHeight() + 2);
              
        RowSpacerItem rowspacer = new RowSpacerItem("rowSpacer");
		rowspacer.setStartRow(true);
		rowspacer.setHeight(5);

		loginform = new DynamicForm();
		loginform.setMargin(2);
		loginform.setNumCols(2);
		loginform.setCellPadding(10);
		loginform.setAutoFocus(false);
		loginform.setWrapItemTitles(false);
		loginform.setWidth(FORM_WIDTH);
		loginform.setLayoutAlign(Alignment.CENTER);
		loginform.setRequiredMessage(constants.required_field_error_msg());
		loginform.setErrorOrientation(FormErrorOrientation.RIGHT);
		loginform.setFields(rowspacer, usernametxt, rowspacer, passwordtxt, rowspacer, remembermechk);
		
		linksform = new DynamicForm();
		linksform.setMargin(2);
		linksform.setNumCols(2);
		linksform.setCellPadding(10);
		linksform.setAutoFocus(false);
		linksform.setWrapItemTitles(false);
		linksform.setWidth(FORM_WIDTH);
		linksform.setLayoutAlign(Alignment.CENTER);
		linksform.setRequiredMessage(constants.required_field_error_msg());
		linksform.setErrorOrientation(FormErrorOrientation.RIGHT);
		linksform.setFields(forgotpasswordlnk, rowspacer, registerlnk);
		
		loading = new Loading(constants.loading());
        loading.setLayoutAlign(Alignment.CENTER);
        loading.hide();
        
		VLayout logincontainer = new VLayout();
		logincontainer.setLayoutAlign(Alignment.CENTER);
		logincontainer.addMember(loginform);
		logincontainer.addMember(buttonbar);
		logincontainer.addMember(linksform);
		logincontainer.setStyleName(MajiCSS.brainup_rnd_container);
		
		widgetcontainer = new VLayout();
        widgetcontainer.setLayoutAlign(Alignment.CENTER);
        widgetcontainer.setLayoutAlign(VerticalAlignment.CENTER);
        widgetcontainer.setStyleName(MajiCSS.login_container);	
        widgetcontainer.setWidth(FORM_WIDTH);        
		widgetcontainer.addMember(infobar);
        widgetcontainer.addMember(logincontainer);
        widgetcontainer.addMember(loading);
       
        Label headerlabel = new Label();
		headerlabel.setStyleName(MajiCSS.navigation_pane_header_lbl);
		headerlabel.setWidth(20 + "%");
		headerlabel.setContents(constants.login_title());
		headerlabel.setLayoutAlign(Alignment.LEFT);
		headerlabel.setOverflow(Overflow.HIDDEN);

		header = new HLayout();
		header.setStyleName(MajiCSS.navigation_pane_header);
		header.setHeight(MajiConstants.FORM_HEADER_HEIGHT + "px");
		header.setWidth(MEMBER_WIDTH_PERCENTAGE);
		header.setLayoutAlign(Alignment.CENTER);
		header.addMember(headerlabel);
		
		Layout spacer = new VLayout();
	    
		maincontainer = new VLayout();
		maincontainer.setWidth100();
		maincontainer.setHeight(67 + "%"); //67
		maincontainer.setAlign(Alignment.CENTER);
		maincontainer.setAlign(VerticalAlignment.CENTER);
		maincontainer.setMembers(header, widgetcontainer, spacer);
		maincontainer.addDrawHandler(new DrawHandler() {
			
			@Override
			public void onDraw(DrawEvent event) {
				usernametxt.focusInItem();
			}
		});
		
		widgetcontainer.setHeight(getIntValue(maincontainer.getOffsetHeight() * 0.38f));        
		logincontainer.setHeight(getIntValue(widgetcontainer.getOffsetHeight() * 0.99f));
		infolbl.setWidth(getIntValue(widgetcontainer.getOffsetWidth()) + "px"); 
		spacer.setHeight(Float.valueOf(maincontainer.getOffsetHeight() * 0.35f).intValue());	    
	    
        return maincontainer;
        
    }
    
    private int getIntValue(float f) {
		Float fl = new Float(f);
		return fl.intValue();
	}

	private void initHandlers(){
    	loginbtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				getUiHandlers().onLoginButtonClicked();
			}
		});
    	
    	resetbtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				getUiHandlers().onResetButtonClicked();
			}
		});

    	closedialogbtn.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				getUiHandlers().onCloseDialogButtonClicked();
				//onDialogClose();
			}
		});

    	forgotpasswordlnk.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {
			
			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				getUiHandlers().onForgotPasswordLinkClicked();				
			}
		});
    	
    	registerlnk.addClickHandler(new com.smartgwt.client.widgets.form.fields.events.ClickHandler() {
			
			@Override
			public void onClick(
					com.smartgwt.client.widgets.form.fields.events.ClickEvent event) {
				getUiHandlers().onRegisterLinkClicked();				
			}
		});
    }
    
    public void onKeyUp(KeyUpEvent event) {
        if(EventHandler.getKeyEventCharacterValue() == KeyCodes.KEY_ENTER){ //event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
            if (event.getSource().equals(usernametxt)) {
                passwordtxt.focusInItem();
            }  else if (event.getSource().equals(passwordtxt)) {
                getUiHandlers().onLoginButtonClicked();
            }
        }
    }
 
    public void createPopup(){
    	
    	dialogbox = new Window();
    	dialogbox.setWidth(getIntValue(widgetcontainer.getOffsetWidth() + 20));
    	dialogbox.setHeight(getIntValue(widgetcontainer.getOffsetHeight() + 30));    	
    	dialogbox.setIsModal(true);
    	dialogbox.setShowModalMask(true);
    	dialogbox.setShowMinimizeButton(false);
    	dialogbox.setShowMaximizeButton(false);
    	dialogbox.setCanDragResize(false);
    	dialogbox.setTitle(constants.login_title());
		dialogbox.centerInPage();	
		dialogbox.setAlign(VerticalAlignment.TOP);
    	dialogbox.addCloseClickHandler(new CloseClickHandler() {
			
			@Override
			public void onCloseClick(CloseClickEvent event) {
				getUiHandlers().onCloseDialogButtonClicked();
				//onDialogClose();
			}
		}); 
    	//header.setVisible(false);
    	linksform.setVisible(false);    	
    }
      
    @Override
    public Layout asWidget() {
        return maincontainer;
    }

    @Override
    public void setLoading(boolean load) {
        if (load) {
            loading.show();
        } else {
            loading.hide();
        }
    }
    
    @Override
    public void onAttach() {
       //super.onAttach();
       usernametxt.focusInItem();
    }
	@Override
	public Boolean getRememberMeValue() {
		
		return remembermechk.getValueAsBoolean();
	}

	@Override
	public void setRememberMeValue(boolean value) {
		remembermechk.setValue(value);
	}

	@Override
	public void setLoginstatuslbl(String value, boolean iserror) {
		if(value != null){
			if(iserror){
				if(infolbl.getStyleName().contains(MajiCSS.brainup_info_lbl))
					infolbl.removeStyleName(MajiCSS.brainup_info_lbl);
				if(!infolbl.getStyleName().contains(MajiCSS.brainup_err_lbl))
					infolbl.setStyleName(MajiCSS.brainup_err_lbl);				
			}else{
				if(infolbl.getStyleName().contains(MajiCSS.brainup_err_lbl))
					infolbl.removeStyleName(MajiCSS.brainup_err_lbl);
				if(!infolbl.getStyleName().contains(MajiCSS.brainup_info_lbl))
					infolbl.setStyleName(MajiCSS.brainup_info_lbl);				
			}				
			
			infolbl.setText(value);
		}else
			infolbl.setText("");			
	}

	@Override
	public String getPasswordValue() {
		if(passwordtxt.getValue() == null)
			return "";
		else
			return passwordtxt.getValueAsString();
	}

	@Override
	public String getUserNameValue() {
		if(usernametxt.getValue() == null)
			return "";
		else
			return usernametxt.getValueAsString().trim();
	}

	@Override
	public void setPasswordValue(String value) {
		if(value != null)
			passwordtxt.setValue(value);
		else
			passwordtxt.setValue("");
		
	}

	@Override
	public void setUserNameValue(String value) {
		if(value != null)
			usernametxt.setValue(value);
		else
			usernametxt.setValue("");
	}

	@Override
	public void setFocusUserNameTxt(boolean focus) {
		if(focus){
			usernametxt.focusInItem();
		}else{
			//TODO
		}
	}

	@Override
	public void showCloseDialog(boolean show) {
		/*if (dialogbox != null){
			if (closedialogbtn != null) 				
				closedialogbtn.setVisible(show);						
		}		*/
	}

	@Override
	public void showDialogBox(boolean show) {
		if(dialogbox == null)
			createPopup();
			
		if(show){
			//clear dialog
			Canvas[] members = dialogbox.getMembers();
			if(members != null)
				for(Canvas c: members)
					dialogbox.removeMember(c);			
			
			dialogbox.addMember(widgetcontainer);//asWidget());
			if(dialogbox.isDrawn()){
				if(!dialogbox.isVisible()){
					linksform.setVisible(false);		    	
					dialogbox.setVisible(show);				
				}
			}else{
				dialogbox.show();
			}
		}else{
			if(dialogbox.isVisible()){
				onDialogClose();
				dialogbox.destroy();//hide();				
			}
		}
	}

	@Override
	public void addPasswordStyle(String stylename) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addUserNameStyle(String stylename) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removePasswordStyle(String stylename) {
		
	}

	@Override
	public void removeUserNameStyle(String stylename) {
		// TODO Auto-generated method stub
		
	}	
	
	@Override
	public void reset() {
		setLoginstatuslbl(null, false);
		setUserNameValue("");
		setPasswordValue("");
		setFocusUserNameTxt(true);
		setRememberMeValue(false);
		removeUserNameStyle(MajiCSS.login_txt_error);
		removePasswordStyle(MajiCSS.login_txt_error);
		loginform.clearErrors(true);		
	}
	
	private void onDialogClose(){
		header.setVisible(true);
    	linksform.setVisible(true);
    	dialogbox.removeMember(widgetcontainer);    		
	}
}
