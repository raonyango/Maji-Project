package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.ibatis.beans.City;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class CityRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String CITY_ID = "city_id";
	public static final String CITY_NAME = "city_name";
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	
	public CityRecord() {
	}

	public CityRecord(City city) {
		
		setCityID(city.getCityId());
		setCityName(city.getCityName());		
		setCreatedOn(city.getCreatedOn());
		setCreatedBy(city.getCreatedBy());
	}

	public void setCityID(int attribute) {
		setAttribute(CITY_ID ,attribute);
	}

	public int getCityID() {
		return getAttributeAsInt(CITY_ID);
	}
	
	public String getCityName() {
		return getAttributeAsString(CITY_NAME);
	}
	
	public void setCityName(String attribute) {
		setAttribute(CITY_NAME, attribute);
	}

	
	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY ,attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}

}
