package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.ibatis.beans.HouseUnit;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class BlockRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String BLOCK_ID = "block_id";
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	public static final String BLOCK_NUMBER =  "block_number";
	
	public BlockRecord() {
	}

	public BlockRecord(HouseUnit unit) {
		
		setBlockId(unit.getBlockId());
		setCreatedOn(unit.getCreatedOn());
		setCreatedBy(unit.getCreatedBy());
		setBlockNumber(unit.getBlockNumber());
		//this.setCustomStyle(MajiCSS.grid_alternating);
	}

	public void setBlockId(int id) {
		setAttribute(BLOCK_ID, id);
	}

	public int getBlockId() {
		return getAttributeAsInt(BLOCK_ID);
	}
	
	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY ,attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}

	public void setBlockNumber(String number) {
		setAttribute(BLOCK_NUMBER, number);
	}

	public String getBlockNumber() {
		return getAttributeAsString(BLOCK_NUMBER);
	}
}
