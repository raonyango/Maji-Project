package com.maji.client.view.model;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.fields.DataSourceIntegerField;
import com.smartgwt.client.data.fields.DataSourceTextField;
public class CityDataSource extends DataSource {

	//private MajiGinjector injector = GWT.create(MajiGinjector.class);
    //private AuthenticationServiceAsync rpcservice = injector.getAuthenticationService();
   /* private MajiServiceAsync rpcservice = injector.getMajiService();
    private ClientUtils clientutils = injector.getClientUtils();
    private MajiStrings constants = injector.getMajiConstants();
    private boolean initialized = false;
     */
	public static CityDataSource getInstance() {
		return new CityDataSource();
	}

	public CityDataSource() {
		super();
		setClientOnly(true);
		DataSourceIntegerField idfld = new DataSourceIntegerField("city_id", "City Id");
		idfld.setPrimaryKey(true);
		DataSourceTextField citynamefld = new DataSourceTextField("city_name", "City Name");
		citynamefld.setCanEdit(false);
		setFields(idfld, citynamefld);
	}
	
	/*   @Override
	   protected Object transformRequest(DSRequest request) {
		  request.setWillHandleError(true);
	      if (request.getOperationType() != null) {
	         switch (request.getOperationType()) {
	             case ADD:
	                 //executeAdd(lstRec, true);
	                 break;
	             case FETCH:
	                 executeFetch();
	                 break;
	             case REMOVE:
	                 //executeRemove(lstRec);
	                 break;
	             case UPDATE:
	                 //executeAdd(lstRec, false);
	                 break;

	             default:
	                 break;
	         }
	     }
	     return super.transformRequest(request);
	   }*/
			    
	   

}
