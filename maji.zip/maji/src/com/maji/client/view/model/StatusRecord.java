package com.maji.client.view.model;

import com.maji.shared.ibatis.beans.WaterBillStatus;
import com.smartgwt.client.data.Record;

public class StatusRecord extends Record {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String STATUS_ID = "statusId";
	public static final String STATUS_NAME = "statusName";	
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	
	public StatusRecord() {
	}

	public StatusRecord(WaterBillStatus status) {
		
		setStatusID(status.getStatusId());
		setStatusName(status.getStatusName());
				
		//this.setCustomStyle(MajiCSS.grid_alternating);
	}

	public void setStatusID(int attribute) {
		setAttribute(STATUS_ID ,attribute);
	}

	public int getStatusID() {
		return getAttributeAsInt(STATUS_ID);
	}
	
	public void setStatusName(String name) {
		setAttribute(STATUS_NAME, name);
	}

	public String getStatusName() {
		return getAttributeAsString(STATUS_NAME);
	}
		
}
