package com.maji.client.view.model;

import java.util.Date;

import com.maji.shared.ibatis.beans.WaterBill;
import com.smartgwt.client.widgets.grid.ListGridRecord;

public class BillRecord extends ListGridRecord {

	public static final String ICON_DISPLAY_NAME = "#";
	public static final String ICON = "icon";
	public static final String BILL_ID = "bill_id";
	public static final String UNIT_NUMBER = "unit_number";
	public static final String BILL_NUMBER = "bill_number";
	public static final String MONTH = "month";
	public static final String YEAR = "year";
	public static final String CREATED_ON = "created_on";
	public static final String CREATED_BY = "created_by";
	public static final String UNITS = "units_consumed";
	public static final String CHARGE_ID = "charge_id";
	public static final String HOUSE_UNIT_ID = "house_unit_id";
	public static final String METERREADING = "meter_reading";
	public static final String STATUSNAME = "status_name";
	public static final String CHARGE_AMOUNT = "amount_per_unit";
	public static final String STATUS_ID = "status_id";
	public static final String DUE_DATE = "due_date";
	public static final String BILLING_DATE = "billing_date";
	
	public BillRecord() {
	}

	public BillRecord(WaterBill unit) {

		setBillID(unit.getBillId());
		setBillNumber(unit.getBillNumber());
		setMonth(unit.getMonth());
		setYear(unit.getYear());
		setUnitsConsumed(unit.getUnitsConsumed()); //.doubleValue
		setCreatedOn(unit.getCreatedOn());
		setCreatedBy(unit.getCreatedBy());
		setChargeId(unit.getChargeId());
		setHouseUnitId(unit.getHouseUnitId());
		setDueDate(unit.getDueDate());
		setStatusId(unit.getStatusId());
		setUnitNumber(unit.getUnitNumber());
		setChargeAmount(unit.getChargeAmount());
		setStatusName(unit.getStatusName());
		setMeterReading(unit.getMeterReading()); //.doubleValue
		setBillingDate(unit.getBillingDate());
		
		// this.setCustomStyle(MajiCSS.grid_alternating);
	}

	public void setDueDate(Date attribute) {
		setAttribute(DUE_DATE, attribute);
	}

	public Date getDueDate() {
		return getAttributeAsDate(DUE_DATE);
	}

	public void setBillingDate(Date attribute) {
		setAttribute(BILLING_DATE, attribute);
	}

	public Date getBillingDate() {
		return getAttributeAsDate(BILLING_DATE);
	}
	
	public void setStatusId(int attribute) {
		setAttribute(STATUS_ID, attribute);
	}

	public int getStatusId() {
		return getAttributeAsInt(STATUS_ID);
	}

	public void setChargeAmount(double attribute) {
		setAttribute(CHARGE_AMOUNT, attribute);
	}

	public double getChargeAmount() {
		return getAttributeAsDouble(CHARGE_AMOUNT);
	}

	public void setStatusName(String attribute) {
		setAttribute(STATUSNAME, attribute);
	}

	public String getStatusName() {
		return getAttributeAsString(STATUSNAME);
	}

	public void setMeterReading(double attribute) {
		setAttribute(METERREADING, attribute);
	}

	public double getMeterReading() {
		return getAttributeAsDouble(METERREADING);
	}

	public void setBillID(int attribute) {
		setAttribute(BILL_ID, attribute);
	}

	public int getBillID() {
		return getAttributeAsInt(BILL_ID);
	}

	public void setBillNumber(String attribute) {
		setAttribute(BILL_NUMBER, attribute);
	}

	public String getBillNumber() {
		return getAttributeAsString(BILL_NUMBER);
	}

	public void setMonth(String attribute) {
		setAttribute(MONTH, attribute);
	}

	public String getMonth() {
		return getAttributeAsString(MONTH);
	}

	public void setYear(int attribute) {
		setAttribute(YEAR, attribute);
	}

	public int getYear() {
		return getAttributeAsInt(YEAR);
	}

	public double getUnitsConsumed() {
		return getAttributeAsDouble(UNITS);
	}

	public void setUnitsConsumed(double attribute) {
		setAttribute(UNITS, attribute);
	}

	public Date getCreatedOn() {
		return getAttributeAsDate(CREATED_ON);
	}

	public void setCreatedOn(Date attribute) {
		setAttribute(CREATED_ON, attribute);
	}

	public void setCreatedBy(int attribute) {
		setAttribute(CREATED_BY, attribute);
	}

	public int getCreatedBy() {
		return getAttributeAsInt(CREATED_BY);
	}

	public void setChargeId(int attribute) {
		setAttribute(CHARGE_ID, attribute);
	}

	public int getChargeId() {
		return getAttributeAsInt(CHARGE_ID);
	}

	public String getUnitNumber() {
		return getAttributeAsString(UNIT_NUMBER);
	}

	public void setUnitNumber(String attribute) {
		setAttribute(UNIT_NUMBER, attribute);
	}

	public void setHouseUnitId(int attribute) {
		setAttribute(HOUSE_UNIT_ID, attribute);
	}

	public int getHouseUnitId() {
		return getAttributeAsInt(HOUSE_UNIT_ID);
	}
}
