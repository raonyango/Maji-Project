package com.maji.client.view.model;

import com.google.gwt.core.client.GWT;
import com.maji.client.MajiServiceAsync;
import com.maji.client.gin.MajiGinjector;
import com.maji.client.utils.ClientUtils;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.fields.DataSourceIntegerField;
import com.smartgwt.client.data.fields.DataSourceTextField;
public class StatusDataSource extends DataSource {

	private MajiGinjector injector = GWT.create(MajiGinjector.class);
    //private AuthenticationServiceAsync rpcservice = injector.getAuthenticationService();
    private MajiServiceAsync rpcservice = injector.getMajiService();
    private ClientUtils clientutils = injector.getClientUtils();
    private MajiStrings constants = injector.getMajiConstants();
    private boolean initialized = false;
     
	public static StatusDataSource getInstance() {
		return new StatusDataSource();
	}

	public StatusDataSource() {
		super();
		setClientOnly(true);
		DataSourceIntegerField idfld = new DataSourceIntegerField("statusId", "ID");
		idfld.setPrimaryKey(true);
		DataSourceTextField statusnamefld = new DataSourceTextField("statusName", "Status");
		statusnamefld.setCanEdit(false);
		
		setFields(idfld, statusnamefld);
	}
	
	/*   @Override
	   protected Object transformRequest(DSRequest request) {
		  request.setWillHandleError(true);
	      if (request.getOperationType() != null) {
	         switch (request.getOperationType()) {
	             case ADD:
	                 //executeAdd(lstRec, true);
	                 break;
	             case FETCH:
	                 executeFetch();
	                 break;
	             case REMOVE:
	                 //executeRemove(lstRec);
	                 break;
	             case UPDATE:
	                 //executeAdd(lstRec, false);
	                 break;

	             default:
	                 break;
	         }
	     }
	     return super.transformRequest(request);
	   }*/
			    
	   

}
