package com.maji.client.view.model;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.fields.DataSourceIntegerField;
import com.smartgwt.client.data.fields.DataSourceTextField;
public class ChargeDataSource extends DataSource {

	//private AuthenticationServiceAsync rpcservice = injector.getAuthenticationService();
   
	public static ChargeDataSource getInstance() {
		return new ChargeDataSource();
	}

	public ChargeDataSource() {
		super();
		setClientOnly(true);
		DataSourceIntegerField idfld = new DataSourceIntegerField("charge_id", "ID");
		idfld.setPrimaryKey(true);
		DataSourceTextField amntfld = new DataSourceTextField("amount_per_unit", "Amount Per Unit");
		amntfld.setCanEdit(false);
		
		setFields(idfld, amntfld);
	}
	
	/*   @Override
	   protected Object transformRequest(DSRequest request) {
		  request.setWillHandleError(true);
	      if (request.getOperationType() != null) {
	         switch (request.getOperationType()) {
	             case ADD:
	                 //executeAdd(lstRec, true);
	                 break;
	             case FETCH:
	                 executeFetch();
	                 break;
	             case REMOVE:
	                 //executeRemove(lstRec);
	                 break;
	             case UPDATE:
	                 //executeAdd(lstRec, false);
	                 break;

	             default:
	                 break;
	         }
	     }
	     return super.transformRequest(request);
	   }*/
			    
	   

}
