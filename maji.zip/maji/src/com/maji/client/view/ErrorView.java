package com.maji.client.view;

import com.google.gwt.user.client.Window;
import com.google.inject.Inject;
import com.maji.client.presenter.ErrorPresenter;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.HTMLFlow;
import com.smartgwt.client.widgets.layout.Layout;
import com.smartgwt.client.widgets.layout.VLayout;

public class ErrorView extends Canvas
		implements ErrorPresenter.IErrorViewDisplay {

	private static final String DEFAULT_MARGIN = "0px";
	private VLayout maincontainer;
	private HTMLFlow infolbl;
	private String errorstr = "";
	private String infostr = "";
	
	@Inject
	public ErrorView(MajiStrings constants) {

		//errorstr = constants.error_page_info();
		//infostr = constants.pending_implementation_info();

		Window.enableScrolling(false);
		Window.setMargin(DEFAULT_MARGIN);
		
		maincontainer = new VLayout();
		maincontainer.setLayoutAlign(Alignment.CENTER);
		maincontainer.setLayoutAlign(VerticalAlignment.CENTER);		
		maincontainer.setStyleName(MajiCSS.profile_container);
		maincontainer.setWidth(80 + "%"); // (1090);
		maincontainer.setHeight(60 + "%");
		
		infolbl = new HTMLFlow();
		infolbl.setLayoutAlign(Alignment.CENTER);
		infolbl.setLayoutAlign(VerticalAlignment.CENTER);
		infolbl.setWidth("202px");		
		infolbl.setHeight(Float.valueOf(maincontainer.getOffsetHeight() * 0.85f).intValue());
			
		maincontainer.addMember(infolbl);
		
	}
		
	@Override
	public void setContents(boolean iserror) {		
		if(iserror){
			infolbl.setContents(errorstr);
			if(infolbl.getStyleName().contains(MajiCSS.errorpage_info_lbl))
				infolbl.removeStyleName(MajiCSS.errorpage_info_lbl);
			infolbl.addStyleName(MajiCSS.errorpage_error_lbl);
		}else{
			infolbl.setContents(infostr);
			if(infolbl.getStyleName().contains(MajiCSS.errorpage_error_lbl))
				infolbl.removeStyleName(MajiCSS.errorpage_error_lbl);
			infolbl.addStyleName(MajiCSS.errorpage_info_lbl);
		}		
	}	

	@Override
	public Layout asWidget() {
		return maincontainer;
	}
}
