package com.maji.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;

/**
 * The async counterpart of <code>AuthService</code>.
 */
public interface AuthenticationServiceAsync {
	void authenticateUser(UserLoginData ulogindata,
			AsyncCallback<StandardServerResponse> callback);

	void checkSession(UserLoginData logindata,
			AsyncCallback<StandardServerResponse> callback);

	void logoutUser(String username,
			AsyncCallback<StandardServerResponse> callback);

	void validateURL(String url, AsyncCallback<StandardServerResponse> callback);
	
/*	void resetPassword(ForgotPasswordData data,
			AsyncCallback<StandardServerResponse> callback);
	void validateCaptcha(
			String captcha, AsyncCallback<StandardServerResponse> callback);
	void checkUsernameAvailability(String username, AsyncCallback<StandardServerResponse> callback);*/
}
