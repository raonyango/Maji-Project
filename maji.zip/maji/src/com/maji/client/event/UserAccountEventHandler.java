package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface UserAccountEventHandler extends EventHandler{
    
    public void onShowAccount(UserAccountEvent event);

}
