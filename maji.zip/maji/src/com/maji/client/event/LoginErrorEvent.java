package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class LoginErrorEvent extends GwtEvent<LoginErrorEventHandler> {
    
    public static Type<LoginErrorEventHandler> TYPE = new Type<LoginErrorEventHandler>();
    
    public String getErrorMessage() {
        return errormessage;
    }

    String errormessage;
    
    public LoginErrorEvent(String errormessage) {
       this.errormessage = errormessage;
    }
    
    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<LoginErrorEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(LoginErrorEventHandler handler) {
        handler.onNewError(this);
    }
    
}
