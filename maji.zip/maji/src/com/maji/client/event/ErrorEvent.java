package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;

public class ErrorEvent extends GwtEvent<ErrorEventHandler> {
    
    public static Type<ErrorEventHandler> TYPE = new Type<ErrorEventHandler>();
    
    public String getMessage() {
        return message;
    }

    public String getTitle() {
        return title;
    }
    
    public int getDuration() {
        return duration;
    }

    String message, title;
    int duration;
    
    public ErrorEvent(String title, String message) {
        this(title, message, 0);
    }
    
    public ErrorEvent(String title, String message, int duration) {
        this.message = message;
        this.title = title;
        this.duration = duration;
    }

    @Override
    public com.google.gwt.event.shared.GwtEvent.Type<ErrorEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(ErrorEventHandler handler) {
        handler.onNewError(this);
    }
    
}
