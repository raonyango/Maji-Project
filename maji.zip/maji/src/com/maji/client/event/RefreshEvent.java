package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class RefreshEvent extends GwtEvent<RefreshEventHandler> {
    
    public static Type<RefreshEventHandler> TYPE = new Type<RefreshEventHandler>();
    
    UserLoginData logindata;
    
	public UserLoginData getLogindata() {
		return logindata;
	}

	public void setLogindata(UserLoginData logindata) {
		this.logindata = logindata;
	}

	public RefreshEvent(UserLoginData logindata) {
        this.logindata = logindata;
    } 

    @Override
    public GwtEvent.Type<RefreshEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(RefreshEventHandler handler) {
        handler.onRefreshApplication(this);
    }
    
}
