package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.maji.shared.beans.UserLoginData;

public class UserAccountEvent extends GwtEvent<UserAccountEventHandler>{

    public static Type<UserAccountEventHandler> TYPE = new Type<UserAccountEventHandler>();
    private UserLoginData userLoginData;
    
    public UserAccountEvent(UserLoginData userLoginData) {
        this.userLoginData = userLoginData;
    }

    public UserLoginData getUser() {
        return userLoginData;
    }
    
    @Override
    public Type<UserAccountEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(UserAccountEventHandler handler) {
        handler.onShowAccount(this);
    }

}
