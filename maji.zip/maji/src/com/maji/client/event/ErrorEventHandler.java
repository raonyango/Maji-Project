package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ErrorEventHandler extends EventHandler{
    public void onNewError(ErrorEvent event);
}
