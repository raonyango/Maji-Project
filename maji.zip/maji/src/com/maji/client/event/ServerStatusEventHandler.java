package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface ServerStatusEventHandler extends EventHandler{
    public void onServerStatusChange(ServerStatusEvent event);
}
