package com.maji.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface SessionExpireEventHandler extends EventHandler{

    public void onSessionExpireEvent(SessionExpireEvent event);
}
