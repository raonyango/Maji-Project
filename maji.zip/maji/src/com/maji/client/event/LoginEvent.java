package com.maji.client.event;

import com.google.gwt.event.shared.GwtEvent;
import com.google.gwt.user.client.Command;

public class LoginEvent extends GwtEvent<LoginEventHandler>{

    public static Type<LoginEventHandler> TYPE = new Type<LoginEventHandler>();
    private Command command;
    
    public Command getCommand() {
		return command;
	}

	public void setCommand(Command command) {
		this.command = command;
	}

	public LoginEvent(Command command) {
       this.command = command;
    }

    @Override
    public Type<LoginEventHandler> getAssociatedType() {
        return TYPE;
    }

    @Override
    protected void dispatch(LoginEventHandler handler) {
        handler.onLogin(this);
    }

}
