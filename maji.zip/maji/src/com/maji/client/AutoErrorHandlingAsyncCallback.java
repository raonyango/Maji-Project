package com.maji.client;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.StatusCodeException;
import com.maji.client.event.ErrorEvent;
import com.maji.client.event.LoginEvent;
import com.maji.shared.properties.MajiStrings;

/**
 * An implementation of  {@link AsyncCallback} that handles cases where the requested resource is 
 * restricted by security.
 */
public abstract class AutoErrorHandlingAsyncCallback<T> implements AsyncCallback<T> {
	
	private Command cmd;	
	private EventBus eventbus;
	private MajiStrings constants;
	
	// default constructor
	public AutoErrorHandlingAsyncCallback(EventBus eventbus) {
		super();
		this.eventbus = eventbus;
	}
	
	/**
	 * Constructor to use when a successful login should resubmit the requested server call, i.e. the <code>Command</code>.
	 */
	public AutoErrorHandlingAsyncCallback(EventBus eventbus, Command cmd, MajiStrings constants) {
		super();
		this.eventbus = eventbus;
		this.cmd = cmd;
		this.constants = constants;
	}
	
	public void onFailure(Throwable throwable) {
		if (throwable instanceof StatusCodeException && ((StatusCodeException) throwable).getStatusCode() == 401) {		
			//user has an invalid session
			eventbus.fireEvent(new LoginEvent(cmd));
		} else if (throwable instanceof StatusCodeException && ((StatusCodeException) throwable).getStatusCode() == 403) {	
			//access denied to request
			Log.info("AutoErrorHandlingAsyncCallback..................." + throwable.getMessage());
			eventbus.fireEvent(new ErrorEvent(constants.access_denied(), constants.no_priviledge_for_operation()));
		}else {
			//server error
			eventbus.fireEvent(new ErrorEvent(constants.error(), constants.server_unavailable() + ":" + ((StatusCodeException) throwable).getStatusCode()));			
		}
		return;
	}
}