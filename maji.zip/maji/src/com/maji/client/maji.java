package com.maji.client;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.DeferredCommand;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.ui.RootPanel;
import com.maji.client.gin.MajiGinjector;
import com.maji.client.utils.AppController;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
@SuppressWarnings("deprecation")
public class maji implements EntryPoint {

	private final MajiServiceAsync majiservice = GWT
			.create(MajiService.class);
	private final MajiGinjector minjector = GWT
			.create(MajiGinjector.class);

	public void onModuleLoad() {
		//Defer initialization to catch unexpected exceptions.
	    Log.setUncaughtExceptionHandler();
		DeferredCommand.add(new Command() {
			
			@Override
			public void execute() {
				//GXT.setDefaultTheme(Theme.BLUE, true);

				Element loading = DOM.getElementById("loading");
				DOM.removeChild(RootPanel.getBodyElement(), loading);
				
				RootPanel rootpanel = RootPanel.get();

				AppController appcontroller = new AppController(minjector,
						majiservice);
				appcontroller.go(rootpanel);
			}
		});
		
	}
 
	  public static final String LOCAL_HOST = "http://127.0.0.1:8888/";
	  // public static final String REMOTE_HOST = "http://greencity.com/";
	  public static final String REMOTE_HOST = "http://127.0.0.1:8888/";
	  
	public static String getRelativeURL(String url) {
	    String realModuleBase;

	    if (GWT.isScript()) {
	      String moduleBase = GWT.getModuleBaseURL();

	      Log.debug("GWT.isScript() is true - ModuleBaseURL: " + moduleBase);

	      // Use for deployment to PRODUCTION server
	      realModuleBase = REMOTE_HOST;

	      // Use to test compiled browser locally
	      if (moduleBase.indexOf("localhost") != -1) {
	          realModuleBase = LOCAL_HOST;
	      }
	    } else {
	      // This is the URL for GWT Hosted mode
	      realModuleBase = LOCAL_HOST;
	      
	      Log.debug("GWT.isScript() is false - realModuleBase: " + realModuleBase);
	    }

	    return realModuleBase + url;
	}
}
