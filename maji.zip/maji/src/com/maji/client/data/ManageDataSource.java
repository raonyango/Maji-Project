package com.maji.client.data;

import com.maji.client.place.PlaceTokens;

public class ManageDataSource extends NavigationPaneSectionDataSource {

	public static final String DEFAULT_RECORD_NAME = PlaceTokens.manage;

	private static final String DATA_SOURCE = "ManageDs";
	private static final String URL_PREFIX = "datasource/data/ManageDs";
	private static final String URL_SUFFIX = ".xml";

	private static ManageDataSource instance;
	//private DataSourceField f;
	
	public static ManageDataSource getInstance() {
		if (instance == null) {
			instance = new ManageDataSource(DATA_SOURCE);
		}

		return instance;
	}

	public ManageDataSource(String id) {
		super(id);
		setDataURL(URL_PREFIX, URL_SUFFIX);
		/*
		f= new DataSourceField("Person", FieldType.TEXT);
		addField(f);*/
	}
}
