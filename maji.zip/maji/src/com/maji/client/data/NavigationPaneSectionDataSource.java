package com.maji.client.data;

import com.google.gwt.i18n.client.LocaleInfo;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.DataSourceField;
import com.smartgwt.client.types.DSDataFormat;
import com.smartgwt.client.types.FieldType;

public abstract class NavigationPaneSectionDataSource extends DataSource {

	public static final String ICON = "icon";
	public static final String ICON_DISPLAY_NAME = "Icon";
	public static final String NAME = "name";
	public static final String NAME_DISPLAY_NAME = "Name";
	public static final String DISPLAY_NAME = "displayName";
	public static final String DISPLAY_NAME_DISPLAY_NAME = "Display Name";

	private static final String RECORD_XPATH = "/list/record";

	public NavigationPaneSectionDataSource(String id) {
		setID(id);
		setDataFormat(DSDataFormat.XML);
		setRecordXPath(RECORD_XPATH);
		DataSourceField iconField = new DataSourceField(ICON, FieldType.TEXT,
				ICON_DISPLAY_NAME);
		DataSourceField nameField = new DataSourceField(NAME, FieldType.TEXT,
				NAME_DISPLAY_NAME);
		DataSourceField displayNameField = new DataSourceField(DISPLAY_NAME,
				FieldType.TEXT, DISPLAY_NAME_DISPLAY_NAME);
		setFields(iconField, nameField, displayNameField);
	}

	public void setDataURL(String urlPrefix, String urlSuffix) {
		String url = urlPrefix;
		LocaleInfo localeInfo = LocaleInfo.getCurrentLocale();
		String localeName = localeInfo.getLocaleName();

		if (localeName.length() > 0) {
			url = url + "_" + localeName;
		}

		url = url + urlSuffix;

		//Log.debug("setDataURL: " + url);

		setDataURL(url);
	}
}
