package com.maji.client.utils;

import com.smartgwt.client.widgets.form.validator.RegExpValidator;

public class SmartValidators {

	private final String url_regex = "^((ftp|http|https)://[\\w@.\\-\\_]+\\.[a-zA-Z]{2,}(:\\d{1,5})?(/[\\w#!:.?+=&%@!\\_\\-/]+)*){1}$";
	private final String email_regex = "^([a-zA-Z0-9_.\\-+])+@(([a-zA-Z0-9\\-])+\\.)+[a-zA-Z0-9]{2,4}$";
	private final String phone_regex = "^[+0-9]$"; //"^(\\+44\\s?7\\d{3}|\\(?07\\d{3}\\)?)\\s?\\d{3}\\s?\\d{3}$";
	private final String color_regex = "^#?(([a-fA-F0-9]){3}){1,2}$";
	
	public String getPhoneregex() {
		return phone_regex;
	}

	public String getUrlregex() {
		return url_regex;
	}

	public String getColorregex() {
		return color_regex;
	}
	
	public String getEmailregex() {
		return email_regex;
	}
	
	public RegExpValidator getURLRegValidator(){
		RegExpValidator validator = new RegExpValidator();
	    validator.setExpression(url_regex);
	    
	    return validator;
	}

}
