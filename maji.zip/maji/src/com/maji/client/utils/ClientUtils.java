/**
 * @author Rosemary A. Onyango
 *
 */
package com.maji.client.utils;

import java.util.Random;
import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.AttachEvent;
import com.google.gwt.event.logical.shared.AttachEvent.Handler;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.gwt.regexp.shared.RegExp;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.inject.Inject;
import com.maji.client.place.PlaceTokens;
import com.maji.shared.properties.MajiCSS;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;

public class ClientUtils {
	int pos=0;	
	boolean isLast=false;
	boolean endreached = false;		
	private MajiStrings constants;
	private RegExp urlValidator;
	private RegExp urlPlusTldValidator;
	
	@Inject
	public ClientUtils(MajiStrings constants){	
		this.constants = constants;
	}	


	public boolean hasWord(String word,String input){

		Vector<String> words=new Vector<String>();
		String sWords[]=word.trim().split(" ");
		for(int i=0;i<sWords.length;i++){
			if(sWords[i].trim().length()>0){
				words.add(sWords[i].trim().toLowerCase());
			}
		}
		return words.contains(input.trim().toLowerCase());
	}
	
	public Anchor getHyperLink(boolean asHTML, String linktext, String href) {
	    Anchor link = new Anchor(linktext, asHTML, href, linktext.equals(null) ? null : "_blank");
	    link.ensureDebugId("Hyperlink-" + href);
	   	link.setWordWrap(true);
	   	
	    return link;
	}
	
	public int getRandomInteger(int Start, int End){
		try{
		    if ( Start > End ) {
		      //throw new IllegalArgumentException("Start cannot exceed End.");
		    	return Start;
		    }
		    //get the range, casting to long to avoid overflow problems
		    long range = (long)End - (long)Start + 1;
		    // compute a fraction of the range, 0 <= frac < range
		    Random aRandom = new Random();
		    long fraction = (long)(range * aRandom.nextDouble());
		    
		    return (int)(fraction + Start);    
		}catch(Exception e){
			Window.alert("err getRandomInteger::" + e.getMessage());
			return Start;
		}
	  }

		
	public void showErrorMessage(String title, String errormessage){		
		final DialogBox dbox = new DialogBox(false, true);
		
		Button closebtn = new Button(constants.ok_button_txt(), new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				dbox.hide(true);				
			}
		});
		closebtn.setStylePrimaryName("dialogclosebtn");
		
	    HTML errmsg = new HTML("<center>" + errormessage + "</center>", true);
	    errmsg.setWidth("100%");
	    VerticalPanel dialogContents = new VerticalPanel();
	    dialogContents.setSpacing(8);
	    dialogContents.add(errmsg);
	    dialogContents.setStylePrimaryName("dialogcontents");
	    dialogContents.setCellHorizontalAlignment(
	            errmsg, HasHorizontalAlignment.ALIGN_CENTER);
	    
	    dialogContents.add(closebtn);
	    if(LocaleInfo.getCurrentLocale().isRTL()){
	        dialogContents.setCellHorizontalAlignment(
	            closebtn, HasHorizontalAlignment.ALIGN_LEFT);

	    }else{
	        dialogContents.setCellHorizontalAlignment(
	            closebtn, HasHorizontalAlignment.ALIGN_RIGHT);
	    }
	    
	    
	    dbox.setGlassEnabled(true);
	    dbox.setAnimationEnabled(true);
	    dbox.setText(title);
		dbox.setWidget(dialogContents);		
		dbox.addAttachHandler(new Handler() {
			
			@Override
			public void onAttachOrDetach(AttachEvent event) {
				if(event.isAttached()){					
					dbox.center();
					dbox.setPopupPosition(dbox.getAbsoluteLeft() + 20, dbox.getAbsoluteTop() - 70);						
				}
			}
		});
		
		if(dbox.getWidget() != null)
			dbox.show();
	}
	
	public void showMessage(String title, String message, BooleanCallback callback){	
		showSmartGwtMessage(title, message, callback);
	}
	
	public void showSmartGwtMessage(String title, String message, BooleanCallback callback){	
		SC.say(title, message, callback);
	}
	
	public void showGWTMessage(String title, String message){		
		final DialogBox dbox = new DialogBox(false, true);
		
		Button closebtn = new Button(constants.ok_button_txt(), new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				dbox.hide(true);				
			}
		});
		closebtn.setStylePrimaryName("dialogclosebtn");
		
	    HTML errmsg = new HTML("<center>" + message + "</center>", true);
	    errmsg.setWidth("100%");
	    VerticalPanel dialogContents = new VerticalPanel();
	    dialogContents.setSpacing(8);
	    dialogContents.add(errmsg);
	    dialogContents.setStylePrimaryName("dialogcontents");
	    dialogContents.setCellHorizontalAlignment(
	            errmsg, HasHorizontalAlignment.ALIGN_CENTER);
	    
	    dialogContents.add(closebtn);
	    if(LocaleInfo.getCurrentLocale().isRTL()){
	        dialogContents.setCellHorizontalAlignment(
	            closebtn, HasHorizontalAlignment.ALIGN_LEFT);

	    }else{
	        dialogContents.setCellHorizontalAlignment(
	            closebtn, HasHorizontalAlignment.ALIGN_RIGHT);
	    }
	    
	    
	    dbox.setGlassEnabled(true);
	    dbox.setAnimationEnabled(true);
	    dbox.setText(title);
		dbox.setWidget(dialogContents);		
		dbox.addAttachHandler(new Handler() {
			
			@Override
			public void onAttachOrDetach(AttachEvent event) {
				if(event.isAttached()){					
					dbox.center();
					dbox.setPopupPosition(dbox.getAbsoluteLeft() + 20, dbox.getAbsoluteTop() - 70);						
				}
			}
		});
		
		if(dbox.getWidget() != null)
			dbox.show();
	}
	
	public boolean isValidUrl(String url, boolean topLevelDomainRequired) {
	    if (urlValidator == null || urlPlusTldValidator == null) {
	        urlValidator = RegExp.compile("^((ftp|http|https)://[\\w@.\\-\\_]+(:\\d{1,5})?(/[\\w#!:.?+=&%@!\\_\\-/]+)*){1}$");
	        urlPlusTldValidator = RegExp.compile("^((ftp|http|https)://[\\w@.\\-\\_]+\\.[a-zA-Z]{2,}(:\\d{1,5})?(/[\\w#!:.?+=&%@!\\_\\-/]+)*){1}$");
	    }
	    return (topLevelDomainRequired ? urlPlusTldValidator : urlValidator).exec(url) != null;
	}
	
	public String getPlaceLabel(String place) {
		String title = place;
		if (place != null){
			if (place.trim().length() != 0) {
		        if ( place.equals(PlaceTokens.main) || place.equals(PlaceTokens.home)) {		
		        	title = ""; //constants.overview_tab();						
				}else if (place.equals(PlaceTokens.person)) {		
					title = constants.person_menu();						
				}else if (place.equals(PlaceTokens.bill)) {		
					title = constants.bill_tab();						
				}else if (place.equals(PlaceTokens.cancel)) {		
					title = constants.cancel_tab();						
				}else if (place.equals(PlaceTokens.help)) {		
					title = constants.help_tab();					
				}else if (place.equals(PlaceTokens.charge)) {		
					title = constants.charges_tab();						
				}else if (place.equals(PlaceTokens.unit)) {		
					title = constants.units_tab();		
				}else if (place.equals(PlaceTokens.fee)) {		
					title = constants.fees_tab();	
				}
		    }else{
		    	title = ""; //constants.overview_tab();
		    }
		}else{
			title = ""; //constants.overview_tab();
		}
		
		return title;
	}
		 
    public int getIntValue(float f) {
		Float fl = new Float(f);
		return fl.intValue();
	}
    	
	public void initPasswordValidationScripts() {
		initPasswordValidationScripts(MajiCSS.password_checker, MajiCSS.password_checker_result_id, MajiCSS.password_short, 
				MajiCSS.password_bad, MajiCSS.password_good, MajiCSS.password_strong, MajiCSS.password_checker_basestyle, 
				MajiCSS.password_checker_username_element, constants.short_password_info(), constants.bad_password_info(), 
				constants.good_password_info(), constants.strong_password_info(), constants.same_password_info());	
	}
//------------------------------------------------------------------------------------------------------------------------------------
//NATIVE FUNCTIONS
//------------------------------------------------------------------------------------------------------------------------------------

	private native void initPasswordValidationScripts(String checkerclass,
			String checkerresultid, String shortpass, String badpass,
			String goodpass, String strongpass, String basestyle,
			String useridelement, String shortpassinfo, String badpassinfo,
			String goodpassinfo, String strongpassinfo, String samepassinfo)/*-{
		$wnd.initPasswordCheckerSmartGwt(checkerclass, checkerresultid, shortpass, badpass, goodpass, strongpass, basestyle, useridelement, 
		shortpassinfo, badpassinfo, goodpassinfo, strongpassinfo, samepassinfo);
	}-*/;
	
}
