package com.maji.client.utils;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.Presenter;
import net.customware.gwt.presenter.client.place.PlaceManager;

import com.google.gwt.user.client.ui.HasWidgets;
import com.maji.client.MajiServiceAsync;
import com.maji.client.event.ErrorEvent;
import com.maji.client.event.ErrorEventHandler;
import com.maji.client.gin.MajiGinjector;
import com.maji.client.presenter.HomePresenter;

/**
 * @author Rosemary A. Onyango For history management and view transition logic
 */
public class AppController{
	private EventBus eventbus = null;
	private MajiGinjector binjector;	
	private ClientUtils clientutils;
	
	/* @Inject */
	public AppController(MajiGinjector minjector,
		MajiServiceAsync rpcservice) {
		this.binjector = minjector;
		//this.constants = binjector.getBrainupConstants();
		this.eventbus = minjector.getEventBus();
		this.clientutils = minjector.getClientUtils();
	}	

	public void go(final HasWidgets container) {
		bind();
		Presenter presenter = binjector.getHomePresenter();		
		//Presenter presenter = binjector.getProfilePresenter();
		if (presenter != null){ 
			//container.add(((HomePresenter) presenter).getDisplay().asWidget()); //if not using smartgwt
			((HomePresenter) presenter).getDisplay().asWidget().draw(); //only when using smartgwt. Else use commented line above
			presenter.bind();
		}
		
		// Load PlaceManager so it can start listening
		PlaceManager bplacemanager = binjector.getPlaceManager();
		bplacemanager.fireCurrentPlace();			
	}

	public void bind() {
		// -----------------------------------------------------------------------------------
		// EVENTBUS HANDLERS
		// -----------------------------------------------------------------------------------
		eventbus.addHandler(ErrorEvent.TYPE, new ErrorEventHandler() {

			@Override
			public void onNewError(ErrorEvent event) {
				clientutils.showErrorMessage(event.getTitle(), event.getMessage());				
			}

		});
	
		// -----------------------------------------------------------------------------------
		// BROWSER HANDLERS
		// -----------------------------------------------------------------------------------

		/*
		 * Window.addWindowClosingHandler(new ClosingHandler() {
		 * 
		 * @Override public void onWindowClosing(ClosingEvent event) { //clean
		 * up sessions eventbus.fireEvent(new InvalidateCometEvent());
		 * eventbus.fireEvent(new InvalidateSessionEvent()); } });
		 */

	}
}
