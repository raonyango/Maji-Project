package com.maji.client.presenter;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.History;
import com.google.inject.Inject;
import com.maji.client.AutoErrorHandlingAsyncCallback;
import com.maji.client.MajiServiceAsync;
import com.maji.client.event.FlashEvent;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.SessionExpireEvent;
import com.maji.client.event.SessionExpireEventHandler;
import com.maji.client.view.uihandlers.BillViewUiHandlers;
import com.maji.client.view.uihandlers.HasUiHandlers;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.WidgetPresenter;
import com.maji.client.widgets.interfaces.WidgetDisplay;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.HouseUnit;
import com.maji.shared.ibatis.beans.WaterBill;
import com.maji.shared.ibatis.beans.WaterBillStatus;
import com.maji.shared.ibatis.beans.WaterCharge;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.layout.Layout;

public class BillPresenter extends
		WidgetPresenter<BillPresenter.IBillViewDisplay> implements
		BillViewUiHandlers {

	private MajiStrings constants;
	private IBillViewDisplay display;
	private MajiServiceAsync rpcservice;
	private EventBus eventbus;
	private UserLoginData userdata;

	private int presenterwidth, presenterheight;
	private int maxresults;
	private int firstresult;
	private int pagenumber;
	private int numberofelements;

	private static final String HOST_FILENAME = "bill.html";
	private static final String ACTIVITY = "activity";
	private static final String NEW = "new";
	private static final String EDIT = "edit";
	private static final String PARAMETER_SEPERATOR = "&"; // GWTP "?"
	private static final String NAME = "_blank";
	private static final String FEATURES = "width=760, height=480";

	private List<WaterBill> bill_dtos, print_lst;// , addon_dtos;
	private List<WaterBillStatus> status_lst = null;

	public int getPresenterheight() {
		return presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	public void setPresenterDimensions(int presenterheight, int presenterwidth) {
		this.presenterheight = presenterheight;
		this.presenterwidth = presenterwidth;
	}

	@Inject
	public BillPresenter(MajiStrings constants, EventBus eventbus,
			IBillViewDisplay display, MajiServiceAsync rpcService) {
		super(display, eventbus);
		this.display = display;
		rpcservice = rpcService;
		this.eventbus = eventbus;
		this.constants = constants;

		display.setUiHandlers(this);
	}

	public interface IBillViewDisplay extends WidgetDisplay,
			HasUiHandlers<BillViewUiHandlers> {

		Layout asWidget();

		void setPageNumber(int pagenumber);

		void setNumberSelected(int numberselected);

		void refreshStatusBar();

		void setResultSet(List<WaterBill> resultset);

		void setNumberOfElements(int numberofelements);

		StatusBar getStatusBar();

		void setStatusDSource(List<WaterBillStatus> status_lst,boolean new_bill);

		void setHouseUnitsDSource(List<HouseUnit> unit_dtos);

		void setActiveUnitChargeValue(WaterCharge unit_charge,boolean new_bill);
		
		void setLastMeterReading(WaterBill last_bill);

		void setSaveNewSuccess();

		void setBillDetails(WaterBill waterBill);

		void setUpdateSuccess();

	}

	public void revealDisplay(UserLoginData userdata) {
		this.userdata = userdata;
		if (bill_dtos == null) {
			retrieveGridRecords();
		} else {
			displayGridRecords();
		}

		revealDisplay();
	}

	@Override
	protected void onBind() {
		maxresults = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
		firstresult = 0;
		pagenumber = 1;
		numberofelements = maxresults;

		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {

			@Override
			public void onRefreshApplication(RefreshEvent event) {
				if (History.getToken().trim().equals("")
						|| History.getToken().trim().equals("main")) {
					revealDisplay(event.getLogindata());
				}
			}
		});

		eventbus.addHandler(SessionExpireEvent.TYPE,
				new SessionExpireEventHandler() {

					public void onSessionExpireEvent(SessionExpireEvent event) {
						eventbus.fireEvent(new FlashEvent(constants
								.session_timed_out(), 4000));
					}

				});
	}

	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub
	}

	protected void retrieveGridRecords() {
		getAllBills();
	}

	protected void displayGridRecords() {
		try {
			if (bill_dtos != null)
				numberofelements = bill_dtos.size();

			// update Selected label e.g "0 of 50 selected"
			display.setNumberOfElements(numberofelements);
			display.setPageNumber(pagenumber);
			display.refreshStatusBar();

			// enable/disable the pagination widgets
			if (pagenumber == 1) {
				display.getStatusBar().getResultSetFirstButton().disable();
				display.getStatusBar().getResultSetPreviousButton().disable();
			}

			// enable/disable the pagination widgets
			if (numberofelements < maxresults) {
				display.getStatusBar().getResultSetNextButton().disable();
			} else {
				display.getStatusBar().getResultSetNextButton().enable();
			}

			// pass the result set to the View
			if (bill_dtos != null)
				display.setResultSet(bill_dtos);
		} catch (Exception e) {
			Log.error(e.getLocalizedMessage(), e);
		}
	}

	@Override
	public void onRecordDoubleClicked(Integer recordId) {
		getAllBillStatuses(false);
		getAllHouseUnits();
		getActiveUnitCharge(false);
		getBill(recordId);
	}


	@Override
	public void onResultSetFirstButtonClicked() {
		firstresult = 0;
		pagenumber = 1;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetNextButtonClicked() {
		firstresult += numberofelements;
		pagenumber++;

		retrieveGridRecords();
	}

	@Override
	public void onResultSetPreviousButtonClicked() {
		firstresult -= maxresults;
		pagenumber--;

		retrieveGridRecords();
	}

	@Override
	public void onRefreshButtonClicked() {
		retrieveGridRecords();
	}

	protected void getAllBills() {
		Command cmd = new Command() {

			@Override
			public void execute() {
				//Integer bill_id, Integer house_unit_id, String month, Integer year
				rpcservice
						.getAllWaterBills(0,0,null,0, null,new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@SuppressWarnings("unchecked")
							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										numberofelements = response
												.getIntegerData();
										if (response.getListData() != null) {
											bill_dtos = (List<WaterBill>) response
													.getListData();
										}
									} else {
										SC.say(constants.app_error(),
												constants.error_get_all_bills()
														+ (response
																.getErrorData() == null ? ""
																: " "
																		+ response
																				.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_get_all_bills());
									return;
								}
								// allservices_loaded = true;
								if (bill_dtos != null) {
									displayGridRecords();
								}
							}

						});
			}
		};

		cmd.execute();
	}

	private void getAllBillStatuses(final boolean new_bill) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getAllWaterBillStatuses(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {
							@SuppressWarnings("unchecked")
							@Override
							public void onSuccess(StandardServerResponse result) {
								if (result.isSuccess()) {
									if (result.getListData() != null) {
										if (result.getListData().size() > 0) {
											status_lst = (List<WaterBillStatus>) result
													.getListData();

											display.setStatusDSource(status_lst, new_bill);
										}
									} else {
										SC.say(constants.app_error(),
												constants
														.err_getallWBStatuses()
														+ (result
																.getErrorData() == null ? ""
																: " "
																		+ result.getErrorData()));

									}
								} else {
									SC.say(constants.app_error(),
											constants.err_getallWBStatuses()
													+ (result.getErrorData() == null ? ""
															: " "
																	+ result.getErrorData()));

								}
							}

							@Override
							public void onFailure(Throwable caught) {
								Log.info(".................wbstatusds:onFailure()..............."
										+ caught.getMessage());
							}
						});
			}
		};

		cmd.execute();
	}

	protected void getAllHouseUnits() {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getAllHouseUnits(0, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@SuppressWarnings("unchecked")
							@Override
							public void onSuccess(
									StandardServerResponse response) {
								List<HouseUnit> unit_dtos = null;

								if (response != null) {
									if (response.isSuccess()) {
										numberofelements = response
												.getIntegerData();
										if (response.getListData() != null) {
											unit_dtos = (List<HouseUnit>) response
													.getListData();
											display.setHouseUnitsDSource(unit_dtos);
										}
									} else {
										SC.say(constants.app_error(),
												constants.error_get_all_units()
														+ (response
																.getErrorData() == null ? ""
																: " "
																		+ response
																				.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_get_all_units());
									return;
								}
								/*
								 * //allservices_loaded = true; if(unit_dtos !=
								 * null){ displayGridRecords(); }
								 */
							}

						});
			}
		};

		cmd.execute();
	}

	protected void getActiveUnitCharge(final boolean new_bill) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getActiveUnitCharge(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										if (response.getListData() != null) {
											if (response.getListData().size() > 0) {
												display.setActiveUnitChargeValue((WaterCharge)response.getListData().get(0), new_bill);
											}
										}
									} else {
										SC.say(constants.app_error(),
												constants
														.error_get_active_unit_charge()
														+ (response
																.getErrorData() == null ? ""
																: " "
																		+ response
																				.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(), constants
											.error_get_active_unit_charge());
									return;
								}

							}

						});
			}
		};

		cmd.execute();
	}

	@Override
	public void onNewButtonClicked() {
		/*
		 * StringBuilder url = new StringBuilder();
		 * url.append(HOST_FILENAME).append("?");
		 * 
		 * String arg0Name = URL.encodeQueryString(BillRecord.BILL_ID);
		 * url.append(arg0Name); url.append("="); String arg0Value =
		 * URL.encodeQueryString("0"); // url.append(arg0Value);
		 * url.append(encodeBase64(arg0Value));
		 * Log.debug("Window.open() arg0Value: " + arg0Value + " Base64: " +
		 * encodeBase64(arg0Value)); url.append(PARAMETER_SEPERATOR);
		 * 
		 * String arg1Name = URL.encodeQueryString(ACTIVITY);
		 * url.append(arg1Name); url.append("="); String arg1Value =
		 * URL.encodeQueryString(NEW); // url.append(arg1Value);
		 * url.append(encodeBase64(arg1Value));
		 * Log.debug("Window.open() arg1Value: " + arg1Value + " Base64: " +
		 * encodeBase64(arg1Value));
		 * 
		 * // Log.debug("Window.open() RelativeURL: " +
		 * Serendipity.getRelativeURL(url.toString()));
		 * Window.open(maji.getRelativeURL(url.toString()), NAME, FEATURES);
		 */
		
		//removeBillForm();
		
		getAllBillStatuses(true);
		getAllHouseUnits();
		getActiveUnitCharge(true);
	}

	//public static native String removeBillForm() /*-{ return $wnd.removeBillForm(); }-*/;
	
	public static native String encodeBase64(String string) /*-{ return $wnd.btoa(string); }-*/;

	@Override
	public void onHouseUnitSelected(final Integer houseunit_id) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.getWaterBills(houseunit_id, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										numberofelements = response
												.getIntegerData();
										if (response.getListData() != null) {
											if (response.getListData().size() > 0){
												display.setLastMeterReading((WaterBill) response.getListData().get(0));
											}else{
												display.setLastMeterReading(new WaterBill());
											}
										}else{
											display.setLastMeterReading(new WaterBill());
										}
									} else {
										SC.say(constants.app_error(), (response.getErrorData() == null ? ""
																: " " + response.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_get_all_bills());
									return;
								}
								
							}

						});
			}
		};

		cmd.execute();
	}

	@Override
	public void onSaveNewButtonClicked(final WaterBill bill) {
		
		if (bill != null){
		//bill.setBillNumber(billNumber);
			if (userdata != null){
		bill.setCreatedBy(userdata.getUserId());
				
		Command cmd = new Command() {

			@Override
			public void execute() {
				rpcservice
						.addNewBill(bill, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										display.setSaveNewSuccess();
										retrieveGridRecords();
									} else {
										SC.say(constants.app_error(), (response.getErrorData() == null ? ""
																: " " + response.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_add_new_bill());
									return;
								}
								
							}

						});
			}
		};

		cmd.execute();

			}else{
				SC.say("User data is null");
			}
		
		}
	}

	private void getBill(final Integer bill_id) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				//Integer bill_id, Integer house_unit_id, String month, Integer year
				rpcservice
						.getAllWaterBills(bill_id,0,null,0, null,new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										numberofelements = response
												.getIntegerData();
										if (response.getListData() != null) {
											if (response.getListData().size() > 0) {
											display.setBillDetails((WaterBill) response
													.getListData().get(0));
											}
										}
									} else {
										SC.say(constants.app_error(),
												constants.error_get_bill()
														+ (response
																.getErrorData() == null ? ""
																: " "
																		+ response
																				.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_get_bill());
									return;
								}						
							}

						});
			}
		};

		cmd.execute();
	}

	@Override
	public void onUpdateButtonClicked(final WaterBill bill) {
		if (bill != null){
			//bill.setBillNumber(billNumber);
				if (userdata != null){
			bill.setModifiedBy(userdata.getUserId());
			Log.info(userdata.getUserId() + ": created by...................." + bill.getBillId());
					
			Command cmd = new Command() {

				@Override
				public void execute() {
					rpcservice
							.UpdateBill(bill, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
									eventbus, this, constants) {

								@Override
								public void onSuccess(
										StandardServerResponse response) {

									if (response != null) {
										if (response.isSuccess()) {
											display.setUpdateSuccess();
											retrieveGridRecords();
										} else {
											SC.say(constants.app_error(), (response.getErrorData() == null ? ""
																	: " " + response.getErrorData()));
											return;
										}
									} else {
										SC.say(constants.app_error(),
												constants.error_update_bill());
										return;
									}
									
								}

							});
				}
			};

			cmd.execute();

				}else{
					SC.say("User data is null");
				}
			
			}
		
	}

	@Override
	public void onPrintButtonClicked(int print_option, String month, int year) {
		String pmonth = null;
		int pyear = 0;
		int status = 0;
				
		if (print_option == 1){
			//Print All
			
		}else if (print_option == 2){
			//Print All Pending
			status = 1;
		}else if (print_option == 3){
			//Print All In Month
			pmonth = month;
			pyear = year;
		}else if (print_option == 4){
			//Print Pending In Month
			pmonth = month;
			pyear = year;
			status = 1;
		}
		
		printBills(status, pmonth, pyear);
				
	}

	private void sentToPrinter(List<WaterBill> print_lst) {
		// TODO Auto-generated method stub
		try{
			
			for(WaterBill bill:print_lst){
				
			}
		}catch(Exception e){
			
		}
	}

	private void printBills(final int status, final String month, final int year) {
		Command cmd = new Command() {

			@Override
			public void execute() {
				//Integer bill_id, Integer house_unit_id, String month, Integer year
				rpcservice
						.printWaterBills(0,0,month,year,status, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
								eventbus, this, constants) {

							@Override
							public void onSuccess(
									StandardServerResponse response) {

								if (response != null) {
									if (response.isSuccess()) {
										/*if (response.getListData() != null) {
											print_lst = (List<WaterBill>) response
													.getListData();
											
											if (print_lst != null){
												if(print_lst.size() > 0){
													sentToPrinter(print_lst);
												}
											}
										}*/
										SC.say(response.getIntegerData() + " bills printed successfully. Merged file on '" + response.getStringData() + "'");
									} else {
										SC.say(constants.app_error(),
												constants.error_printing_bills()
														+ (response
																.getErrorData() == null ? ""
																: " "
																		+ response
																				.getErrorData()));
										return;
									}
								} else {
									SC.say(constants.app_error(),
											constants.error_printing_bills());
									return;
								}								
							}

						});
			}
		};

		cmd.execute();
	}
}
