package com.maji.client.presenter;

import net.customware.gwt.presenter.client.EventBus;

import com.google.gwt.core.client.GWT;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.History;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.maji.client.AuthenticationServiceAsync;
import com.maji.client.AutoErrorHandlingAsyncCallback;
import com.maji.client.event.ErrorEvent;
import com.maji.client.event.FlashEvent;
import com.maji.client.event.FlashEventHandler;
import com.maji.client.event.LoginEvent;
import com.maji.client.event.LoginEventHandler;
import com.maji.client.event.LoginSuccessEvent;
import com.maji.client.event.LoginSuccessEventHandler;
import com.maji.client.event.LogoutEvent;
import com.maji.client.event.LogoutEventHandler;
import com.maji.client.event.LogoutSuccessEvent;
import com.maji.client.event.LogoutSuccessEventHandler;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.ServerStatusEvent;
import com.maji.client.event.ServerStatusEvent.ServerStatus;
import com.maji.client.event.ServerStatusEventHandler;
import com.maji.client.event.SessionExpireEvent;
import com.maji.client.event.SessionExpireEventHandler;
import com.maji.client.event.UserAccountEvent;
import com.maji.client.event.UserAccountEventHandler;
import com.maji.client.place.PlaceTokens;
import com.maji.client.utils.ClientUtils;
import com.maji.client.widgets.WidgetContainerPresenter;
import com.maji.client.widgets.interfaces.WidgetContainerDisplay;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.widgets.layout.Layout;

public class HomePresenter extends
		WidgetContainerPresenter<HomePresenter.IHomeViewDisplay> {

	private static final int IDLE_INTERVAL = 150000;
	public IHomeViewDisplay display;
	private AuthenticationServiceAsync authrpcservice;
	private EventBus eventbus;
	private ServerStatus serverStatus = ServerStatus.Available;
	private UserLoginData user;
	private MajiStrings constants;
	private Timer noopTimer = new IdleTimer();
	private LoginPresenter loginpresenter;
	private MainPresenter mainpresenter;
	/*private ForgotPasswordPresenter fpasswordpresenter;
	private RegistrationPresenter registerpresenter;*/

	public interface IHomeViewDisplay extends WidgetContainerDisplay {
		Layout asWidget();
	}

	@Inject
	public HomePresenter(ClientUtils clientutils, MajiStrings constants,
			EventBus eventBus, IHomeViewDisplay display,
			LoginPresenter loginpresenter, MainPresenter mainpresenter,
			//ForgotPasswordPresenter fpasswordpresenter,
			AuthenticationServiceAsync authrpcservice
			//,RegistrationPresenter registerpresenter
			) {
		super(display, eventBus, loginpresenter, mainpresenter);
		this.display = display;
		this.authrpcservice = authrpcservice;
		this.eventbus = eventBus;
		this.constants = constants;
		this.mainpresenter = mainpresenter;
		this.loginpresenter = loginpresenter;
		//this.fpasswordpresenter = fpasswordpresenter;
		//this.registerpresenter = registerpresenter;
		// this.clientutils = clientutils;
	}

	@Override
	protected void onBind() {
		super.onBind();
		/*
		display.getLogoutClick().addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {

				logoutUser();
			}
		});*/

		eventbus.addHandler(LogoutEvent.TYPE, new LogoutEventHandler() {
			
			@Override
			public void onLogout(LogoutEvent logoutEvent) {
				logoutUser();
			}
		});
		
		eventbus.addHandler(UserAccountEvent.TYPE, new UserAccountEventHandler() {

			@Override
			public void onShowAccount(UserAccountEvent event) {
				user = event.getUser();
				showUserAccountPage(user);
				// display.showMessage(constants.welcome(), 3000);
			}

		});

		eventbus.addHandler(LogoutSuccessEvent.TYPE, new LogoutSuccessEventHandler() {

			public void onLogoutSuccess(LogoutSuccessEvent event) {
				
				if (mainpresenter.isBound())
					mainpresenter.unbind();

				UserLoginData userdata = event.getUserLoginData();
				String username = null;
				if (userdata != null) {
					username = userdata.getUsername();
				}
				showLoginPage(username, null);
				noopTimer.cancel();
			}

		});

		eventbus.addHandler(SessionExpireEvent.TYPE,
				new SessionExpireEventHandler() {

					public void onSessionExpireEvent(SessionExpireEvent event) {
						logoutUser();
					}

				});

		eventbus.addHandler(ServerStatusEvent.TYPE,
				new ServerStatusEventHandler() {

					public void onServerStatusChange(ServerStatusEvent event) {
						if (event.getStatus() != serverStatus) {
							GWT.log("Server status has hanged from "
									+ serverStatus + " to" + event.getStatus(),
									null);
							serverStatus = event.getStatus();
							/*display.setServerStatus(serverStatus);*/
						}
					}
				});

		eventbus.addHandler(FlashEvent.TYPE, new FlashEventHandler() {

			public void onFlash(FlashEvent event) {
				/*display.showMessage(event.getMessage(), event.getMillisec());*/
			}

		});

		eventbus.addHandler(LoginEvent.TYPE, new LoginEventHandler() {

			@Override
			public void onLogin(LoginEvent event) {
				showLoginPage(null, event.getCommand());
			}
		});

		eventbus.addHandler(LoginSuccessEvent.TYPE,
				new LoginSuccessEventHandler() {

					@Override
					public void onLoginSuccess(LoginSuccessEvent event) {
						user = event.getUser();
						/*display.getUserText().setText(
								event.getUser().getUsername());*/
						noopTimer.scheduleRepeating(IDLE_INTERVAL);
						
					}
				});

		/*eventbus.addHandler(ForgotPasswordEvent.TYPE,
				new ForgotPasswordEventHandler() {

					@Override
					public void onForgotPassword(ForgotPasswordEvent event) {
						addPresenter(fpasswordpresenter);
						if (!fpasswordpresenter.isBound())
							fpasswordpresenter.bind();
						fpasswordpresenter.revealDisplay();
					}
				});
		
		eventbus.addHandler(RegisterEvent.TYPE, new RegisterEventHandler() {
			
			@Override
			public void onRegister(RegisterEvent event) {
				addPresenter(registerpresenter);
				if (!registerpresenter.isBound())
					registerpresenter.bind();
				registerpresenter.revealDisplay(true);
				
			}
		});

		eventbus.addHandler(ForgotPasswordSuccessEvent.TYPE,
				new ForgotPasswordSuccessEventHandler() {

					@Override
					public void onResetSuccess(ForgotPasswordSuccessEvent event) {
						loginpresenter.revealDisplay(null, null);
						loginpresenter
								.getDisplay()
								.setLoginstatuslbl(constants.password_reset_successfull(), false);
					}
				});*/
		
		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {
			
			@Override
			public void onRefreshApplication(RefreshEvent event) {
				user = event.getLogindata();
				/*display.getUserText().setText(user.getUsername());
				display.showTopNavigation(true);*/
				
				if(History.getToken().trim().equals("") || History.getToken().trim().equals(PlaceTokens.home) || 
						History.getToken().trim().equals(PlaceTokens.main)){
					addPresenter(mainpresenter);
					mainpresenter.revealDisplay(event.getLogindata());
				}
			}
		});

		setChildPresenterDimensions(display.asWidget()
				.getOffsetWidth(), display.asWidget()
				.getOffsetHeight());
		checkUserSession();
	}
		
	private void logoutUser() {
		if (user != null) {
			authrpcservice.logoutUser(user.getUsername(),
					new AutoErrorHandlingAsyncCallback<StandardServerResponse>(
							eventbus) {

						@Override
						public void onSuccess(StandardServerResponse response) {
							if (response.isSuccess()) {
								if (response.getListData() != null) {
									if (response.getListData().size() > 0) {
										logoutUserWithSpringSecurity((UserLoginData) response
												.getListData().get(0));										
									}
								}
							} else {
								eventbus.fireEvent(new ErrorEvent(constants
										.app_error(), constants
										.fail_logout_user()));
							}
						}

						@Override
						public void onFailure(Throwable caught) {
							eventbus.fireEvent(new ErrorEvent(
									constants.error(), constants
											.fail_logout_user()));
						}
					});
		}
	}

	private void logoutUserWithSpringSecurity(final UserLoginData logindata) {
		RequestBuilder rb = new RequestBuilder(RequestBuilder.POST, GWT
				.getHostPageBaseURL()
				+ "j_spring_security_logout");
		rb.setHeader("Content-Type", "application/x-www-form-urlencoded");

		rb.setCallback(new RequestCallback() {
			public void onError(Request request, Throwable exception) {
				eventbus.fireEvent(new ErrorEvent(constants.error(), constants
						.fail_logout_user()));
			}

			public void onResponseReceived(Request request, Response response) {
				if (response.getStatusCode() == 200) {
					eventbus.fireEvent(new LogoutSuccessEvent(logindata));
				} else {
					eventbus.fireEvent(new ErrorEvent(constants.app_error(),
							constants.fail_logout_user() + "("
									+ response.getStatusCode() + ")"));
				}
			}
		});

		try {
			rb.send();
		} catch (RequestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void checkUserSession() {
		UserLoginData logindata = null;
		if (Cookies.getCookie(MajiConstants.USER_SESS_ID) != null) {
			logindata = new UserLoginData();
			logindata.setSessionid(Cookies
					.getCookie(MajiConstants.USER_SESS_ID));
		}

		authrpcservice.checkSession(logindata,
				new AsyncCallback<StandardServerResponse>() {

			@Override
			public void onSuccess(StandardServerResponse response) {
				serverStatus = ServerStatus.Available;
				// display.setServerStatus(serverStatus);
				if (response.isSuccess()) {
					if (response.getListData() != null) {
						if (response.getListData().size() > 0) {
							//user = (UserLoginData) response.getListData().get(0);
							//eventbus.fireEvent(new LoginSuccessEvent((UserLoginData) response.getListData().get(0)));
							eventbus.fireEvent(new RefreshEvent((UserLoginData) response.getListData().get(0)));
						} else {
							eventbus.fireEvent(new LoginEvent(null));
						}
					} else {
						eventbus.fireEvent(new LoginEvent(null));
					}
				} else {		
					eventbus.fireEvent(new LoginEvent(null));
				}
			}

			@Override
			public void onFailure(Throwable caught) {
				serverStatus = ServerStatus.Unavailable;
				/*display.setServerStatus(serverStatus);*/
				// clientutils.showErrorMessage(constants.app_error(),
				// constants.fail_check_session());
				eventbus.fireEvent(new LoginEvent(null));				
			}
		});
	}

	private void showUserAccountPage(UserLoginData user) {
		addPresenter(mainpresenter);
		/*display.showTopNavigation(true);*/
		if (!mainpresenter.isBound())
			mainpresenter.bind();
		mainpresenter.revealDisplay(user);
	}

	private void showLoginPage(String username, Command command) {
		/*display.showTopNavigation(false);*/
		if (!loginpresenter.isBound())
			loginpresenter.bind();
		loginpresenter.revealDisplay(username, command);
	}

	private class IdleTimer extends Timer {
		// boolean running = false;

		public void run() {

			/*
			 * if (!running) { running = true; dispatcher.execute(new Idle(),
			 * new HupaCallback<IdleResult>(dispatcher, eventBus) { public void
			 * callback(IdleResult result) { running = false; // check if the
			 * server is not supporting the Idle command. // if so cancel this
			 * Timer if (result.isSupported() == false) {
			 * IdleTimer.this.cancel(); } // Noop // TODO: put code here to
			 * readew events from server (new messages ...)
			 * 
			 * } }); }
			 */

		}
	}

	@Override
	public void unbind() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isBound() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void revealDisplay() {
		// TODO Auto-generated method stub
	}

	private void setChildPresenterDimensions(int width, int height) {
		mainpresenter.setPresenterheight(height);
		mainpresenter.setPresenterwidth(width - 18);
	}
}
