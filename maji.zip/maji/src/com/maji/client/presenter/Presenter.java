package com.maji.client.presenter;

import com.google.gwt.user.client.ui.HasWidgets;

public abstract interface Presenter extends net.customware.gwt.presenter.client.Presenter{
	public abstract void go(final HasWidgets container);
	void bind();
	void unbind();
}
