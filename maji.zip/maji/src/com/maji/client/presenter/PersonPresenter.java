package com.maji.client.presenter;

import java.util.List;

import net.customware.gwt.presenter.client.EventBus;

import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.History;
import com.google.inject.Inject;
import com.maji.client.AutoErrorHandlingAsyncCallback;
import com.maji.client.MajiServiceAsync;
import com.maji.client.event.FlashEvent;
import com.maji.client.event.RefreshEvent;
import com.maji.client.event.RefreshEventHandler;
import com.maji.client.event.SessionExpireEvent;
import com.maji.client.event.SessionExpireEventHandler;
import com.maji.client.view.uihandlers.HasUiHandlers;
import com.maji.client.view.uihandlers.PersonViewUiHandlers;
import com.maji.client.widgets.StatusBar;
import com.maji.client.widgets.WidgetPresenter;
import com.maji.client.widgets.interfaces.WidgetDisplay;
import com.maji.shared.beans.PersonDto;
import com.maji.shared.beans.StandardServerResponse;
import com.maji.shared.beans.UserLoginData;
import com.maji.shared.ibatis.beans.City;
import com.maji.shared.ibatis.beans.Person;
import com.maji.shared.ibatis.beans.PersonStatus;
import com.maji.shared.properties.MajiConstants;
import com.maji.shared.properties.MajiStrings;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.layout.Layout;

public class PersonPresenter extends
		WidgetPresenter<PersonPresenter.IPersonViewDisplay> implements PersonViewUiHandlers {

	private MajiStrings constants;
	private IPersonViewDisplay display;
	private MajiServiceAsync rpcservice;
	private EventBus eventbus;
	private UserLoginData userdata;
	
	private int presenterwidth, presenterheight;
	private int maxresults;
	private int firstresult;
	private int pagenumber;
	private int numberofelements;
	
	//private boolean allservices_loaded, alladdons_loaded, userservices_loaded, useraddons_loaded;
	private List<Person> person_dtos;//, addon_dtos;
	private  List<City> city_dtos;
	private List<PersonStatus> pstatus_dtos;
	
	public int getPresenterheight() {
		return presenterheight;
	}

	public int getPresenterwidth() {
		return presenterwidth;
	}

	public void setPresenterDimensions(int presenterheight, int presenterwidth) {
		this.presenterheight = presenterheight;
		this.presenterwidth = presenterwidth;
	}

	@Inject
	public PersonPresenter(MajiStrings constants, EventBus eventbus,
			IPersonViewDisplay display, MajiServiceAsync rpcService) {
		super(display, eventbus);
		this.display = display;
		rpcservice = rpcService;
		this.eventbus = eventbus;
		this.constants = constants;
		
		display.setUiHandlers(this);
	}

	public interface IPersonViewDisplay extends WidgetDisplay, HasUiHandlers<PersonViewUiHandlers> {

		Layout asWidget();

		void setPageNumber(int pagenumber);

		void setNumberSelected(int numberselected);

		void refreshStatusBar();

		void setResultSet(List<Person> resultset);

		void setNumberOfElements(int numberofelements);

		StatusBar getStatusBar();

		void setStatusDSource(List<PersonStatus> status_lst, boolean new_person);

		void setPersonDetails(Person person);

		void setUpdateSuccess();

		void setSaveNewSuccess();

		void setCityDSource(List<City> city_dtos);
	}

	public void revealDisplay(UserLoginData userdata) {
		this.userdata = userdata;
		if(person_dtos == null){
			retrieveGridRecords();
		}else{
			displayGridRecords();
		}
		
		revealDisplay();
	}

	@Override
	protected void onBind() {
		maxresults = MajiConstants.DEFAULT_MAX_GRID_RESULTS;
	    firstresult = 0;
	    pagenumber = 1;
	    numberofelements = maxresults;
	    
		eventbus.addHandler(RefreshEvent.TYPE, new RefreshEventHandler() {

			@Override
			public void onRefreshApplication(RefreshEvent event) {
				if (History.getToken().trim().equals("")
						|| History.getToken().trim().equals("main")) {
					revealDisplay(event.getLogindata());
				}
			}
		});		

		eventbus.addHandler(SessionExpireEvent.TYPE,
				new SessionExpireEventHandler() {

					public void onSessionExpireEvent(SessionExpireEvent event) {
						eventbus.fireEvent(new FlashEvent(constants
								.session_timed_out(), 4000));
					}

				});
	}
	
	@Override
	protected void onRevealDisplay() {
		// TODO Auto-generated method stub
	}

	@Override
	protected void onUnbind() {
		// TODO Auto-generated method stub
	}

	protected void retrieveGridRecords() {
		getAllPersons();		
	}
	
	protected void displayGridRecords(){
		try{
			if(person_dtos != null)
				numberofelements= person_dtos.size();
	
			// update Selected label e.g "0 of 50 selected"
			display.setNumberOfElements(numberofelements);
			display.setPageNumber(pagenumber);
			display.refreshStatusBar();
	
			//Log.debug("onSuccess() - firstResult: " + firstresult + " pageNumber: " + pagenumber + " numberOfElements: " + numberofelements);
	
			// enable/disable the pagination widgets
			if (pagenumber == 1) {
				display.getStatusBar().getResultSetFirstButton()
						.disable();
				display.getStatusBar()
						.getResultSetPreviousButton().disable();
			}
	
			// enable/disable the pagination widgets
			if (numberofelements < maxresults) {
				display.getStatusBar().getResultSetNextButton()
						.disable();
			} else {
				display.getStatusBar().getResultSetNextButton()
						.enable();
			}
	
			// pass the result set to the View
			if(person_dtos != null)
				display.setResultSet(person_dtos);
		}catch (Exception e) {
			Log.error(e.getLocalizedMessage(), e);
		}
	}

	@Override
	public void onRecordDoubleClicked(int recordId) {
		getAllCities();
		getAllPersonStatuses(false);
		getPerson(recordId);
	}

	private void getPerson(final int person_id) {
Command cmd = new Command() {
			
			@Override
			public void execute() {
				rpcservice.getPerson(person_id, new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

					@SuppressWarnings("unchecked")
					@Override
					public void onSuccess(StandardServerResponse response) {
						
						if(response != null){
							if(response.isSuccess()){
								if(response.getListData() != null){
									if(response.getListData().size() > 0){
										display.setPersonDetails(((List<Person>)response.getListData()).get(0));
									}
								}
							}else{
								SC.say(constants.app_error(), constants.error_get_all_persons() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
								return;
							}
						}else{
							SC.say(constants.app_error(), constants.error_get_all_persons());
							return;
						}
						//allservices_loaded = true;
						if(person_dtos != null){
							displayGridRecords();
						}
					}				
					
				});
			}
		};
		
		cmd.execute();		
	}

	@Override
	public void onResultSetFirstButtonClicked() {
		firstresult = 0;
	    pagenumber = 1;

	    retrieveGridRecords();
	}

	@Override
	public void onResultSetNextButtonClicked() {
		firstresult += numberofelements;
	    pagenumber++;
	
	    retrieveGridRecords();
	}

	@Override
	public void onResultSetPreviousButtonClicked() {
		firstresult -= maxresults;
	    pagenumber--;
	    
	    retrieveGridRecords();		
	}

	@Override
	public void onRefreshButtonClicked() {
		retrieveGridRecords();	
	}

	protected void getAllPersons() {
		Command cmd = new Command() {
			
			@Override
			public void execute() {
				rpcservice.getAllPersons(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

					@SuppressWarnings("unchecked")
					@Override
					public void onSuccess(StandardServerResponse response) {
						
						if(response != null){
							if(response.isSuccess()){
								numberofelements = response.getIntegerData();
								if(response.getListData() != null){
									person_dtos = (List<Person>)response.getListData();
								}
							}else{
								SC.say(constants.app_error(), constants.error_get_all_persons() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
								return;
							}
						}else{
							SC.say(constants.app_error(), constants.error_get_all_persons());
							return;
						}
						//allservices_loaded = true;
						if(person_dtos != null){
							displayGridRecords();
						}
					}				
					
				});
			}
		};
		
		cmd.execute();		
	}

	@Override
	public void onNewButtonClicked() {
		getAllCities();
		getAllPersonStatuses(true);
	}

	private void getAllPersonStatuses(final boolean new_person) {
Command cmd = new Command() {
			
			@Override
			public void execute() {
				rpcservice.getAllPersonStatuses(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

					@SuppressWarnings("unchecked")
					@Override
					public void onSuccess(StandardServerResponse response) {
						
						if(response != null){
							if(response.isSuccess()){
								
								if(response.getListData() != null){
									pstatus_dtos = (List<PersonStatus>)response.getListData();
									display.setStatusDSource(pstatus_dtos, new_person);
								}
							}else{
								SC.say(constants.app_error(), constants.error_get_all_pstatuses() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
								return;
							}
						}else{
							SC.say(constants.app_error(), constants.error_get_all_pstatuses());
							return;
						}
					}				
					
				});
			}
		};
		
		cmd.execute();
	}

	private void getAllCities() {
Command cmd = new Command() {
			
			@Override
			public void execute() {
				rpcservice.getAllCities(new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

					@SuppressWarnings("unchecked")
					@Override
					public void onSuccess(StandardServerResponse response) {
						
						if(response != null){
							if(response.isSuccess()){
								
								if(response.getListData() != null){
									city_dtos = (List<City>)response.getListData();
									display.setCityDSource(city_dtos);
								}
							}else{
								SC.say(constants.app_error(), constants.error_get_all_cities() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
								return;
							}
						}else{
							SC.say(constants.app_error(), constants.error_get_all_cities());
							return;
						}
					}				
					
				});
			}
		};
		
		cmd.execute();		
	}

	@Override
	public void onSaveNewButtonClicked(final Person person) {
		person.setCreatedBy(userdata.getUserId());

Command cmd = new Command() {
			
			@Override
			public void execute() {
				rpcservice.addNewPerson(person,new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

					@SuppressWarnings("unchecked")
					@Override
					public void onSuccess(StandardServerResponse response) {
						
						if(response != null){
							if(response.isSuccess()){
								
								display.setSaveNewSuccess();
								onRefreshButtonClicked();
							}else{
								SC.say(constants.app_error(), constants.error_add_new_person() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
								return;
							}
						}else{
							SC.say(constants.app_error(), constants.error_add_new_person());
							return;
						}
					}				
					
				});
			}
		};
		
		cmd.execute();		
	}

	@Override
	public void onUpdateButtonClicked(final Person person) {
		person.setModifiedBy(userdata.getUserId());

		Command cmd = new Command() {
					
					@Override
					public void execute() {
						rpcservice.updatePerson(person,new AutoErrorHandlingAsyncCallback<StandardServerResponse>(eventbus, this, constants) {

							@SuppressWarnings("unchecked")
							@Override
							public void onSuccess(StandardServerResponse response) {
								
								if(response != null){
									if(response.isSuccess()){
										
										display.setUpdateSuccess();
										onRefreshButtonClicked();
									}else{
										SC.say(constants.app_error(), constants.error_update_person() + (response.getErrorData() == null ? "" : " " + response.getErrorData()));
										return;
									}
								}else{
									SC.say(constants.app_error(), constants.error_update_person());
									return;
								}
							}				
							
						});
					}
				};
				
				cmd.execute();
	}
	
}
