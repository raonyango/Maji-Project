package com.maji.client.place;

import net.customware.gwt.presenter.client.EventBus;
import net.customware.gwt.presenter.client.place.DefaultPlaceManager;
import net.customware.gwt.presenter.client.place.TokenFormatter;

import com.google.inject.Inject;

public class MajiPlaceManager extends DefaultPlaceManager {

	@Inject
	public MajiPlaceManager(EventBus eventbus,
			TokenFormatter tokenformatter, HomePlace homeplace,
			MainPlace mainplace, LoginPlace loginplace, PersonPlace personplace, UnitPlace unitplace, 
			ChargePlace chargeplace, BillPlace billplace,ErrorPlace errorplace, FeePlace feeplace) {
		
		super(eventbus, tokenformatter, homeplace, mainplace, loginplace, personplace, unitplace,
				chargeplace, billplace,feeplace,errorplace);
		
	}
}
