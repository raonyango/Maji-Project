package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.ErrorPresenter;

public class ErrorPlace extends ProvidedPresenterPlace<ErrorPresenter> {

	public static final String NAME = PlaceTokens.error;
	
	@Inject
    public ErrorPlace(Provider<ErrorPresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, ErrorPresenter presenter) {
      
    }
     
}
