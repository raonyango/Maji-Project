package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.ChargePresenter;

public class ChargePlace extends ProvidedPresenterPlace<ChargePresenter> {

	public static final String NAME = PlaceTokens.charge;
	
	@Inject
    public ChargePlace(Provider<ChargePresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, ChargePresenter presenter) {
      /*  String user = request.getParameter("user", null);
        if (user != null) {
            presenter.getDisplay().getUserNameValue().setValue(user);
        }*/
    }
}
