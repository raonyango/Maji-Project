package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.MainPresenter;

public class MainPlace extends ProvidedPresenterPlace<MainPresenter> {

	public static final String NAME = PlaceTokens.main;
	
	@Inject
    public MainPlace(Provider<MainPresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, MainPresenter presenter) {
       /* String user = request.getParameter("user", null);
        if (user != null) {
            //presenter.getDisplay().getUserNameValue().setValue(user);
        }*/
    }
    /*
    @Override
    protected PlaceRequest prepareRequest(PlaceRequest request, StatusPresenter presenter) {

        if (presenter.getId() != null) {
            request = request.with(PARAM_ID, presenter.getId());
        }

        return request;
    }*/
}
