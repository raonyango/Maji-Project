package com.maji.client.place;

import net.customware.gwt.presenter.client.gin.ProvidedPresenterPlace;
import net.customware.gwt.presenter.client.place.PlaceRequest;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.maji.client.presenter.PersonPresenter;

public class PersonPlace extends ProvidedPresenterPlace<PersonPresenter> {

	public static final String NAME = PlaceTokens.person;
	
	@Inject
    public PersonPlace(Provider<PersonPresenter> presenter) {
        super(presenter);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void preparePresenter(PlaceRequest request, PersonPresenter presenter) {
      /*  String user = request.getParameter("user", null);
        if (user != null) {
            presenter.getDisplay().getUserNameValue().setValue(user);
        }*/
    }
}
