package com.maji.shared.beans;

import java.io.Serializable;
import java.util.Date;

public class UserLoginData implements Serializable{

	private static final long serialVersionUID = -573674209289821920L;
    private String username;
    private String password;
    private int userRoleId;
    private String sessionid;    
    private Date loginDate;
    private boolean auth;
    private boolean rememberlogin = false;
    private UserSettings settings = null;
    private int userId = -1;
	private int companyId = -1;
    private int systemAdminId = -1;
    private int companyUserId = -1;
    
    public int getUserId() {
		return userId;
	}

	public void setUserId(int userid) {
		this.userId = userid;
	}

	public void setUsername(String username) {
		this.username = username == null ? null : username.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
    	this.password = password == null ? null : password.trim();
    }

    public String getPassword() {
        return password;
    }
   
    public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int role) {
		this.userRoleId = role;
	}

	public String toString() {
        return getUsername();
    }
   
    public boolean equals(Object object) {
        if (object instanceof UserLoginData) {
            if (((UserLoginData) object).getUsername().equals(getUsername())) {
                return true;
            }
        }
        return false;
    }
    
    public int hashCode() {
        return getUsername().hashCode();
    }
    
    public Date getLastLoginDate() {
        return loginDate;
    }
    
    public void setLastLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }
    
    public void setAuthenticated(boolean auth) {
        this.auth = auth;
        if (auth) {
            loginDate = new Date();
        }
    }

    public boolean isAuthenticated() {
        return auth;
    }
    
    public void setSettings(UserSettings settings) {
        this.settings = settings;
    }
    
    public UserSettings getSettings() {
        return settings;
    }

	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	public boolean isRememberlogin() {
		return rememberlogin;
	}

	public void setRememberlogin(boolean rememberlogin) {
		this.rememberlogin = rememberlogin;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getSystemAdminId() {
		return systemAdminId;
	}

	public void setSystemAdminId(int systemAdminId) {
		this.systemAdminId = systemAdminId;
	}

	public int getCompanyUserId() {
		return companyUserId;
	}

	public void setCompanyUserId(int companyUserId) {
		this.companyUserId = companyUserId;
	}

}
