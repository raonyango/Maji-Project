package com.maji.shared.beans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UserSettings implements Serializable{

}
