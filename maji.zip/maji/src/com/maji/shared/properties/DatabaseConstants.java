package com.maji.shared.properties;

public class DatabaseConstants {
	 public static final String NEW_ACCOUNT_CONFIRMATION = "NEW ACCOUNT CONFIRMATION";
	 public static final String PASSWORD_RESET = "PASSWORD RESET";
	 public static final String ROLE_COMPANY_USER = "ROLE_COMPANY_USER";
	 public static final String ROLE_COMPANY_ADMIN = "ROLE_COMPANY_ADMIN";
	 public static final String ROLE_SYSTEM_ADMIN = "ROLE_SYSTEM_ADMIN";
	
}
