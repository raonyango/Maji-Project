package com.maji.shared.properties;

import com.google.gwt.i18n.client.Messages;

public interface MajiMessages extends Messages {

	@DefaultMessage("{0} of {1} selected")
	public String selected(int arg0, int arg1);

	@DefaultMessage("Page {0}")
	public String page(int arg0);
	
}
