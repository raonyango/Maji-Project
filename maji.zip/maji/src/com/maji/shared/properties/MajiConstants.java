package com.maji.shared.properties;

public class MajiConstants {
	public static final String USER_SESS_ATTR = "logged_user";
	public static final String USERNAME_COOKIE = "brainup_username_cke";
	
	public static final String PRE_AUTH_SESSION_ID = "pre_auth_session_id";
	public static final String USER_SESS_ID = "brainupsid";
	public static final String REQUIRED_FIELD_SYMBOL = "*";
	public static final String COMPANY_PREFIX = "BR_CO";
	public static final String APP_NAME = "Maji";
	
	public static final int FORM_FIELD_WIDTH = 225;
	public static final int ERROR_MSG_WIDTH = 225;
	public static final int FORM_HEADER_HEIGHT = 27;
	public static final int MIN_PASSWORD_LENGTH = 5;
	public static final int LABEL_HEIGHT = 15;
	
	public static final String NUMERIC_KEY_PRESS_FILTER = "[0-9]";
	
	public static final String TERMS_OF_USE_PAGE = "TermsOfUse.html";	
	public static final String HOME_PAGE = "Maji.html";
	public static final String ACCOUNT_ACTIVATION_ERROR_PAGE = "AccountActivationError.html";
	
	public static final int DEFAULT_MAX_GRID_RESULTS = 50;
	public static final String[] CLOUD_VIEWS = new String[]{"Company", "News", "Company and News"};
	public static final String[] FONTS = new String[]{"Gerogia", "Tahoma", "Verdana", "Times New Roman"};
	
	public static final String USERID = "userid";
	public static final String USER_SERVICES = "user_services";
	public static final String USER_NEWSPAPERS = "user_newspapers"; 
	public static final String USER_NEWSCATEGORIES = "user_newscategories";
	
	public static final String ALL_NEWSPAPERS_KEY = "allnewspaperskey"; 
	public static final String ALL_NEWSCATS_KEY = "allnewscatskey"; 
	public static final String ALL_NEWSPAPERSDTO_KEY = "allnewspapersdtokey";
	public static final String CONSTANTS_CACHE = "constantsCache";	
	
}

