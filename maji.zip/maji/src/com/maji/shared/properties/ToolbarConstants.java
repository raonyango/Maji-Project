package com.maji.shared.properties;

import com.google.gwt.i18n.client.Constants;

public interface ToolbarConstants extends Constants {

	@DefaultStringValue("Background color")
    public String editor_background();

	public String savebtn_tooltip();

	public String printpreviewbtn_tooltip();

	public String emailbtn_tooltip();

	public String helpbtn_tooltip();

	public String refreshbtn_tooltip();
	
	public String savebtn_caption();

	public String prinpreviewbtn_caption();

	public String emailbtn_caption();

	public String refreshbtn_caption();

	public String helpbtn_caption();

	public String change_pwd_btn_caption();

	public String change_pwd_btn_tooltip();

	public String export_btn_caption();

	public String export_btn_tooltip();
	
	public String new_btn_caption();
	
	public String new_btn_tooltip();

	public String cancelbtn_caption();

	public String save_close_btn_tooltip();

	public String save_close_btn_caption();

	public String updatebtn_tooltip();

	public String updatebtn_caption();
	
}
