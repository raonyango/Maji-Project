package com.maji.shared.properties;

public class MajiCSS {
	//IMAGES
	public static final String resultset_next_img_src = "statusbar/resultsetnext.png";
	public static final String resultset_prev_img_src = "statusbar/resultsetprevious.png";
	public static final String resultset_first_img_src = "statusbar/resultsetfirst.png";
	
	//CSS
	public static final String loading = "brainup-loading";
	public static final String masked_loading = "brainup-masked-loading";
	
	public static final String brainup_rnd_container = "brainup-rounded";
	public static final String brainup_rnd_container_no_border = "brainup-rounded-no-border";
	public static final String button_container ="brainup-button-bar";
	
    public static final String login_info_container = "brainup-loginfo";
    public static final String login_info_label = "brainup-loginfo-label";
    public static final String login_info_user = "brainup-loginfo-user";
    public static final String login_container = "brainup-login";
    public static final String login_form = "brainup-login-form";
    public static final String login_box = "brainup-login-textbox";
    public static final String login_form_button ="brainup-loginfo-button";
    public static final String login_infolbl ="brainup-loginfo-lbl";
    public static final String login_txt_error ="brainup-logintxt-error";
    public static final String logout_link = "brainup-logout-link";
    public static final String navigation_pane_grid_cell = "brainup-navigationpane-grid-cell";	
	public static final String navigation_pane = "brainup-navigationpane";
    public static final String navigation_pane_header = "brainup-navigationpane-header";
	public static final String navigation_pane_header_lbl = "brainup-navigationpane-header-lbl";
	public static final String context_area_header_lbl = "brainup-contentarea-header-lbl";
	
    public static final String menu_button = "brainup-menu-button";    
    public static final String app_container ="brainup";
    public static final String logo_container ="brainup-logo";
    public static final String top_container ="brainup-top";
    public static final String main_container ="brainup-main";
    public static final String bottom_container ="brainup-bottom";
    public static final String info_container ="brainup-info-bar";
    public static final String header ="brainup-header";
    public static final String flash ="brainup-flash";
    public static final String appnamelbl ="brainup-appname-lbl";
    public static final String signedin_user_lbl = "brainup-signedin-user-lbl";
	public static final String profile_infolbl = "brainup-profileinfo-lbl";
	public static final String profile_form_button = "brainup-profileinfo-button";
	public static final String profile_form = "brainup-profile-form";   
	public static final String profile_container = "brainup-profile-container";  
	public static final String profile_main_container = "brainup-profile-main-container";
	public static final String profile_wrapper_container = "brainup-profile-maincontainer-wrapper";
	
	public static final String brainup_err_lbl = "brainup-err-lbl";
	public static final String form_html = "brainup_form_html";
	public static final String brainup_titlelbl = "brainup-title-lbl";
	public static final String section_lbl = "brainup-section-lbl";
	public static final String profile_title_lbl = "brainup-profile-title-lbl";
	public static final String password_checker = "brainup-passwordchecker-class";
	public static final String refresh_captcha_btn = "brainup-refresh-captcha-btn";
	
	public static final String password_checker_result_id = "brainup-pwd-checker-result-id";
	public static final String password_short = "brainup-short-password";
	public static final String password_bad = "brainup-bad-password";
	public static final String password_good = "brainup-good-password";
	public static final String password_strong = "brainup-strong-password";
	public static final String password_checker_basestyle = "brainup-checker-basestyle";
	public static final String password_checker_useridelement = "brainup-username-input";
	public static final String password_checker_username_element = "brainup-username";	
	
	public static final String application_menu="brainup-application-menu";
	
	public static final String toolbar = "brainup-toolbar";
	public static final String record_toolstrip = "brainup-record-toolstrip";
	public static final String record_toolbar = "brainup-record-toolbar";
	public static final String brainup_info_lbl = "brainup-info-lbl";
	public static final String errorpage_info_lbl = "brainup-errorpage-info-lbl";
	public static final String errorpage_error_lbl = "brainup-errorpage-error-lbl";
	
	public static final String statusbar_label = "brainup-statusbar-lbl";	
	public static final String StatusBar = "brainup-status-bar";
	public static final String context_area = "brainup-context-area";
	public static final String frames_wrapper_container = "brainup-profile-maincontainer-wrapper";
	public static final String grid_alternating = "brainup-grid-alternating";		
	
	
}
